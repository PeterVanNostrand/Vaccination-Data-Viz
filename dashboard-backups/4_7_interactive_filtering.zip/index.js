const { 
  csv,
  select,
  json,
  brushX
} = d3;
import { interactiveBar } from './interactiveBar';
import { stateMenu } from './stateMenu';
import { mapElement } from './mapElement';
import React, { useState, useRef } from 'react';

// data source url
const csvUrl = [
  'https://gist.githubusercontent.com/',
  'PeterVanNostrand/', // User
  'd449b0a3e5914278dfa79ba60e48df5d/', // Id of the Gist
  'raw/', // commit
  'vaccine_data.csv', // File name
].join('');

const jsonURL = [
	'https://gist.githubusercontent.com/',
  'PeterVanNostrand/',
  'd449b0a3e5914278dfa79ba60e48df5d/',
  'raw/',
  'state_centroids.json'
].join('')

const mapURL = 'https://unpkg.com/us-atlas@3.0.0/states-10m.json'

// parsing the dataset
const parseRow = (d) => {
  d.date = new Date(d.date);
  d.total_vaccinations = +d.total_vaccinations;
  d.total_distributed = +d.total_distributed;
  d.people_vaccinated = +d.people_vaccinated;
  d.people_fully_vaccinated_per_hundred = +d.people_fully_vaccinated_per_hundred;
  d.total_vaccinations_per_hundred = +d.total_vaccinations_per_hundred;
  d.people_fully_vaccinated = +d.people_fully_vaccinated;
  d.people_vaccinated_per_hundred = +d.people_vaccinated_per_hundred;
  d.distributed_per_hundred = +d.distributed_per_hundred;
  d.daily_vaccinations_raw = +d.daily_vaccinations_raw;
  d.daily_vaccinations = +d.daily_vaccinations;
  d.daily_vaccinations_per_million = +d.daily_vaccinations_per_million;
  d.share_doses_used = +d.share_doses_used;
  return d;
};

// Select the SVG element
const width = window.innerWidth;
const height = window.innerHeight;

const svg = select('body')
  .append('svg')
  .attr('width', width - 300)
  .attr('height', height - 200)
	.attr('class', 'map_svg');

const svg2 = select('body')
  .append('svg')
  .attr('width', width - 20)
  .attr('height', 180)
	.attr('class', 'bar_svg');

var tooltip = select('body')
  .append('div')
	.append('div')
    .attr('id', 'tooltip')
		.attr('class', 'tooltip-container')
    .style('position','absolute')
    .style('visibility', 'hidden');

const map_tooltip = select('body')
  .append('div')
  .attr('class', 'd3-tooltip')
  .style('position', 'absolute')
  .style('z-index', '10')
  .style('visibility', 'hidden')
  .style('padding', '10px')
  .style('background', 'rgba(0,0,0,0.6)')
  .style('border-radius', '5px')
  .style('color', 'white');

const map_group = svg.append('g')
const map_scale = 0.6
map_group.attr('id', 'map_group');
map_group.attr('transform', 'scale(0.6)');

const bar_group = svg2.append('g');
const bar_plot_height = 180;

let zoom = d3.zoom()
 .on('zoom', (e, d) => {
   const trans_x = e.transform.x
   const trans_y = e.transform.y
   const trans_scale = e.transform.k
   map_group.attr('transform',`translate(${trans_x},${trans_y}) scale(${trans_scale * map_scale})`)
});



const main = async () => {
  // load data
  const data = await csv(csvUrl, parseRow);
  const us_states = await json(mapURL);
  let stateCentroids = await json(jsonURL);
  
  function onlyUnique(value, index, self) {
  	return self.indexOf(value) === index;
	}	
	const states_list = data
  	.map((d) => d.location)
  	.filter(onlyUnique);
  
  // create map  
  const map_height = height - bar_plot_height;
   const map_plot = mapElement()
  	.data(data)
  	.map_data(us_states)
  	.state_centroids(stateCentroids)
   	.selected_date(new Date('2021-09-04'))
    .states_list(states_list)
   	.plot_group(bar_group)
   	.tooltip(map_tooltip);
  map_group.call(map_plot);
  
  // create bar plot
  const bar_plot = interactiveBar()
    .width(width - 20)
    .height(bar_plot_height)
    .data(data)
    .xValue((d) => d.date)
    .yValue((d) => d.daily_vaccinations)
    .margin({
      top: 20,
      right: 20,
      bottom: 40,
      left: 100,
    })
    .bar_width(3)
    .bar_color('#5DABF4')
  	.bar_opacity(1.0)
    .selected_state("Alabama")
  	.label_size('1em')
  	.map_group(map_group)
  	.map(map_plot);
  bar_group.call(bar_plot);
  
  map_plot.plot(bar_plot);
  
  // create menu
  const my_menu = stateMenu()
  	.data(data)
  	.plot(bar_plot);
	bar_group.call(my_menu);
  svg.call(zoom);

};

main();
