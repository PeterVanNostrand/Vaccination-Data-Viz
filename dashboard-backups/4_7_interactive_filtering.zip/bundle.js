(function (d3$1, react) {
  'use strict';

  var react__default = 'default' in react ? react['default'] : react;

  const interactiveBar = () => {
    let width;
    let height;
    let state_data;
    let data;
    let xValue;
    let yValue;
    let margin;
    let bar_width;
    let bar_color;
    let bar_opacity;
    let selected_state;
    let label_size;
  	let map_group;
    let map;
    
    const my = (selection) => {
      function filter_state(list) {
        return list.location == selected_state;
      }

      // Create a time scale for the x-axis
      const mindate = new Date('2021-04-01');
      const maxdate = new Date('2021-09-04');
      const x = d3$1.scaleTime()
        .domain([mindate, maxdate])
        .range([margin.left, width - margin.right]);

      state_data = data.filter(filter_state);

      // create y scale, y is used to determine the bar height y1 is just used
      // to plot the axis in the right direction
      const y = d3$1.scaleLinear()
        .domain([
          d3$1.extent(state_data, yValue)[1] * 1.1,
          d3$1.extent(state_data, yValue)[0],
        ])
        .range([height - margin.bottom, margin.top]);
      const y1 = d3$1.scaleLinear()
        .domain([
          d3$1.extent(state_data, yValue)[0],
          d3$1.extent(state_data, yValue)[1] * 1.1,
        ])
        .range([height - margin.bottom, margin.top]);

      // create a set of marks to visualize
      const correctDate = (d) => {
        let date = new Date(d.valueOf());
        date.setDate(date.getDate() + 32);
        return date;
      };
      const marks = state_data.map((d) => {
        return {
          x: x(xValue(d)),
          y: y(yValue(d)),
          date: correctDate(d.date),
          doses: d.daily_vaccinations,
        };
      });

      // hover animation functions
      function handle_mouse_over(e, d) {
        // console.log('mover');
        selection
          .selectAll('rect')
          .transition()
          .duration('100')
          .attr('opacity', bar_opacity / 2);
        d3$1.select(this)
          .transition()
          .duration('100')
          .attr('opacity', bar_opacity);
        d3$1.select('#tooltip')
          .style('visibility', 'visible')
          .text(
            'Date: ' +
              d.date.getMonth() +
              '/' +
              d.date.getDate() +
              ', Doses: ' +
              d.doses
          );
      }

      function handle_mouse_move(e, d) {
        // console.log(event.PageX, event.PageY);
        d3$1.select('#tooltip')
          .style('top', event.pageY - 25 + 'px')
          .style('left', event.pageX + 'px');
      }

      function handle_mouse_out(e, d) {
        selection
          .selectAll('rect')
          .transition()
          .duration('100')
          .attr('opacity', bar_opacity);
        d3$1.select('#tooltip').style('visibility', 'hidden');
      }
      
      // animation functions
      const t = d3$1.transition().duration(500);
      const positionBars = (bars) => {
        bars
          .attr('x', (d) => {
            return d.x + bar_width / 2;
          })
          .attr('y', (d) => {
            // place the bottom of each bar at the x-axis
            return height - margin.bottom - d.y;
          })
          .attr('fill', bar_color)
          .attr('opacity', bar_opacity)
          .attr('height', (d) => d.y);
      };

      const set_handlers = (bars) => {
        bars.on('mouseover', handle_mouse_over);
        bars.on('mousemove', handle_mouse_move);
        bars.on('mouseout', handle_mouse_out);
      };
      
      const initializeWidth = (bars) => {
        bars.attr('width', 0);
        bars.attr('height', 0);
      };
      const growWidth = (enter) => {
        enter.transition(t).attr('width', bar_width);
        enter.transition(t).attr('height', (d) => d.y);
      };


      // draw the bars
      const bars = selection
        .selectAll('rect')
        .data(marks)
        .join(
          (enter) =>
            enter
              .append('rect')
          		.attr("pointer-events", "all")
              .call(positionBars)
              .call(initializeWidth)
              .call(growWidth)
          		.call(set_handlers),
          (update) =>
            update.call((update) =>
              update
                .transition(t)
                .delay((d, i) => i * 10)
                .call(positionBars)
            ),
          (exit) => exit.remove()
        );
      // redraw y axis
      selection
        .selectAll('.y-axis')
        .data([null])
        .join('g')
        .attr('class', 'y-axis')
        .attr('transform', `translate(${margin.left},0)`)
        .transition(t)
        .call(d3$1.axisLeft(y1));

      // redraw x axis
      selection
        .selectAll('.x-axis')
        .data([null])
        .join('g')
        .attr('class', 'x-axis')
        .attr(
          'transform',
          `translate(0,${height - margin.bottom})`
        )
        .transition(t)
        .call(d3$1.axisBottom(x));
      
      // brushing
      function brushed(e, d){
        const brush_area = e.selection;
        
        let end_date = new Date('2021-09-04');
        if(brush_area){
          const start_date = x.invert(brush_area[0]);
        	end_date = x.invert(brush_area[1]);
        }
        map_group.call(map.selected_date(end_date));
      }
      const brush = d3$1.brushX()
        .extent([[0,0], [width, height]])
        .on("brush end", brushed);
      selection.call(brush);
      // select('.overlay').attr('display', 'none');
      
      // Add axis labels
      selection
        .selectAll('.x-axis-label')
      	.data([null])
      	.join('text')
        .attr('y', height - 10)
        .attr('x', width / 2 - 10)
        .text('Date, 2021')
        .attr('font-size', label_size)
      	.attr('class', 'x-axis-label');
      
      selection
        .selectAll('.y-axis-label')
      	.data([null])
      	.join('text')
        .attr('x', 0)
        .attr('y', height/2-20)
        .text('Daily Doses Distributed')
        .attr('transform', `rotate(270, 70, ${height/2})`)
        .attr('font-size', label_size)
      	.attr('class', 'y-axis-label');
    };

    my.width = function (_) {
      return arguments.length ? ((width = +_), my) : width;
    };

    my.height = function (_) {
      return arguments.length ? ((height = +_), my) : height;
    };

    my.data = function (_) {
      return arguments.length ? ((data = _), my) : data;
    };

    my.xValue = function (_) {
      return arguments.length ? ((xValue = _), my) : xValue;
    };

    my.yValue = function (_) {
      return arguments.length ? ((yValue = _), my) : yValue;
    };

    my.margin = function (_) {
      return arguments.length ? ((margin = _), my) : margin;
    };

    my.bar_width = function (_) {
      return arguments.length
        ? ((bar_width = +_), my)
        : bar_width;
    };

    my.bar_opacity = function (_) {
      return arguments.length
        ? ((bar_opacity = +_), my)
        : bar_opacity;
    };

    my.bar_color = function (_) {
      return arguments.length
        ? ((bar_color = _), my)
        : bar_color;
    };

    my.selected_state = function (_) {
      return arguments.length
        ? ((selected_state = _), my)
        : selected_state;
    };
    
    my.label_size = function (_) {
      return arguments.length
        ? ((label_size = _), my)
        : label_size;
    };
    
    my.map_group = function (_) {
      return arguments.length ? ((map_group = _), my) : map_group;
    };
    
    my.map = function (_) {
      return arguments.length ? ((map = _), my) : map;
    };

    return my;
  };

  const menu = () => {
    let id;
    let labelText;
    let options;
    const listeners = d3$1.dispatch('change');
    
    const my = (selection) => {
      selection
        .selectAll('label')
        .data([null])
        .join('label')
        .attr('for', id)
        .text(labelText);

      selection
        .selectAll('select')
        .data([null])
        .join('select')
        .attr('id', id)
        .on('change', (event) => {
          listeners.call('change', null, event.target.value);
        })
        .selectAll('option')
        .data(options)
        .join('option')
        .attr('value', (d) => d.value)
        .text((d) => d.text);
    };

    my.id = function (_) {
      return arguments.length ? ((id = _), my) : id;
    };

    my.labelText = function (_) {
      return arguments.length
        ? ((labelText = _), my)
        : labelText;
    };

    my.options = function (_) {
      return arguments.length ? ((options = _), my) : options;
    };

    my.on = function () {
      var value = listeners.on.apply(listeners, arguments);
      return value === listeners ? my : value;
    };

    return my;
  };

  const stateMenu = () => {
    let data;
    let plot;
    
    const my = (selection) => {
      const menuContainer = d3$1.select('body')
      	.append('div')
      	.attr('class', 'menu-container');
      const state_menu = menuContainer.append('div');
      const yMenu = menuContainer.append('div');
      
      function onlyUnique(value, index, self) {
        return self.indexOf(value) === index;
      }
      const states = data
        .map((d) => d.location)
        .filter(onlyUnique);
      const options = states.map((d) => {
        return { value: d, text: d };
      });
      
      state_menu.call(
        menu()
          .id('state-menu')
          .labelText('State:')
          .options(options)
          .on('change', (state) => {
            selection.call(
              plot.selected_state(state)
            );
          })
      );
    };

    my.data = function (_) {
      return arguments.length ? ((data = _), my) : data;
    };
      
    my.plot = function (_) {
      return arguments.length ? ((plot = _), my) : plot;
    };
    
    return my;
  };

  const mapElement = () => {
    let data;
    let map_data;
    let state_centroids;
    let selected_date;
    let tooltip;
    let plot;
    let plot_group;
    let states_list;
    
    function map_mouse_move(e,d) {
      tooltip
        .style('top', event.pageY - 10 + 'px')
        .style('left', event.pageX + 10 + 'px');
    }

    function map_mouse_on(e,d){
      // hover on dougnut plot group
      if(d.location){
        tooltip
        .html(
          `State: ${d.location}`
        )
        .style('visibility', 'visible');
      }
      // hover on state path
      if(d.properties){
        tooltip
        .html(
          `State: ${d.properties.name}`
        )
        .style('visibility', 'visible');
      }
    }

    function map_mouse_out(e,d) {
        tooltip.html(``).style('visibility', 'hidden');
    }

    function update_dropdown(selected_state){
      if(data){
      	const state_index = states_list.findIndex((f) => { return f > selected_state });
      	const dropdown = d3$1.select('#state-menu');
      	dropdown.property('selectedIndex', state_index-1);
      }
    }
    
    function map_mouse_click(e,d) {
      // click on dougnut plot group
      if(d.location){
        plot_group.call(
          plot.selected_state(d.location)
        );
        update_dropdown(d.location);
      }
      // click on state path
      if(d.properties){
        plot_group.call(
          plot.selected_state(d.properties.name)
        );
        update_dropdown(d.properties.name);
      }
    }
    
    
    const my = (selection) => {
    	const projection = d3$1.geoAlbersUsa();
      const path = d3$1.geoPath(projection);
      
      const states = selection
        .selectAll('path')
        .data(topojson.feature(map_data, map_data.objects.states).features)
        .join(
          (enter) =>
            enter
              .append('path')
              .attr('d', path)
              .attr('id', (d) => d.properties.name)
              .attr('id', (d) => d.location)
              .attr('stroke', 'black')
              .attr('fill', 'lightgray')
          		.on('mouseover', map_mouse_on)
          		.on('mousemove', map_mouse_move)
          		.on('mouseout', map_mouse_out)
          		.on('mousedown', map_mouse_click),
          (update) =>
            update.call((update) =>update),
          (exit) => exit.remove()
        );
      
      // const selected_date = new Date('2021-09-04');
      function filter_date(list) {
        return list.date.getDate() == selected_date.getDate()&& 
          list.date.getMonth() == selected_date.getMonth()&& 
          list.date.getFullYear() == selected_date.getFullYear();
      }
      const date_data = data.filter(filter_date);  
      
      let my_state = "California";
      function get_state_centroid(centroids) {
        return centroids.name == my_state;
      }

      let marks = date_data.map((d) => {
        my_state = d.location;
        const center = state_centroids.filter(get_state_centroid)[0];
        if(center)
          return { 
            location : d.location,
            lat : center.lat,
            lon : center.lon,
            full : d.people_fully_vaccinated_per_hundred,
            part : d.people_vaccinated_per_hundred,
            doses : d.share_doses_used
          }
      });
      
      marks = marks.filter(function( element ) {
       return element !== undefined;
      });

      const highest_vacc = d3$1.max(marks, function (d) {
          return d.full;
      });
      
      // ARC STUFF
      let ring_width = 7;
      let ring_radius = 12;
      function generateArc(d, base_radius, value) {
      	let inner = base_radius;
        let outer = base_radius + ring_width;
        let angle = (value(d) / 100) * 2*Math.PI;
        let arcGen = d3$1.arc()
          .innerRadius(inner)
          .outerRadius(outer)
          .startAngle(0)
          .endAngle(angle);
        return arcGen(d);
      }
      // END ARC STUFF
    
      const circleRadius = d3
        .scaleSqrt()
        .domain([0, highest_vacc])
        .range([0, 25]); // 0 to maximum radius in pixels
      
     	function radius (d) { 
         return ring_radius;
      }	

      var simulation = d3$1.forceSimulation(marks)
        .force("x", d3$1.forceX(function(d) {
          return projection([+d.lon,+d.lat])[0];
        }))
        .force("y", d3$1.forceY(function(d) {
          return projection([+d.lon,+d.lat])[1];
        }))
        .force("collide", d3$1.forceCollide(d => radius() + ring_width*2 + 1))
        .stop();
      for (var i = 0; i < 120; ++i) simulation.tick();
         
      
      const vacc_value = (d) => d.full;
      const dose_value = (d) => d.doses * 100;
      
      function drawmark (enter){
        let g = enter.append('g').attr('class', 'marks');
        
        g.append('circle')
        		.attr('class', 'circles')
            .attr('cx', (d) => d.x)
            .attr('cy', (d) => d.y)
            .attr('id', (d) => d.location)
            .attr('fill', '#e0dcdc')
            .attr('stroke', 'black')
            .attr('stroke-width', 2)
            .attr('opacity', 1)
            .attr('r', d => radius() + ring_width*2);
        
        g.append("text")
            .attr('class', 'vacc-text')
            .attr('x', (d) => d.x - 10)
            .attr('y', (d) => d.y + 5)
            .text((d) => "" + parseInt(d.full));
        
        g.append("path")
            .attr('class', 'vacc-rings')
            .attr("d", d => {return generateArc(d, ring_radius, vacc_value)})
            .attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
            .attr('id', (d) => d.location)
            .attr('fill', 'blue');
        
        g.append("path")
            .attr('class', 'dose-rings')
            .attr("d", d => {return generateArc(d, ring_width + ring_radius, dose_value)})
            .attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
            .attr('id', (d) => d.location)
            .attr('fill', 'green');
        
        g.on('mouseover', map_mouse_on);
        g.on('mousemove', map_mouse_move);
        g.on('mouseout', map_mouse_out);
        g.on('mousedown', map_mouse_click);
        
        return g;
      }
      
      function updatemark(update){
        selection.selectAll('.vacc-text').data(marks)
          .text((d) => "" + parseInt(d.full));
        
        selection.selectAll('.marks').data(marks)
          .append("path")
            .attr('class', 'vacc-rings')
            .attr("d", d => {return generateArc(d, ring_radius, vacc_value)})
            .attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
            .attr('id', (d) => d.location)
            .attr('fill', 'blue');
        
        selection.selectAll('.marks').append("path")
            .attr('class', 'dose-rings')
            .attr("d", d => {return generateArc(d, ring_width + ring_radius, dose_value)})
            .attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
            .attr('id', (d) => d.location)
            .attr('fill', 'green');
      }
      
      const groups  = selection
        .selectAll('.marks')
        .data(marks)
      	.join(
          (enter) => drawmark(enter),
          (update) => updatemark(),
          (exit) => exit.remove()
        );
    };
    
    my.data = function (_) {
      return arguments.length ? ((data = _), my) : data;
    };
    
    my.map_data = function (_) {
      return arguments.length ? ((map_data = _), my) : map_data;
    };
    
    my.state_centroids = function (_) {
      return arguments.length ? ((state_centroids = _), my) : state_centroids;
    };
    
    my.selected_date = function (_) {
      return arguments.length ? ((selected_date = _), my) : selected_date;
    };
    
    my.plot = function (_) {
      return arguments.length ? ((plot = _), my) : plot;
    };
    
    my.plot_group = function (_) {
      return arguments.length ? ((plot_group = _), my) : plot_group;
    };
    
    my.tooltip = function (_) {
      return arguments.length ? ((tooltip = _), my) : tooltip;
    };
    
    my.states_list = function (_) {
      return arguments.length ? ((states_list = _), my) : states_list;
    };
    
    return my;
  };

  const { 
    csv,
    select,
    json,
    brushX
  } = d3;

  // data source url
  const csvUrl = [
    'https://gist.githubusercontent.com/',
    'PeterVanNostrand/', // User
    'd449b0a3e5914278dfa79ba60e48df5d/', // Id of the Gist
    'raw/', // commit
    'vaccine_data.csv', // File name
  ].join('');

  const jsonURL = [
  	'https://gist.githubusercontent.com/',
    'PeterVanNostrand/',
    'd449b0a3e5914278dfa79ba60e48df5d/',
    'raw/',
    'state_centroids.json'
  ].join('');

  const mapURL = 'https://unpkg.com/us-atlas@3.0.0/states-10m.json';

  // parsing the dataset
  const parseRow = (d) => {
    d.date = new Date(d.date);
    d.total_vaccinations = +d.total_vaccinations;
    d.total_distributed = +d.total_distributed;
    d.people_vaccinated = +d.people_vaccinated;
    d.people_fully_vaccinated_per_hundred = +d.people_fully_vaccinated_per_hundred;
    d.total_vaccinations_per_hundred = +d.total_vaccinations_per_hundred;
    d.people_fully_vaccinated = +d.people_fully_vaccinated;
    d.people_vaccinated_per_hundred = +d.people_vaccinated_per_hundred;
    d.distributed_per_hundred = +d.distributed_per_hundred;
    d.daily_vaccinations_raw = +d.daily_vaccinations_raw;
    d.daily_vaccinations = +d.daily_vaccinations;
    d.daily_vaccinations_per_million = +d.daily_vaccinations_per_million;
    d.share_doses_used = +d.share_doses_used;
    return d;
  };

  // Select the SVG element
  const width = window.innerWidth;
  const height = window.innerHeight;

  const svg = select('body')
    .append('svg')
    .attr('width', width - 300)
    .attr('height', height - 200)
  	.attr('class', 'map_svg');

  const svg2 = select('body')
    .append('svg')
    .attr('width', width - 20)
    .attr('height', 180)
  	.attr('class', 'bar_svg');

  var tooltip = select('body')
    .append('div')
  	.append('div')
      .attr('id', 'tooltip')
  		.attr('class', 'tooltip-container')
      .style('position','absolute')
      .style('visibility', 'hidden');

  const map_tooltip = select('body')
    .append('div')
    .attr('class', 'd3-tooltip')
    .style('position', 'absolute')
    .style('z-index', '10')
    .style('visibility', 'hidden')
    .style('padding', '10px')
    .style('background', 'rgba(0,0,0,0.6)')
    .style('border-radius', '5px')
    .style('color', 'white');

  const map_group = svg.append('g');
  const map_scale = 0.6;
  map_group.attr('id', 'map_group');
  map_group.attr('transform', 'scale(0.6)');

  const bar_group = svg2.append('g');
  const bar_plot_height = 180;

  let zoom = d3.zoom()
   .on('zoom', (e, d) => {
     const trans_x = e.transform.x;
     const trans_y = e.transform.y;
     const trans_scale = e.transform.k;
     map_group.attr('transform',`translate(${trans_x},${trans_y}) scale(${trans_scale * map_scale})`);
  });



  const main = async () => {
    // load data
    const data = await csv(csvUrl, parseRow);
    const us_states = await json(mapURL);
    let stateCentroids = await json(jsonURL);
    
    function onlyUnique(value, index, self) {
    	return self.indexOf(value) === index;
  	}	
  	const states_list = data
    	.map((d) => d.location)
    	.filter(onlyUnique);
     const map_plot = mapElement()
    	.data(data)
    	.map_data(us_states)
    	.state_centroids(stateCentroids)
     	.selected_date(new Date('2021-09-04'))
      .states_list(states_list)
     	.plot_group(bar_group)
     	.tooltip(map_tooltip);
    map_group.call(map_plot);
    
    // create bar plot
    const bar_plot = interactiveBar()
      .width(width - 20)
      .height(bar_plot_height)
      .data(data)
      .xValue((d) => d.date)
      .yValue((d) => d.daily_vaccinations)
      .margin({
        top: 20,
        right: 20,
        bottom: 40,
        left: 100,
      })
      .bar_width(3)
      .bar_color('#5DABF4')
    	.bar_opacity(1.0)
      .selected_state("Alabama")
    	.label_size('1em')
    	.map_group(map_group)
    	.map(map_plot);
    bar_group.call(bar_plot);
    
    map_plot.plot(bar_plot);
    
    // create menu
    const my_menu = stateMenu()
    	.data(data)
    	.plot(bar_plot);
  	bar_group.call(my_menu);
    svg.call(zoom);

  };

  main();

}(d3, React));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbImludGVyYWN0aXZlQmFyLmpzIiwibWVudS5qcyIsInN0YXRlTWVudS5qcyIsIm1hcEVsZW1lbnQuanMiLCJpbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBzY2FsZUxpbmVhcixcbiAgZXh0ZW50LFxuICBheGlzTGVmdCxcbiAgYXhpc0JvdHRvbSxcbiAgdHJhbnNpdGlvbixcbiAgc2VsZWN0LFxuICBzY2FsZVRpbWUsXG4gIGJydXNoWFxufSBmcm9tICdkMyc7XG5cblxuZXhwb3J0IGNvbnN0IGludGVyYWN0aXZlQmFyID0gKCkgPT4ge1xuICBsZXQgd2lkdGg7XG4gIGxldCBoZWlnaHQ7XG4gIGxldCBzdGF0ZV9kYXRhO1xuICBsZXQgZGF0YTtcbiAgbGV0IHhWYWx1ZTtcbiAgbGV0IHlWYWx1ZTtcbiAgbGV0IG1hcmdpbjtcbiAgbGV0IGJhcl93aWR0aDtcbiAgbGV0IGJhcl9jb2xvcjtcbiAgbGV0IGJhcl9vcGFjaXR5O1xuICBsZXQgc2VsZWN0ZWRfc3RhdGU7XG4gIGxldCBsYWJlbF9zaXplO1xuXHRsZXQgbWFwX2dyb3VwO1xuICBsZXQgbWFwO1xuICBcbiAgY29uc3QgbXkgPSAoc2VsZWN0aW9uKSA9PiB7XG4gICAgZnVuY3Rpb24gZmlsdGVyX3N0YXRlKGxpc3QpIHtcbiAgICAgIHJldHVybiBsaXN0LmxvY2F0aW9uID09IHNlbGVjdGVkX3N0YXRlO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSBhIHRpbWUgc2NhbGUgZm9yIHRoZSB4LWF4aXNcbiAgICBjb25zdCBtaW5kYXRlID0gbmV3IERhdGUoJzIwMjEtMDQtMDEnKTtcbiAgICBjb25zdCBtYXhkYXRlID0gbmV3IERhdGUoJzIwMjEtMDktMDQnKTtcbiAgICBjb25zdCB4ID0gc2NhbGVUaW1lKClcbiAgICAgIC5kb21haW4oW21pbmRhdGUsIG1heGRhdGVdKVxuICAgICAgLnJhbmdlKFttYXJnaW4ubGVmdCwgd2lkdGggLSBtYXJnaW4ucmlnaHRdKTtcblxuICAgIHN0YXRlX2RhdGEgPSBkYXRhLmZpbHRlcihmaWx0ZXJfc3RhdGUpO1xuXG4gICAgLy8gY3JlYXRlIHkgc2NhbGUsIHkgaXMgdXNlZCB0byBkZXRlcm1pbmUgdGhlIGJhciBoZWlnaHQgeTEgaXMganVzdCB1c2VkXG4gICAgLy8gdG8gcGxvdCB0aGUgYXhpcyBpbiB0aGUgcmlnaHQgZGlyZWN0aW9uXG4gICAgY29uc3QgeSA9IHNjYWxlTGluZWFyKClcbiAgICAgIC5kb21haW4oW1xuICAgICAgICBleHRlbnQoc3RhdGVfZGF0YSwgeVZhbHVlKVsxXSAqIDEuMSxcbiAgICAgICAgZXh0ZW50KHN0YXRlX2RhdGEsIHlWYWx1ZSlbMF0sXG4gICAgICBdKVxuICAgICAgLnJhbmdlKFtoZWlnaHQgLSBtYXJnaW4uYm90dG9tLCBtYXJnaW4udG9wXSk7XG4gICAgY29uc3QgeTEgPSBzY2FsZUxpbmVhcigpXG4gICAgICAuZG9tYWluKFtcbiAgICAgICAgZXh0ZW50KHN0YXRlX2RhdGEsIHlWYWx1ZSlbMF0sXG4gICAgICAgIGV4dGVudChzdGF0ZV9kYXRhLCB5VmFsdWUpWzFdICogMS4xLFxuICAgICAgXSlcbiAgICAgIC5yYW5nZShbaGVpZ2h0IC0gbWFyZ2luLmJvdHRvbSwgbWFyZ2luLnRvcF0pO1xuXG4gICAgLy8gY3JlYXRlIGEgc2V0IG9mIG1hcmtzIHRvIHZpc3VhbGl6ZVxuICAgIGNvbnN0IGNvcnJlY3REYXRlID0gKGQpID0+IHtcbiAgICAgIGxldCBkYXRlID0gbmV3IERhdGUoZC52YWx1ZU9mKCkpO1xuICAgICAgZGF0ZS5zZXREYXRlKGRhdGUuZ2V0RGF0ZSgpICsgMzIpO1xuICAgICAgcmV0dXJuIGRhdGU7XG4gICAgfTtcbiAgICBjb25zdCBtYXJrcyA9IHN0YXRlX2RhdGEubWFwKChkKSA9PiB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB4OiB4KHhWYWx1ZShkKSksXG4gICAgICAgIHk6IHkoeVZhbHVlKGQpKSxcbiAgICAgICAgZGF0ZTogY29ycmVjdERhdGUoZC5kYXRlKSxcbiAgICAgICAgZG9zZXM6IGQuZGFpbHlfdmFjY2luYXRpb25zLFxuICAgICAgfTtcbiAgICB9KTtcblxuICAgIC8vIGhvdmVyIGFuaW1hdGlvbiBmdW5jdGlvbnNcbiAgICBmdW5jdGlvbiBoYW5kbGVfbW91c2Vfb3ZlcihlLCBkKSB7XG4gICAgICAvLyBjb25zb2xlLmxvZygnbW92ZXInKTtcbiAgICAgIHNlbGVjdGlvblxuICAgICAgICAuc2VsZWN0QWxsKCdyZWN0JylcbiAgICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgICAuZHVyYXRpb24oJzEwMCcpXG4gICAgICAgIC5hdHRyKCdvcGFjaXR5JywgYmFyX29wYWNpdHkgLyAyKTtcbiAgICAgIHNlbGVjdCh0aGlzKVxuICAgICAgICAudHJhbnNpdGlvbigpXG4gICAgICAgIC5kdXJhdGlvbignMTAwJylcbiAgICAgICAgLmF0dHIoJ29wYWNpdHknLCBiYXJfb3BhY2l0eSk7XG4gICAgICBzZWxlY3QoJyN0b29sdGlwJylcbiAgICAgICAgLnN0eWxlKCd2aXNpYmlsaXR5JywgJ3Zpc2libGUnKVxuICAgICAgICAudGV4dChcbiAgICAgICAgICAnRGF0ZTogJyArXG4gICAgICAgICAgICBkLmRhdGUuZ2V0TW9udGgoKSArXG4gICAgICAgICAgICAnLycgK1xuICAgICAgICAgICAgZC5kYXRlLmdldERhdGUoKSArXG4gICAgICAgICAgICAnLCBEb3NlczogJyArXG4gICAgICAgICAgICBkLmRvc2VzXG4gICAgICAgICk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gaGFuZGxlX21vdXNlX21vdmUoZSwgZCkge1xuICAgICAgLy8gY29uc29sZS5sb2coZXZlbnQuUGFnZVgsIGV2ZW50LlBhZ2VZKTtcbiAgICAgIHNlbGVjdCgnI3Rvb2x0aXAnKVxuICAgICAgICAuc3R5bGUoJ3RvcCcsIGV2ZW50LnBhZ2VZIC0gMjUgKyAncHgnKVxuICAgICAgICAuc3R5bGUoJ2xlZnQnLCBldmVudC5wYWdlWCArICdweCcpO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIGhhbmRsZV9tb3VzZV9vdXQoZSwgZCkge1xuICAgICAgc2VsZWN0aW9uXG4gICAgICAgIC5zZWxlY3RBbGwoJ3JlY3QnKVxuICAgICAgICAudHJhbnNpdGlvbigpXG4gICAgICAgIC5kdXJhdGlvbignMTAwJylcbiAgICAgICAgLmF0dHIoJ29wYWNpdHknLCBiYXJfb3BhY2l0eSk7XG4gICAgICBzZWxlY3QoJyN0b29sdGlwJykuc3R5bGUoJ3Zpc2liaWxpdHknLCAnaGlkZGVuJyk7XG4gICAgfVxuICAgIFxuICAgIC8vIGFuaW1hdGlvbiBmdW5jdGlvbnNcbiAgICBjb25zdCB0ID0gdHJhbnNpdGlvbigpLmR1cmF0aW9uKDUwMCk7XG4gICAgY29uc3QgcG9zaXRpb25CYXJzID0gKGJhcnMpID0+IHtcbiAgICAgIGJhcnNcbiAgICAgICAgLmF0dHIoJ3gnLCAoZCkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLnggKyBiYXJfd2lkdGggLyAyO1xuICAgICAgICB9KVxuICAgICAgICAuYXR0cigneScsIChkKSA9PiB7XG4gICAgICAgICAgLy8gcGxhY2UgdGhlIGJvdHRvbSBvZiBlYWNoIGJhciBhdCB0aGUgeC1heGlzXG4gICAgICAgICAgcmV0dXJuIGhlaWdodCAtIG1hcmdpbi5ib3R0b20gLSBkLnk7XG4gICAgICAgIH0pXG4gICAgICAgIC5hdHRyKCdmaWxsJywgYmFyX2NvbG9yKVxuICAgICAgICAuYXR0cignb3BhY2l0eScsIGJhcl9vcGFjaXR5KVxuICAgICAgICAuYXR0cignaGVpZ2h0JywgKGQpID0+IGQueSk7XG4gICAgfTtcblxuICAgIGNvbnN0IHNldF9oYW5kbGVycyA9IChiYXJzKSA9PiB7XG4gICAgICBiYXJzLm9uKCdtb3VzZW92ZXInLCBoYW5kbGVfbW91c2Vfb3Zlcik7XG4gICAgICBiYXJzLm9uKCdtb3VzZW1vdmUnLCBoYW5kbGVfbW91c2VfbW92ZSk7XG4gICAgICBiYXJzLm9uKCdtb3VzZW91dCcsIGhhbmRsZV9tb3VzZV9vdXQpO1xuICAgIH07XG4gICAgXG4gICAgY29uc3QgaW5pdGlhbGl6ZVdpZHRoID0gKGJhcnMpID0+IHtcbiAgICAgIGJhcnMuYXR0cignd2lkdGgnLCAwKTtcbiAgICAgIGJhcnMuYXR0cignaGVpZ2h0JywgMCk7XG4gICAgfTtcbiAgICBjb25zdCBncm93V2lkdGggPSAoZW50ZXIpID0+IHtcbiAgICAgIGVudGVyLnRyYW5zaXRpb24odCkuYXR0cignd2lkdGgnLCBiYXJfd2lkdGgpO1xuICAgICAgZW50ZXIudHJhbnNpdGlvbih0KS5hdHRyKCdoZWlnaHQnLCAoZCkgPT4gZC55KTtcbiAgICB9O1xuXG5cbiAgICAvLyBkcmF3IHRoZSBiYXJzXG4gICAgY29uc3QgYmFycyA9IHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgncmVjdCcpXG4gICAgICAuZGF0YShtYXJrcylcbiAgICAgIC5qb2luKFxuICAgICAgICAoZW50ZXIpID0+XG4gICAgICAgICAgZW50ZXJcbiAgICAgICAgICAgIC5hcHBlbmQoJ3JlY3QnKVxuICAgICAgICBcdFx0LmF0dHIoXCJwb2ludGVyLWV2ZW50c1wiLCBcImFsbFwiKVxuICAgICAgICAgICAgLmNhbGwocG9zaXRpb25CYXJzKVxuICAgICAgICAgICAgLmNhbGwoaW5pdGlhbGl6ZVdpZHRoKVxuICAgICAgICAgICAgLmNhbGwoZ3Jvd1dpZHRoKVxuICAgICAgICBcdFx0LmNhbGwoc2V0X2hhbmRsZXJzKSxcbiAgICAgICAgKHVwZGF0ZSkgPT5cbiAgICAgICAgICB1cGRhdGUuY2FsbCgodXBkYXRlKSA9PlxuICAgICAgICAgICAgdXBkYXRlXG4gICAgICAgICAgICAgIC50cmFuc2l0aW9uKHQpXG4gICAgICAgICAgICAgIC5kZWxheSgoZCwgaSkgPT4gaSAqIDEwKVxuICAgICAgICAgICAgICAuY2FsbChwb3NpdGlvbkJhcnMpXG4gICAgICAgICAgKSxcbiAgICAgICAgKGV4aXQpID0+IGV4aXQucmVtb3ZlKClcbiAgICAgICk7XG4gICAgLy8gcmVkcmF3IHkgYXhpc1xuICAgIHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgnLnktYXhpcycpXG4gICAgICAuZGF0YShbbnVsbF0pXG4gICAgICAuam9pbignZycpXG4gICAgICAuYXR0cignY2xhc3MnLCAneS1heGlzJylcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBgdHJhbnNsYXRlKCR7bWFyZ2luLmxlZnR9LDApYClcbiAgICAgIC50cmFuc2l0aW9uKHQpXG4gICAgICAuY2FsbChheGlzTGVmdCh5MSkpO1xuXG4gICAgLy8gcmVkcmF3IHggYXhpc1xuICAgIHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgnLngtYXhpcycpXG4gICAgICAuZGF0YShbbnVsbF0pXG4gICAgICAuam9pbignZycpXG4gICAgICAuYXR0cignY2xhc3MnLCAneC1heGlzJylcbiAgICAgIC5hdHRyKFxuICAgICAgICAndHJhbnNmb3JtJyxcbiAgICAgICAgYHRyYW5zbGF0ZSgwLCR7aGVpZ2h0IC0gbWFyZ2luLmJvdHRvbX0pYFxuICAgICAgKVxuICAgICAgLnRyYW5zaXRpb24odClcbiAgICAgIC5jYWxsKGF4aXNCb3R0b20oeCkpO1xuICAgIFxuICAgIC8vIGJydXNoaW5nXG4gICAgZnVuY3Rpb24gYnJ1c2hlZChlLCBkKXtcbiAgICAgIGNvbnN0IGJydXNoX2FyZWEgPSBlLnNlbGVjdGlvbjtcbiAgICAgIFxuICAgICAgbGV0IGVuZF9kYXRlID0gbmV3IERhdGUoJzIwMjEtMDktMDQnKTtcbiAgICAgIGlmKGJydXNoX2FyZWEpe1xuICAgICAgICBjb25zdCBzdGFydF9kYXRlID0geC5pbnZlcnQoYnJ1c2hfYXJlYVswXSk7XG4gICAgICBcdGVuZF9kYXRlID0geC5pbnZlcnQoYnJ1c2hfYXJlYVsxXSk7XG4gICAgICB9XG4gICAgICBtYXBfZ3JvdXAuY2FsbChtYXAuc2VsZWN0ZWRfZGF0ZShlbmRfZGF0ZSkpO1xuICAgIH1cbiAgICBjb25zdCBicnVzaCA9IGJydXNoWCgpXG4gICAgICAuZXh0ZW50KFtbMCwwXSwgW3dpZHRoLCBoZWlnaHRdXSlcbiAgICAgIC5vbihcImJydXNoIGVuZFwiLCBicnVzaGVkKTtcbiAgICBzZWxlY3Rpb24uY2FsbChicnVzaCk7XG4gICAgLy8gc2VsZWN0KCcub3ZlcmxheScpLmF0dHIoJ2Rpc3BsYXknLCAnbm9uZScpO1xuICAgIFxuICAgIC8vIEFkZCBheGlzIGxhYmVsc1xuICAgIHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgnLngtYXhpcy1sYWJlbCcpXG4gICAgXHQuZGF0YShbbnVsbF0pXG4gICAgXHQuam9pbigndGV4dCcpXG4gICAgICAuYXR0cigneScsIGhlaWdodCAtIDEwKVxuICAgICAgLmF0dHIoJ3gnLCB3aWR0aCAvIDIgLSAxMClcbiAgICAgIC50ZXh0KCdEYXRlLCAyMDIxJylcbiAgICAgIC5hdHRyKCdmb250LXNpemUnLCBsYWJlbF9zaXplKVxuICAgIFx0LmF0dHIoJ2NsYXNzJywgJ3gtYXhpcy1sYWJlbCcpO1xuICAgIFxuICAgIHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgnLnktYXhpcy1sYWJlbCcpXG4gICAgXHQuZGF0YShbbnVsbF0pXG4gICAgXHQuam9pbigndGV4dCcpXG4gICAgICAuYXR0cigneCcsIDApXG4gICAgICAuYXR0cigneScsIGhlaWdodC8yLTIwKVxuICAgICAgLnRleHQoJ0RhaWx5IERvc2VzIERpc3RyaWJ1dGVkJylcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBgcm90YXRlKDI3MCwgNzAsICR7aGVpZ2h0LzJ9KWApXG4gICAgICAuYXR0cignZm9udC1zaXplJywgbGFiZWxfc2l6ZSlcbiAgICBcdC5hdHRyKCdjbGFzcycsICd5LWF4aXMtbGFiZWwnKTtcbiAgfTtcblxuICBteS53aWR0aCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKHdpZHRoID0gK18pLCBteSkgOiB3aWR0aDtcbiAgfTtcblxuICBteS5oZWlnaHQgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChoZWlnaHQgPSArXyksIG15KSA6IGhlaWdodDtcbiAgfTtcblxuICBteS5kYXRhID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgoZGF0YSA9IF8pLCBteSkgOiBkYXRhO1xuICB9O1xuXG4gIG15LnhWYWx1ZSA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKHhWYWx1ZSA9IF8pLCBteSkgOiB4VmFsdWU7XG4gIH07XG5cbiAgbXkueVZhbHVlID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgoeVZhbHVlID0gXyksIG15KSA6IHlWYWx1ZTtcbiAgfTtcblxuICBteS5tYXJnaW4gPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChtYXJnaW4gPSBfKSwgbXkpIDogbWFyZ2luO1xuICB9O1xuXG4gIG15LmJhcl93aWR0aCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGhcbiAgICAgID8gKChiYXJfd2lkdGggPSArXyksIG15KVxuICAgICAgOiBiYXJfd2lkdGg7XG4gIH07XG5cbiAgbXkuYmFyX29wYWNpdHkgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoXG4gICAgICA/ICgoYmFyX29wYWNpdHkgPSArXyksIG15KVxuICAgICAgOiBiYXJfb3BhY2l0eTtcbiAgfTtcblxuICBteS5iYXJfY29sb3IgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoXG4gICAgICA/ICgoYmFyX2NvbG9yID0gXyksIG15KVxuICAgICAgOiBiYXJfY29sb3I7XG4gIH07XG5cbiAgbXkuc2VsZWN0ZWRfc3RhdGUgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoXG4gICAgICA/ICgoc2VsZWN0ZWRfc3RhdGUgPSBfKSwgbXkpXG4gICAgICA6IHNlbGVjdGVkX3N0YXRlO1xuICB9O1xuICBcbiAgbXkubGFiZWxfc2l6ZSA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGhcbiAgICAgID8gKChsYWJlbF9zaXplID0gXyksIG15KVxuICAgICAgOiBsYWJlbF9zaXplO1xuICB9O1xuICBcbiAgbXkubWFwX2dyb3VwID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgobWFwX2dyb3VwID0gXyksIG15KSA6IG1hcF9ncm91cDtcbiAgfTtcbiAgXG4gIG15Lm1hcCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKG1hcCA9IF8pLCBteSkgOiBtYXA7XG4gIH07XG5cbiAgcmV0dXJuIG15O1xufTtcbiIsImltcG9ydCB7IGRpc3BhdGNoIH0gZnJvbSAnZDMnO1xuZXhwb3J0IGNvbnN0IG1lbnUgPSAoKSA9PiB7XG4gIGxldCBpZDtcbiAgbGV0IGxhYmVsVGV4dDtcbiAgbGV0IG9wdGlvbnM7XG4gIGNvbnN0IGxpc3RlbmVycyA9IGRpc3BhdGNoKCdjaGFuZ2UnKTtcbiAgXG4gIGNvbnN0IG15ID0gKHNlbGVjdGlvbikgPT4ge1xuICAgIHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgnbGFiZWwnKVxuICAgICAgLmRhdGEoW251bGxdKVxuICAgICAgLmpvaW4oJ2xhYmVsJylcbiAgICAgIC5hdHRyKCdmb3InLCBpZClcbiAgICAgIC50ZXh0KGxhYmVsVGV4dCk7XG5cbiAgICBzZWxlY3Rpb25cbiAgICAgIC5zZWxlY3RBbGwoJ3NlbGVjdCcpXG4gICAgICAuZGF0YShbbnVsbF0pXG4gICAgICAuam9pbignc2VsZWN0JylcbiAgICAgIC5hdHRyKCdpZCcsIGlkKVxuICAgICAgLm9uKCdjaGFuZ2UnLCAoZXZlbnQpID0+IHtcbiAgICAgICAgbGlzdGVuZXJzLmNhbGwoJ2NoYW5nZScsIG51bGwsIGV2ZW50LnRhcmdldC52YWx1ZSk7XG4gICAgICB9KVxuICAgICAgLnNlbGVjdEFsbCgnb3B0aW9uJylcbiAgICAgIC5kYXRhKG9wdGlvbnMpXG4gICAgICAuam9pbignb3B0aW9uJylcbiAgICAgIC5hdHRyKCd2YWx1ZScsIChkKSA9PiBkLnZhbHVlKVxuICAgICAgLnRleHQoKGQpID0+IGQudGV4dCk7XG4gIH07XG5cbiAgbXkuaWQgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChpZCA9IF8pLCBteSkgOiBpZDtcbiAgfTtcblxuICBteS5sYWJlbFRleHQgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoXG4gICAgICA/ICgobGFiZWxUZXh0ID0gXyksIG15KVxuICAgICAgOiBsYWJlbFRleHQ7XG4gIH07XG5cbiAgbXkub3B0aW9ucyA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKG9wdGlvbnMgPSBfKSwgbXkpIDogb3B0aW9ucztcbiAgfTtcblxuICBteS5vbiA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgdmFsdWUgPSBsaXN0ZW5lcnMub24uYXBwbHkobGlzdGVuZXJzLCBhcmd1bWVudHMpO1xuICAgIHJldHVybiB2YWx1ZSA9PT0gbGlzdGVuZXJzID8gbXkgOiB2YWx1ZTtcbiAgfTtcblxuICByZXR1cm4gbXk7XG59O1xuIiwiaW1wb3J0IHtcbiAgbWF4LFxuICBnZW9BbGJlcnNVc2EsXG4gIGdlb1BhdGgsXG4gIHNlbGVjdFxufSBmcm9tICdkMyc7XG5pbXBvcnQgeyBtZW51IH0gZnJvbSAnLi9tZW51JztcblxuZXhwb3J0IGNvbnN0IHN0YXRlTWVudSA9ICgpID0+IHtcbiAgbGV0IHdpZHRoO1xuICBsZXQgaGVpZ2h0O1xuICBsZXQgZGF0YTtcbiAgbGV0IHBsb3Q7XG4gIFxuICBjb25zdCBteSA9IChzZWxlY3Rpb24pID0+IHtcbiAgICBjb25zdCBtZW51Q29udGFpbmVyID0gc2VsZWN0KCdib2R5JylcbiAgICBcdC5hcHBlbmQoJ2RpdicpXG4gICAgXHQuYXR0cignY2xhc3MnLCAnbWVudS1jb250YWluZXInKTtcbiAgICBjb25zdCBzdGF0ZV9tZW51ID0gbWVudUNvbnRhaW5lci5hcHBlbmQoJ2RpdicpO1xuICAgIGNvbnN0IHlNZW51ID0gbWVudUNvbnRhaW5lci5hcHBlbmQoJ2RpdicpO1xuICAgIFxuICAgIGZ1bmN0aW9uIG9ubHlVbmlxdWUodmFsdWUsIGluZGV4LCBzZWxmKSB7XG4gICAgICByZXR1cm4gc2VsZi5pbmRleE9mKHZhbHVlKSA9PT0gaW5kZXg7XG4gICAgfVxuICAgIGNvbnN0IHN0YXRlcyA9IGRhdGFcbiAgICAgIC5tYXAoKGQpID0+IGQubG9jYXRpb24pXG4gICAgICAuZmlsdGVyKG9ubHlVbmlxdWUpO1xuICAgIGNvbnN0IG9wdGlvbnMgPSBzdGF0ZXMubWFwKChkKSA9PiB7XG4gICAgICByZXR1cm4geyB2YWx1ZTogZCwgdGV4dDogZCB9O1xuICAgIH0pO1xuICAgIFxuICAgIHN0YXRlX21lbnUuY2FsbChcbiAgICAgIG1lbnUoKVxuICAgICAgICAuaWQoJ3N0YXRlLW1lbnUnKVxuICAgICAgICAubGFiZWxUZXh0KCdTdGF0ZTonKVxuICAgICAgICAub3B0aW9ucyhvcHRpb25zKVxuICAgICAgICAub24oJ2NoYW5nZScsIChzdGF0ZSkgPT4ge1xuICAgICAgICAgIHNlbGVjdGlvbi5jYWxsKFxuICAgICAgICAgICAgcGxvdC5zZWxlY3RlZF9zdGF0ZShzdGF0ZSlcbiAgICAgICAgICApO1xuICAgICAgICB9KVxuICAgICk7XG4gIH07XG5cbiAgbXkuZGF0YSA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKGRhdGEgPSBfKSwgbXkpIDogZGF0YTtcbiAgfTtcbiAgICBcbiAgbXkucGxvdCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKHBsb3QgPSBfKSwgbXkpIDogcGxvdDtcbiAgfTtcbiAgXG4gIHJldHVybiBteTtcbn07XG4iLCJpbXBvcnQge1xuICBtYXgsXG4gIGdlb0FsYmVyc1VzYSxcbiAgZ2VvUGF0aCxcbiAgdG9wanNvbixcbiAgdHJhbnNpdGlvbixcbiAgZm9yY2VTaW11bGF0aW9uLFxuICBmb3JjZUNvbGxpZGUsXG4gIGZvcmNlWCxcbiAgZm9yY2VZLFxuICBhcmMsXG4gIHNjYWxlU3FydCxcbiAgc2VsZWN0XG59IGZyb20gJ2QzJztcblxuXG5cblxuXG5leHBvcnQgY29uc3QgbWFwRWxlbWVudCA9ICgpID0+IHtcbiAgbGV0IHdpZHRoO1xuICBsZXQgaGVpZ2h0O1xuICBsZXQgZGF0YTtcbiAgbGV0IG1hcF9kYXRhO1xuICBsZXQgc3RhdGVfY2VudHJvaWRzO1xuICBsZXQgc2VsZWN0ZWRfZGF0ZTtcbiAgbGV0IG1hcmtzO1xuICBsZXQgdG9vbHRpcDtcbiAgbGV0IHBsb3Q7XG4gIGxldCBwbG90X2dyb3VwO1xuICBsZXQgc3RhdGVzX2xpc3Q7XG4gIFxuICBmdW5jdGlvbiBtYXBfbW91c2VfbW92ZShlLGQpIHtcbiAgICB0b29sdGlwXG4gICAgICAuc3R5bGUoJ3RvcCcsIGV2ZW50LnBhZ2VZIC0gMTAgKyAncHgnKVxuICAgICAgLnN0eWxlKCdsZWZ0JywgZXZlbnQucGFnZVggKyAxMCArICdweCcpO1xuICB9XG5cbiAgZnVuY3Rpb24gbWFwX21vdXNlX29uKGUsZCl7XG4gICAgLy8gaG92ZXIgb24gZG91Z251dCBwbG90IGdyb3VwXG4gICAgaWYoZC5sb2NhdGlvbil7XG4gICAgICB0b29sdGlwXG4gICAgICAuaHRtbChcbiAgICAgICAgYFN0YXRlOiAke2QubG9jYXRpb259YFxuICAgICAgKVxuICAgICAgLnN0eWxlKCd2aXNpYmlsaXR5JywgJ3Zpc2libGUnKTtcbiAgICB9XG4gICAgLy8gaG92ZXIgb24gc3RhdGUgcGF0aFxuICAgIGlmKGQucHJvcGVydGllcyl7XG4gICAgICB0b29sdGlwXG4gICAgICAuaHRtbChcbiAgICAgICAgYFN0YXRlOiAke2QucHJvcGVydGllcy5uYW1lfWBcbiAgICAgIClcbiAgICAgIC5zdHlsZSgndmlzaWJpbGl0eScsICd2aXNpYmxlJyk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gbWFwX21vdXNlX291dChlLGQpIHtcbiAgICAgIHRvb2x0aXAuaHRtbChgYCkuc3R5bGUoJ3Zpc2liaWxpdHknLCAnaGlkZGVuJyk7XG4gIH1cblxuICBmdW5jdGlvbiB1cGRhdGVfZHJvcGRvd24oc2VsZWN0ZWRfc3RhdGUpe1xuICAgIGlmKGRhdGEpe1xuICAgIFx0Y29uc3Qgc3RhdGVfaW5kZXggPSBzdGF0ZXNfbGlzdC5maW5kSW5kZXgoKGYpID0+IHsgcmV0dXJuIGYgPiBzZWxlY3RlZF9zdGF0ZSB9KTtcbiAgICBcdGNvbnN0IGRyb3Bkb3duID0gc2VsZWN0KCcjc3RhdGUtbWVudScpO1xuICAgIFx0ZHJvcGRvd24ucHJvcGVydHkoJ3NlbGVjdGVkSW5kZXgnLCBzdGF0ZV9pbmRleC0xKTtcbiAgICB9XG4gIH1cbiAgXG4gIGZ1bmN0aW9uIG1hcF9tb3VzZV9jbGljayhlLGQpIHtcbiAgICAvLyBjbGljayBvbiBkb3VnbnV0IHBsb3QgZ3JvdXBcbiAgICBpZihkLmxvY2F0aW9uKXtcbiAgICAgIHBsb3RfZ3JvdXAuY2FsbChcbiAgICAgICAgcGxvdC5zZWxlY3RlZF9zdGF0ZShkLmxvY2F0aW9uKVxuICAgICAgKTtcbiAgICAgIHVwZGF0ZV9kcm9wZG93bihkLmxvY2F0aW9uKVxuICAgIH1cbiAgICAvLyBjbGljayBvbiBzdGF0ZSBwYXRoXG4gICAgaWYoZC5wcm9wZXJ0aWVzKXtcbiAgICAgIHBsb3RfZ3JvdXAuY2FsbChcbiAgICAgICAgcGxvdC5zZWxlY3RlZF9zdGF0ZShkLnByb3BlcnRpZXMubmFtZSlcbiAgICAgICk7XG4gICAgICB1cGRhdGVfZHJvcGRvd24oZC5wcm9wZXJ0aWVzLm5hbWUpXG4gICAgfVxuICB9XG4gIFxuICBcbiAgY29uc3QgbXkgPSAoc2VsZWN0aW9uKSA9PiB7XG4gIFx0Y29uc3QgcHJvamVjdGlvbiA9IGdlb0FsYmVyc1VzYSgpO1xuICAgIGNvbnN0IHBhdGggPSBnZW9QYXRoKHByb2plY3Rpb24pO1xuICAgIFxuICAgIGNvbnN0IHN0YXRlcyA9IHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgncGF0aCcpXG4gICAgICAuZGF0YSh0b3BvanNvbi5mZWF0dXJlKG1hcF9kYXRhLCBtYXBfZGF0YS5vYmplY3RzLnN0YXRlcykuZmVhdHVyZXMpXG4gICAgICAuam9pbihcbiAgICAgICAgKGVudGVyKSA9PlxuICAgICAgICAgIGVudGVyXG4gICAgICAgICAgICAuYXBwZW5kKCdwYXRoJylcbiAgICAgICAgICAgIC5hdHRyKCdkJywgcGF0aClcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiBkLnByb3BlcnRpZXMubmFtZSlcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiBkLmxvY2F0aW9uKVxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZScsICdibGFjaycpXG4gICAgICAgICAgICAuYXR0cignZmlsbCcsICdsaWdodGdyYXknKVxuICAgICAgICBcdFx0Lm9uKCdtb3VzZW92ZXInLCBtYXBfbW91c2Vfb24pXG4gICAgICAgIFx0XHQub24oJ21vdXNlbW92ZScsIG1hcF9tb3VzZV9tb3ZlKVxuICAgICAgICBcdFx0Lm9uKCdtb3VzZW91dCcsIG1hcF9tb3VzZV9vdXQpXG4gICAgICAgIFx0XHQub24oJ21vdXNlZG93bicsIG1hcF9tb3VzZV9jbGljayksXG4gICAgICAgICh1cGRhdGUpID0+XG4gICAgICAgICAgdXBkYXRlLmNhbGwoKHVwZGF0ZSkgPT51cGRhdGUpLFxuICAgICAgICAoZXhpdCkgPT4gZXhpdC5yZW1vdmUoKVxuICAgICAgKTtcbiAgICBcbiAgICAvLyBjb25zdCBzZWxlY3RlZF9kYXRlID0gbmV3IERhdGUoJzIwMjEtMDktMDQnKTtcbiAgICBmdW5jdGlvbiBmaWx0ZXJfZGF0ZShsaXN0KSB7XG4gICAgICByZXR1cm4gbGlzdC5kYXRlLmdldERhdGUoKSA9PSBzZWxlY3RlZF9kYXRlLmdldERhdGUoKSYmIFxuICAgICAgICBsaXN0LmRhdGUuZ2V0TW9udGgoKSA9PSBzZWxlY3RlZF9kYXRlLmdldE1vbnRoKCkmJiBcbiAgICAgICAgbGlzdC5kYXRlLmdldEZ1bGxZZWFyKCkgPT0gc2VsZWN0ZWRfZGF0ZS5nZXRGdWxsWWVhcigpO1xuICAgIH1cbiAgICBjb25zdCBkYXRlX2RhdGEgPSBkYXRhLmZpbHRlcihmaWx0ZXJfZGF0ZSk7ICBcbiAgICBcbiAgICBsZXQgbXlfc3RhdGUgPSBcIkNhbGlmb3JuaWFcIlxuICAgIGZ1bmN0aW9uIGdldF9zdGF0ZV9jZW50cm9pZChjZW50cm9pZHMpIHtcbiAgICAgIHJldHVybiBjZW50cm9pZHMubmFtZSA9PSBteV9zdGF0ZTtcbiAgICB9XG5cbiAgICBsZXQgbWFya3MgPSBkYXRlX2RhdGEubWFwKChkKSA9PiB7XG4gICAgICBteV9zdGF0ZSA9IGQubG9jYXRpb247XG4gICAgICBjb25zdCBjZW50ZXIgPSBzdGF0ZV9jZW50cm9pZHMuZmlsdGVyKGdldF9zdGF0ZV9jZW50cm9pZClbMF07XG4gICAgICBpZihjZW50ZXIpXG4gICAgICAgIHJldHVybiB7IFxuICAgICAgICAgIGxvY2F0aW9uIDogZC5sb2NhdGlvbixcbiAgICAgICAgICBsYXQgOiBjZW50ZXIubGF0LFxuICAgICAgICAgIGxvbiA6IGNlbnRlci5sb24sXG4gICAgICAgICAgZnVsbCA6IGQucGVvcGxlX2Z1bGx5X3ZhY2NpbmF0ZWRfcGVyX2h1bmRyZWQsXG4gICAgICAgICAgcGFydCA6IGQucGVvcGxlX3ZhY2NpbmF0ZWRfcGVyX2h1bmRyZWQsXG4gICAgICAgICAgZG9zZXMgOiBkLnNoYXJlX2Rvc2VzX3VzZWRcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIFxuICAgIG1hcmtzID0gbWFya3MuZmlsdGVyKGZ1bmN0aW9uKCBlbGVtZW50ICkge1xuICAgICByZXR1cm4gZWxlbWVudCAhPT0gdW5kZWZpbmVkO1xuICAgIH0pO1xuXG4gICAgY29uc3QgaGlnaGVzdF92YWNjID0gbWF4KG1hcmtzLCBmdW5jdGlvbiAoZCkge1xuICAgICAgICByZXR1cm4gZC5mdWxsO1xuICAgIH0pO1xuICAgIFxuICAgIC8vIEFSQyBTVFVGRlxuICAgIGxldCByaW5nX3dpZHRoID0gNztcbiAgICBsZXQgcmluZ19yYWRpdXMgPSAxMjtcbiAgICBmdW5jdGlvbiBnZW5lcmF0ZUFyYyhkLCBiYXNlX3JhZGl1cywgdmFsdWUpIHtcbiAgICBcdGxldCBpbm5lciA9IGJhc2VfcmFkaXVzO1xuICAgICAgbGV0IG91dGVyID0gYmFzZV9yYWRpdXMgKyByaW5nX3dpZHRoO1xuICAgICAgbGV0IGFuZ2xlID0gKHZhbHVlKGQpIC8gMTAwKSAqIDIqTWF0aC5QSTtcbiAgICAgIGxldCBhcmNHZW4gPSBhcmMoKVxuICAgICAgICAuaW5uZXJSYWRpdXMoaW5uZXIpXG4gICAgICAgIC5vdXRlclJhZGl1cyhvdXRlcilcbiAgICAgICAgLnN0YXJ0QW5nbGUoMClcbiAgICAgICAgLmVuZEFuZ2xlKGFuZ2xlKTtcbiAgICAgIHJldHVybiBhcmNHZW4oZCk7XG4gICAgfVxuICAgIC8vIEVORCBBUkMgU1RVRkZcbiAgXG4gICAgY29uc3QgY2lyY2xlUmFkaXVzID0gZDNcbiAgICAgIC5zY2FsZVNxcnQoKVxuICAgICAgLmRvbWFpbihbMCwgaGlnaGVzdF92YWNjXSlcbiAgICAgIC5yYW5nZShbMCwgMjVdKTsgLy8gMCB0byBtYXhpbXVtIHJhZGl1cyBpbiBwaXhlbHNcbiAgICBcbiAgIFx0ZnVuY3Rpb24gcmFkaXVzIChkKSB7IFxuICAgICAgIHJldHVybiByaW5nX3JhZGl1cztcbiAgICB9XHRcblxuICAgIHZhciBzaW11bGF0aW9uID0gZm9yY2VTaW11bGF0aW9uKG1hcmtzKVxuICAgICAgLmZvcmNlKFwieFwiLCBmb3JjZVgoZnVuY3Rpb24oZCkge1xuICAgICAgICByZXR1cm4gcHJvamVjdGlvbihbK2QubG9uLCtkLmxhdF0pWzBdO1xuICAgICAgfSkpXG4gICAgICAuZm9yY2UoXCJ5XCIsIGZvcmNlWShmdW5jdGlvbihkKSB7XG4gICAgICAgIHJldHVybiBwcm9qZWN0aW9uKFsrZC5sb24sK2QubGF0XSlbMV07XG4gICAgICB9KSlcbiAgICAgIC5mb3JjZShcImNvbGxpZGVcIiwgZm9yY2VDb2xsaWRlKGQgPT4gcmFkaXVzKGQpICsgcmluZ193aWR0aCoyICsgMSkpXG4gICAgICAuc3RvcCgpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMTIwOyArK2kpIHNpbXVsYXRpb24udGljaygpO1xuICAgICAgIFxuICAgIFxuICAgIGNvbnN0IHZhY2NfdmFsdWUgPSAoZCkgPT4gZC5mdWxsO1xuICAgIGNvbnN0IGRvc2VfdmFsdWUgPSAoZCkgPT4gZC5kb3NlcyAqIDEwMDtcbiAgICBcbiAgICBmdW5jdGlvbiBkcmF3bWFyayAoZW50ZXIpe1xuICAgICAgbGV0IGcgPSBlbnRlci5hcHBlbmQoJ2cnKS5hdHRyKCdjbGFzcycsICdtYXJrcycpO1xuICAgICAgXG4gICAgICBnLmFwcGVuZCgnY2lyY2xlJylcbiAgICAgIFx0XHQuYXR0cignY2xhc3MnLCAnY2lyY2xlcycpXG4gICAgICAgICAgLmF0dHIoJ2N4JywgKGQpID0+IGQueClcbiAgICAgICAgICAuYXR0cignY3knLCAoZCkgPT4gZC55KVxuICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiBkLmxvY2F0aW9uKVxuICAgICAgICAgIC5hdHRyKCdmaWxsJywgJyNlMGRjZGMnKVxuICAgICAgICAgIC5hdHRyKCdzdHJva2UnLCAnYmxhY2snKVxuICAgICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCAyKVxuICAgICAgICAgIC5hdHRyKCdvcGFjaXR5JywgMSlcbiAgICAgICAgICAuYXR0cigncicsIGQgPT4gcmFkaXVzKGQpICsgcmluZ193aWR0aCoyKTtcbiAgICAgIFxuICAgICAgZy5hcHBlbmQoXCJ0ZXh0XCIpXG4gICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ3ZhY2MtdGV4dCcpXG4gICAgICAgICAgLmF0dHIoJ3gnLCAoZCkgPT4gZC54IC0gMTApXG4gICAgICAgICAgLmF0dHIoJ3knLCAoZCkgPT4gZC55ICsgNSlcbiAgICAgICAgICAudGV4dCgoZCkgPT4gXCJcIiArIHBhcnNlSW50KGQuZnVsbCkpO1xuICAgICAgXG4gICAgICBnLmFwcGVuZChcInBhdGhcIilcbiAgICAgICAgICAuYXR0cignY2xhc3MnLCAndmFjYy1yaW5ncycpXG4gICAgICAgICAgLmF0dHIoXCJkXCIsIGQgPT4ge3JldHVybiBnZW5lcmF0ZUFyYyhkLCByaW5nX3JhZGl1cywgdmFjY192YWx1ZSl9KVxuICAgICAgICAgIC5hdHRyKFwidHJhbnNmb3JtXCIsIGQgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIFwidHJhbnNsYXRlKFwiICsgW2QueCwgZC55XSArIFwiKVwiO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ2lkJywgKGQpID0+IGQubG9jYXRpb24pXG4gICAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnYmx1ZScpXG4gICAgICBcbiAgICAgIGcuYXBwZW5kKFwicGF0aFwiKVxuICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdkb3NlLXJpbmdzJylcbiAgICAgICAgICAuYXR0cihcImRcIiwgZCA9PiB7cmV0dXJuIGdlbmVyYXRlQXJjKGQsIHJpbmdfd2lkdGggKyByaW5nX3JhZGl1cywgZG9zZV92YWx1ZSl9KVxuICAgICAgICAgIC5hdHRyKFwidHJhbnNmb3JtXCIsIGQgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIFwidHJhbnNsYXRlKFwiICsgW2QueCwgZC55XSArIFwiKVwiO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ2lkJywgKGQpID0+IGQubG9jYXRpb24pXG4gICAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnZ3JlZW4nKTtcbiAgICAgIFxuICAgICAgZy5vbignbW91c2VvdmVyJywgbWFwX21vdXNlX29uKTtcbiAgICAgIGcub24oJ21vdXNlbW92ZScsIG1hcF9tb3VzZV9tb3ZlKTtcbiAgICAgIGcub24oJ21vdXNlb3V0JywgbWFwX21vdXNlX291dCk7XG4gICAgICBnLm9uKCdtb3VzZWRvd24nLCBtYXBfbW91c2VfY2xpY2spO1xuICAgICAgXG4gICAgICByZXR1cm4gZztcbiAgICB9XG4gICAgXG4gICAgZnVuY3Rpb24gdXBkYXRlbWFyayh1cGRhdGUpe1xuICAgICAgc2VsZWN0aW9uLnNlbGVjdEFsbCgnLnZhY2MtdGV4dCcpLmRhdGEobWFya3MpXG4gICAgICAgIC50ZXh0KChkKSA9PiBcIlwiICsgcGFyc2VJbnQoZC5mdWxsKSk7XG4gICAgICBcbiAgICAgIHNlbGVjdGlvbi5zZWxlY3RBbGwoJy5tYXJrcycpLmRhdGEobWFya3MpXG4gICAgICAgIC5hcHBlbmQoXCJwYXRoXCIpXG4gICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ3ZhY2MtcmluZ3MnKVxuICAgICAgICAgIC5hdHRyKFwiZFwiLCBkID0+IHtyZXR1cm4gZ2VuZXJhdGVBcmMoZCwgcmluZ19yYWRpdXMsIHZhY2NfdmFsdWUpfSlcbiAgICAgICAgICAuYXR0cihcInRyYW5zZm9ybVwiLCBkID0+IHtcbiAgICAgICAgICAgIHJldHVybiBcInRyYW5zbGF0ZShcIiArIFtkLngsIGQueV0gKyBcIilcIjtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiBkLmxvY2F0aW9uKVxuICAgICAgICAgIC5hdHRyKCdmaWxsJywgJ2JsdWUnKTtcbiAgICAgIFxuICAgICAgc2VsZWN0aW9uLnNlbGVjdEFsbCgnLm1hcmtzJykuYXBwZW5kKFwicGF0aFwiKVxuICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdkb3NlLXJpbmdzJylcbiAgICAgICAgICAuYXR0cihcImRcIiwgZCA9PiB7cmV0dXJuIGdlbmVyYXRlQXJjKGQsIHJpbmdfd2lkdGggKyByaW5nX3JhZGl1cywgZG9zZV92YWx1ZSl9KVxuICAgICAgICAgIC5hdHRyKFwidHJhbnNmb3JtXCIsIGQgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIFwidHJhbnNsYXRlKFwiICsgW2QueCwgZC55XSArIFwiKVwiO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ2lkJywgKGQpID0+IGQubG9jYXRpb24pXG4gICAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnZ3JlZW4nKTtcbiAgICB9XG4gICAgXG4gICAgY29uc3QgZ3JvdXBzICA9IHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgnLm1hcmtzJylcbiAgICAgIC5kYXRhKG1hcmtzKVxuICAgIFx0LmpvaW4oXG4gICAgICAgIChlbnRlcikgPT4gZHJhd21hcmsoZW50ZXIpLFxuICAgICAgICAodXBkYXRlKSA9PiB1cGRhdGVtYXJrKHVwZGF0ZSksXG4gICAgICAgIChleGl0KSA9PiBleGl0LnJlbW92ZSgpXG4gICAgICApO1xuICB9O1xuICBcbiAgbXkuZGF0YSA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKGRhdGEgPSBfKSwgbXkpIDogZGF0YTtcbiAgfTtcbiAgXG4gIG15Lm1hcF9kYXRhID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgobWFwX2RhdGEgPSBfKSwgbXkpIDogbWFwX2RhdGE7XG4gIH07XG4gIFxuICBteS5zdGF0ZV9jZW50cm9pZHMgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChzdGF0ZV9jZW50cm9pZHMgPSBfKSwgbXkpIDogc3RhdGVfY2VudHJvaWRzO1xuICB9O1xuICBcbiAgbXkuc2VsZWN0ZWRfZGF0ZSA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKHNlbGVjdGVkX2RhdGUgPSBfKSwgbXkpIDogc2VsZWN0ZWRfZGF0ZTtcbiAgfTtcbiAgXG4gIG15LnBsb3QgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChwbG90ID0gXyksIG15KSA6IHBsb3Q7XG4gIH07XG4gIFxuICBteS5wbG90X2dyb3VwID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgocGxvdF9ncm91cCA9IF8pLCBteSkgOiBwbG90X2dyb3VwO1xuICB9O1xuICBcbiAgbXkudG9vbHRpcCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKHRvb2x0aXAgPSBfKSwgbXkpIDogdG9vbHRpcDtcbiAgfTtcbiAgXG4gIG15LnN0YXRlc19saXN0ID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgoc3RhdGVzX2xpc3QgPSBfKSwgbXkpIDogc3RhdGVzX2xpc3Q7XG4gIH07XG4gIFxuICBzdGF0ZXNfbGlzdFxuICBcbiAgcmV0dXJuIG15O1xufTtcbiIsImNvbnN0IHsgXG4gIGNzdixcbiAgc2VsZWN0LFxuICBqc29uLFxuICBicnVzaFhcbn0gPSBkMztcbmltcG9ydCB7IGludGVyYWN0aXZlQmFyIH0gZnJvbSAnLi9pbnRlcmFjdGl2ZUJhcic7XG5pbXBvcnQgeyBzdGF0ZU1lbnUgfSBmcm9tICcuL3N0YXRlTWVudSc7XG5pbXBvcnQgeyBtYXBFbGVtZW50IH0gZnJvbSAnLi9tYXBFbGVtZW50JztcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuXG4vLyBkYXRhIHNvdXJjZSB1cmxcbmNvbnN0IGNzdlVybCA9IFtcbiAgJ2h0dHBzOi8vZ2lzdC5naXRodWJ1c2VyY29udGVudC5jb20vJyxcbiAgJ1BldGVyVmFuTm9zdHJhbmQvJywgLy8gVXNlclxuICAnZDQ0OWIwYTNlNTkxNDI3OGRmYTc5YmE2MGU0OGRmNWQvJywgLy8gSWQgb2YgdGhlIEdpc3RcbiAgJ3Jhdy8nLCAvLyBjb21taXRcbiAgJ3ZhY2NpbmVfZGF0YS5jc3YnLCAvLyBGaWxlIG5hbWVcbl0uam9pbignJyk7XG5cbmNvbnN0IGpzb25VUkwgPSBbXG5cdCdodHRwczovL2dpc3QuZ2l0aHVidXNlcmNvbnRlbnQuY29tLycsXG4gICdQZXRlclZhbk5vc3RyYW5kLycsXG4gICdkNDQ5YjBhM2U1OTE0Mjc4ZGZhNzliYTYwZTQ4ZGY1ZC8nLFxuICAncmF3LycsXG4gICdzdGF0ZV9jZW50cm9pZHMuanNvbidcbl0uam9pbignJylcblxuY29uc3QgbWFwVVJMID0gJ2h0dHBzOi8vdW5wa2cuY29tL3VzLWF0bGFzQDMuMC4wL3N0YXRlcy0xMG0uanNvbidcblxuLy8gcGFyc2luZyB0aGUgZGF0YXNldFxuY29uc3QgcGFyc2VSb3cgPSAoZCkgPT4ge1xuICBkLmRhdGUgPSBuZXcgRGF0ZShkLmRhdGUpO1xuICBkLnRvdGFsX3ZhY2NpbmF0aW9ucyA9ICtkLnRvdGFsX3ZhY2NpbmF0aW9ucztcbiAgZC50b3RhbF9kaXN0cmlidXRlZCA9ICtkLnRvdGFsX2Rpc3RyaWJ1dGVkO1xuICBkLnBlb3BsZV92YWNjaW5hdGVkID0gK2QucGVvcGxlX3ZhY2NpbmF0ZWQ7XG4gIGQucGVvcGxlX2Z1bGx5X3ZhY2NpbmF0ZWRfcGVyX2h1bmRyZWQgPSArZC5wZW9wbGVfZnVsbHlfdmFjY2luYXRlZF9wZXJfaHVuZHJlZDtcbiAgZC50b3RhbF92YWNjaW5hdGlvbnNfcGVyX2h1bmRyZWQgPSArZC50b3RhbF92YWNjaW5hdGlvbnNfcGVyX2h1bmRyZWQ7XG4gIGQucGVvcGxlX2Z1bGx5X3ZhY2NpbmF0ZWQgPSArZC5wZW9wbGVfZnVsbHlfdmFjY2luYXRlZDtcbiAgZC5wZW9wbGVfdmFjY2luYXRlZF9wZXJfaHVuZHJlZCA9ICtkLnBlb3BsZV92YWNjaW5hdGVkX3Blcl9odW5kcmVkO1xuICBkLmRpc3RyaWJ1dGVkX3Blcl9odW5kcmVkID0gK2QuZGlzdHJpYnV0ZWRfcGVyX2h1bmRyZWQ7XG4gIGQuZGFpbHlfdmFjY2luYXRpb25zX3JhdyA9ICtkLmRhaWx5X3ZhY2NpbmF0aW9uc19yYXc7XG4gIGQuZGFpbHlfdmFjY2luYXRpb25zID0gK2QuZGFpbHlfdmFjY2luYXRpb25zO1xuICBkLmRhaWx5X3ZhY2NpbmF0aW9uc19wZXJfbWlsbGlvbiA9ICtkLmRhaWx5X3ZhY2NpbmF0aW9uc19wZXJfbWlsbGlvbjtcbiAgZC5zaGFyZV9kb3Nlc191c2VkID0gK2Quc2hhcmVfZG9zZXNfdXNlZDtcbiAgcmV0dXJuIGQ7XG59O1xuXG4vLyBTZWxlY3QgdGhlIFNWRyBlbGVtZW50XG5jb25zdCB3aWR0aCA9IHdpbmRvdy5pbm5lcldpZHRoO1xuY29uc3QgaGVpZ2h0ID0gd2luZG93LmlubmVySGVpZ2h0O1xuXG5jb25zdCBzdmcgPSBzZWxlY3QoJ2JvZHknKVxuICAuYXBwZW5kKCdzdmcnKVxuICAuYXR0cignd2lkdGgnLCB3aWR0aCAtIDMwMClcbiAgLmF0dHIoJ2hlaWdodCcsIGhlaWdodCAtIDIwMClcblx0LmF0dHIoJ2NsYXNzJywgJ21hcF9zdmcnKTtcblxuY29uc3Qgc3ZnMiA9IHNlbGVjdCgnYm9keScpXG4gIC5hcHBlbmQoJ3N2ZycpXG4gIC5hdHRyKCd3aWR0aCcsIHdpZHRoIC0gMjApXG4gIC5hdHRyKCdoZWlnaHQnLCAxODApXG5cdC5hdHRyKCdjbGFzcycsICdiYXJfc3ZnJyk7XG5cbnZhciB0b29sdGlwID0gc2VsZWN0KCdib2R5JylcbiAgLmFwcGVuZCgnZGl2Jylcblx0LmFwcGVuZCgnZGl2JylcbiAgICAuYXR0cignaWQnLCAndG9vbHRpcCcpXG5cdFx0LmF0dHIoJ2NsYXNzJywgJ3Rvb2x0aXAtY29udGFpbmVyJylcbiAgICAuc3R5bGUoJ3Bvc2l0aW9uJywnYWJzb2x1dGUnKVxuICAgIC5zdHlsZSgndmlzaWJpbGl0eScsICdoaWRkZW4nKTtcblxuY29uc3QgbWFwX3Rvb2x0aXAgPSBzZWxlY3QoJ2JvZHknKVxuICAuYXBwZW5kKCdkaXYnKVxuICAuYXR0cignY2xhc3MnLCAnZDMtdG9vbHRpcCcpXG4gIC5zdHlsZSgncG9zaXRpb24nLCAnYWJzb2x1dGUnKVxuICAuc3R5bGUoJ3otaW5kZXgnLCAnMTAnKVxuICAuc3R5bGUoJ3Zpc2liaWxpdHknLCAnaGlkZGVuJylcbiAgLnN0eWxlKCdwYWRkaW5nJywgJzEwcHgnKVxuICAuc3R5bGUoJ2JhY2tncm91bmQnLCAncmdiYSgwLDAsMCwwLjYpJylcbiAgLnN0eWxlKCdib3JkZXItcmFkaXVzJywgJzVweCcpXG4gIC5zdHlsZSgnY29sb3InLCAnd2hpdGUnKTtcblxuY29uc3QgbWFwX2dyb3VwID0gc3ZnLmFwcGVuZCgnZycpXG5jb25zdCBtYXBfc2NhbGUgPSAwLjZcbm1hcF9ncm91cC5hdHRyKCdpZCcsICdtYXBfZ3JvdXAnKTtcbm1hcF9ncm91cC5hdHRyKCd0cmFuc2Zvcm0nLCAnc2NhbGUoMC42KScpO1xuXG5jb25zdCBiYXJfZ3JvdXAgPSBzdmcyLmFwcGVuZCgnZycpO1xuY29uc3QgYmFyX3Bsb3RfaGVpZ2h0ID0gMTgwO1xuXG5sZXQgem9vbSA9IGQzLnpvb20oKVxuIC5vbignem9vbScsIChlLCBkKSA9PiB7XG4gICBjb25zdCB0cmFuc194ID0gZS50cmFuc2Zvcm0ueFxuICAgY29uc3QgdHJhbnNfeSA9IGUudHJhbnNmb3JtLnlcbiAgIGNvbnN0IHRyYW5zX3NjYWxlID0gZS50cmFuc2Zvcm0ua1xuICAgbWFwX2dyb3VwLmF0dHIoJ3RyYW5zZm9ybScsYHRyYW5zbGF0ZSgke3RyYW5zX3h9LCR7dHJhbnNfeX0pIHNjYWxlKCR7dHJhbnNfc2NhbGUgKiBtYXBfc2NhbGV9KWApXG59KTtcblxuXG5cbmNvbnN0IG1haW4gPSBhc3luYyAoKSA9PiB7XG4gIC8vIGxvYWQgZGF0YVxuICBjb25zdCBkYXRhID0gYXdhaXQgY3N2KGNzdlVybCwgcGFyc2VSb3cpO1xuICBjb25zdCB1c19zdGF0ZXMgPSBhd2FpdCBqc29uKG1hcFVSTCk7XG4gIGxldCBzdGF0ZUNlbnRyb2lkcyA9IGF3YWl0IGpzb24oanNvblVSTCk7XG4gIFxuICBmdW5jdGlvbiBvbmx5VW5pcXVlKHZhbHVlLCBpbmRleCwgc2VsZikge1xuICBcdHJldHVybiBzZWxmLmluZGV4T2YodmFsdWUpID09PSBpbmRleDtcblx0fVx0XG5cdGNvbnN0IHN0YXRlc19saXN0ID0gZGF0YVxuICBcdC5tYXAoKGQpID0+IGQubG9jYXRpb24pXG4gIFx0LmZpbHRlcihvbmx5VW5pcXVlKTtcbiAgXG4gIC8vIGNyZWF0ZSBtYXAgIFxuICBjb25zdCBtYXBfaGVpZ2h0ID0gaGVpZ2h0IC0gYmFyX3Bsb3RfaGVpZ2h0O1xuICAgY29uc3QgbWFwX3Bsb3QgPSBtYXBFbGVtZW50KClcbiAgXHQuZGF0YShkYXRhKVxuICBcdC5tYXBfZGF0YSh1c19zdGF0ZXMpXG4gIFx0LnN0YXRlX2NlbnRyb2lkcyhzdGF0ZUNlbnRyb2lkcylcbiAgIFx0LnNlbGVjdGVkX2RhdGUobmV3IERhdGUoJzIwMjEtMDktMDQnKSlcbiAgICAuc3RhdGVzX2xpc3Qoc3RhdGVzX2xpc3QpXG4gICBcdC5wbG90X2dyb3VwKGJhcl9ncm91cClcbiAgIFx0LnRvb2x0aXAobWFwX3Rvb2x0aXApO1xuICBtYXBfZ3JvdXAuY2FsbChtYXBfcGxvdCk7XG4gIFxuICAvLyBjcmVhdGUgYmFyIHBsb3RcbiAgY29uc3QgYmFyX3Bsb3QgPSBpbnRlcmFjdGl2ZUJhcigpXG4gICAgLndpZHRoKHdpZHRoIC0gMjApXG4gICAgLmhlaWdodChiYXJfcGxvdF9oZWlnaHQpXG4gICAgLmRhdGEoZGF0YSlcbiAgICAueFZhbHVlKChkKSA9PiBkLmRhdGUpXG4gICAgLnlWYWx1ZSgoZCkgPT4gZC5kYWlseV92YWNjaW5hdGlvbnMpXG4gICAgLm1hcmdpbih7XG4gICAgICB0b3A6IDIwLFxuICAgICAgcmlnaHQ6IDIwLFxuICAgICAgYm90dG9tOiA0MCxcbiAgICAgIGxlZnQ6IDEwMCxcbiAgICB9KVxuICAgIC5iYXJfd2lkdGgoMylcbiAgICAuYmFyX2NvbG9yKCcjNURBQkY0JylcbiAgXHQuYmFyX29wYWNpdHkoMS4wKVxuICAgIC5zZWxlY3RlZF9zdGF0ZShcIkFsYWJhbWFcIilcbiAgXHQubGFiZWxfc2l6ZSgnMWVtJylcbiAgXHQubWFwX2dyb3VwKG1hcF9ncm91cClcbiAgXHQubWFwKG1hcF9wbG90KTtcbiAgYmFyX2dyb3VwLmNhbGwoYmFyX3Bsb3QpO1xuICBcbiAgbWFwX3Bsb3QucGxvdChiYXJfcGxvdCk7XG4gIFxuICAvLyBjcmVhdGUgbWVudVxuICBjb25zdCBteV9tZW51ID0gc3RhdGVNZW51KClcbiAgXHQuZGF0YShkYXRhKVxuICBcdC5wbG90KGJhcl9wbG90KTtcblx0YmFyX2dyb3VwLmNhbGwobXlfbWVudSk7XG4gIHN2Zy5jYWxsKHpvb20pO1xuXG59O1xuXG5tYWluKCk7XG4iXSwibmFtZXMiOlsic2NhbGVUaW1lIiwic2NhbGVMaW5lYXIiLCJleHRlbnQiLCJzZWxlY3QiLCJ0cmFuc2l0aW9uIiwiYXhpc0xlZnQiLCJheGlzQm90dG9tIiwiYnJ1c2hYIiwiZGlzcGF0Y2giLCJnZW9BbGJlcnNVc2EiLCJnZW9QYXRoIiwibWF4IiwiYXJjIiwiZm9yY2VTaW11bGF0aW9uIiwiZm9yY2VYIiwiZm9yY2VZIiwiZm9yY2VDb2xsaWRlIl0sIm1hcHBpbmdzIjoiOzs7OztFQVlPLE1BQU0sY0FBYyxHQUFHLE1BQU07RUFDcEMsRUFBRSxJQUFJLEtBQUssQ0FBQztFQUNaLEVBQUUsSUFBSSxNQUFNLENBQUM7RUFDYixFQUFFLElBQUksVUFBVSxDQUFDO0VBQ2pCLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDWCxFQUFFLElBQUksTUFBTSxDQUFDO0VBQ2IsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUNiLEVBQUUsSUFBSSxNQUFNLENBQUM7RUFDYixFQUFFLElBQUksU0FBUyxDQUFDO0VBQ2hCLEVBQUUsSUFBSSxTQUFTLENBQUM7RUFDaEIsRUFBRSxJQUFJLFdBQVcsQ0FBQztFQUNsQixFQUFFLElBQUksY0FBYyxDQUFDO0VBQ3JCLEVBQUUsSUFBSSxVQUFVLENBQUM7RUFDakIsQ0FBQyxJQUFJLFNBQVMsQ0FBQztFQUNmLEVBQUUsSUFBSSxHQUFHLENBQUM7RUFDVjtFQUNBLEVBQUUsTUFBTSxFQUFFLEdBQUcsQ0FBQyxTQUFTLEtBQUs7RUFDNUIsSUFBSSxTQUFTLFlBQVksQ0FBQyxJQUFJLEVBQUU7RUFDaEMsTUFBTSxPQUFPLElBQUksQ0FBQyxRQUFRLElBQUksY0FBYyxDQUFDO0VBQzdDLEtBQUs7QUFDTDtFQUNBO0VBQ0EsSUFBSSxNQUFNLE9BQU8sR0FBRyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztFQUMzQyxJQUFJLE1BQU0sT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQzNDLElBQUksTUFBTSxDQUFDLEdBQUdBLGNBQVMsRUFBRTtFQUN6QixPQUFPLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztFQUNqQyxPQUFPLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsS0FBSyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ2xEO0VBQ0EsSUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUMzQztFQUNBO0VBQ0E7RUFDQSxJQUFJLE1BQU0sQ0FBQyxHQUFHQyxnQkFBVyxFQUFFO0VBQzNCLE9BQU8sTUFBTSxDQUFDO0VBQ2QsUUFBUUMsV0FBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHO0VBQzNDLFFBQVFBLFdBQU0sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3JDLE9BQU8sQ0FBQztFQUNSLE9BQU8sS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDbkQsSUFBSSxNQUFNLEVBQUUsR0FBR0QsZ0JBQVcsRUFBRTtFQUM1QixPQUFPLE1BQU0sQ0FBQztFQUNkLFFBQVFDLFdBQU0sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3JDLFFBQVFBLFdBQU0sQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRztFQUMzQyxPQUFPLENBQUM7RUFDUixPQUFPLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ25EO0VBQ0E7RUFDQSxJQUFJLE1BQU0sV0FBVyxHQUFHLENBQUMsQ0FBQyxLQUFLO0VBQy9CLE1BQU0sSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7RUFDdkMsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQztFQUN4QyxNQUFNLE9BQU8sSUFBSSxDQUFDO0VBQ2xCLEtBQUssQ0FBQztFQUNOLElBQUksTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSztFQUN4QyxNQUFNLE9BQU87RUFDYixRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3ZCLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDdkIsUUFBUSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7RUFDakMsUUFBUSxLQUFLLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQjtFQUNuQyxPQUFPLENBQUM7RUFDUixLQUFLLENBQUMsQ0FBQztBQUNQO0VBQ0E7RUFDQSxJQUFJLFNBQVMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRTtFQUNyQztFQUNBLE1BQU0sU0FBUztFQUNmLFNBQVMsU0FBUyxDQUFDLE1BQU0sQ0FBQztFQUMxQixTQUFTLFVBQVUsRUFBRTtFQUNyQixTQUFTLFFBQVEsQ0FBQyxLQUFLLENBQUM7RUFDeEIsU0FBUyxJQUFJLENBQUMsU0FBUyxFQUFFLFdBQVcsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUMxQyxNQUFNQyxXQUFNLENBQUMsSUFBSSxDQUFDO0VBQ2xCLFNBQVMsVUFBVSxFQUFFO0VBQ3JCLFNBQVMsUUFBUSxDQUFDLEtBQUssQ0FBQztFQUN4QixTQUFTLElBQUksQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUM7RUFDdEMsTUFBTUEsV0FBTSxDQUFDLFVBQVUsQ0FBQztFQUN4QixTQUFTLEtBQUssQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDO0VBQ3ZDLFNBQVMsSUFBSTtFQUNiLFVBQVUsUUFBUTtFQUNsQixZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO0VBQzdCLFlBQVksR0FBRztFQUNmLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7RUFDNUIsWUFBWSxXQUFXO0VBQ3ZCLFlBQVksQ0FBQyxDQUFDLEtBQUs7RUFDbkIsU0FBUyxDQUFDO0VBQ1YsS0FBSztBQUNMO0VBQ0EsSUFBSSxTQUFTLGlCQUFpQixDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUU7RUFDckM7RUFDQSxNQUFNQSxXQUFNLENBQUMsVUFBVSxDQUFDO0VBQ3hCLFNBQVMsS0FBSyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUM7RUFDOUMsU0FBUyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUM7RUFDM0MsS0FBSztBQUNMO0VBQ0EsSUFBSSxTQUFTLGdCQUFnQixDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUU7RUFDcEMsTUFBTSxTQUFTO0VBQ2YsU0FBUyxTQUFTLENBQUMsTUFBTSxDQUFDO0VBQzFCLFNBQVMsVUFBVSxFQUFFO0VBQ3JCLFNBQVMsUUFBUSxDQUFDLEtBQUssQ0FBQztFQUN4QixTQUFTLElBQUksQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUM7RUFDdEMsTUFBTUEsV0FBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFDLENBQUM7RUFDdkQsS0FBSztFQUNMO0VBQ0E7RUFDQSxJQUFJLE1BQU0sQ0FBQyxHQUFHQyxlQUFVLEVBQUUsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDekMsSUFBSSxNQUFNLFlBQVksR0FBRyxDQUFDLElBQUksS0FBSztFQUNuQyxNQUFNLElBQUk7RUFDVixTQUFTLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUs7RUFDMUIsVUFBVSxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxHQUFHLENBQUMsQ0FBQztFQUNyQyxTQUFTLENBQUM7RUFDVixTQUFTLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUs7RUFDMUI7RUFDQSxVQUFVLE9BQU8sTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUM5QyxTQUFTLENBQUM7RUFDVixTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO0VBQ2hDLFNBQVMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUM7RUFDckMsU0FBUyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNwQyxLQUFLLENBQUM7QUFDTjtFQUNBLElBQUksTUFBTSxZQUFZLEdBQUcsQ0FBQyxJQUFJLEtBQUs7RUFDbkMsTUFBTSxJQUFJLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO0VBQzlDLE1BQU0sSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztFQUM5QyxNQUFNLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLGdCQUFnQixDQUFDLENBQUM7RUFDNUMsS0FBSyxDQUFDO0VBQ047RUFDQSxJQUFJLE1BQU0sZUFBZSxHQUFHLENBQUMsSUFBSSxLQUFLO0VBQ3RDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7RUFDNUIsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQztFQUM3QixLQUFLLENBQUM7RUFDTixJQUFJLE1BQU0sU0FBUyxHQUFHLENBQUMsS0FBSyxLQUFLO0VBQ2pDLE1BQU0sS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0VBQ25ELE1BQU0sS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNyRCxLQUFLLENBQUM7QUFDTjtBQUNBO0VBQ0E7RUFDQSxJQUFJLE1BQU0sSUFBSSxHQUFHLFNBQVM7RUFDMUIsT0FBTyxTQUFTLENBQUMsTUFBTSxDQUFDO0VBQ3hCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQztFQUNsQixPQUFPLElBQUk7RUFDWCxRQUFRLENBQUMsS0FBSztFQUNkLFVBQVUsS0FBSztFQUNmLGFBQWEsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUMzQixXQUFXLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUM7RUFDeEMsYUFBYSxJQUFJLENBQUMsWUFBWSxDQUFDO0VBQy9CLGFBQWEsSUFBSSxDQUFDLGVBQWUsQ0FBQztFQUNsQyxhQUFhLElBQUksQ0FBQyxTQUFTLENBQUM7RUFDNUIsV0FBVyxJQUFJLENBQUMsWUFBWSxDQUFDO0VBQzdCLFFBQVEsQ0FBQyxNQUFNO0VBQ2YsVUFBVSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtFQUM3QixZQUFZLE1BQU07RUFDbEIsZUFBZSxVQUFVLENBQUMsQ0FBQyxDQUFDO0VBQzVCLGVBQWUsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO0VBQ3RDLGVBQWUsSUFBSSxDQUFDLFlBQVksQ0FBQztFQUNqQyxXQUFXO0VBQ1gsUUFBUSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFO0VBQy9CLE9BQU8sQ0FBQztFQUNSO0VBQ0EsSUFBSSxTQUFTO0VBQ2IsT0FBTyxTQUFTLENBQUMsU0FBUyxDQUFDO0VBQzNCLE9BQU8sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDbkIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQ2hCLE9BQU8sSUFBSSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUM7RUFDOUIsT0FBTyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDdkQsT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDO0VBQ3BCLE9BQU8sSUFBSSxDQUFDQyxhQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUMxQjtFQUNBO0VBQ0EsSUFBSSxTQUFTO0VBQ2IsT0FBTyxTQUFTLENBQUMsU0FBUyxDQUFDO0VBQzNCLE9BQU8sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDbkIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQ2hCLE9BQU8sSUFBSSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUM7RUFDOUIsT0FBTyxJQUFJO0VBQ1gsUUFBUSxXQUFXO0VBQ25CLFFBQVEsQ0FBQyxZQUFZLEVBQUUsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ2hELE9BQU87RUFDUCxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDcEIsT0FBTyxJQUFJLENBQUNDLGVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzNCO0VBQ0E7RUFDQSxJQUFJLFNBQVMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7RUFDMUIsTUFBTSxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDO0VBQ3JDO0VBQ0EsTUFBTSxJQUFJLFFBQVEsR0FBRyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztFQUM1QyxNQUFNLEdBQUcsVUFBVSxDQUFDO0VBQ3BCLFFBQVEsTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNuRCxPQUFPLFFBQVEsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzFDLE9BQU87RUFDUCxNQUFNLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0VBQ2xELEtBQUs7RUFDTCxJQUFJLE1BQU0sS0FBSyxHQUFHQyxXQUFNLEVBQUU7RUFDMUIsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ3ZDLE9BQU8sRUFBRSxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztFQUNoQyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDMUI7RUFDQTtFQUNBO0VBQ0EsSUFBSSxTQUFTO0VBQ2IsT0FBTyxTQUFTLENBQUMsZUFBZSxDQUFDO0VBQ2pDLE1BQU0sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDbEIsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDO0VBQ2xCLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0VBQzdCLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztFQUNoQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7RUFDekIsT0FBTyxJQUFJLENBQUMsV0FBVyxFQUFFLFVBQVUsQ0FBQztFQUNwQyxNQUFNLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDLENBQUM7RUFDcEM7RUFDQSxJQUFJLFNBQVM7RUFDYixPQUFPLFNBQVMsQ0FBQyxlQUFlLENBQUM7RUFDakMsTUFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUNsQixNQUFNLElBQUksQ0FBQyxNQUFNLENBQUM7RUFDbEIsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztFQUNuQixPQUFPLElBQUksQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7RUFDN0IsT0FBTyxJQUFJLENBQUMseUJBQXlCLENBQUM7RUFDdEMsT0FBTyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN4RCxPQUFPLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBVSxDQUFDO0VBQ3BDLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQztFQUNwQyxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsRUFBRTtFQUMxQixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksS0FBSyxDQUFDO0VBQ3pELEdBQUcsQ0FBQztBQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQzNCLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUM7RUFDM0QsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDekIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDdEQsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDM0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUM7RUFDMUQsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDM0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUM7RUFDMUQsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDM0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUM7RUFDMUQsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDOUIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNO0VBQzNCLFNBQVMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRTtFQUM3QixRQUFRLFNBQVMsQ0FBQztFQUNsQixHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsRUFBRTtFQUNoQyxJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU07RUFDM0IsU0FBUyxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFO0VBQy9CLFFBQVEsV0FBVyxDQUFDO0VBQ3BCLEdBQUcsQ0FBQztBQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQzlCLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTTtFQUMzQixTQUFTLENBQUMsU0FBUyxHQUFHLENBQUMsR0FBRyxFQUFFO0VBQzVCLFFBQVEsU0FBUyxDQUFDO0VBQ2xCLEdBQUcsQ0FBQztBQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsY0FBYyxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQ25DLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTTtFQUMzQixTQUFTLENBQUMsY0FBYyxHQUFHLENBQUMsR0FBRyxFQUFFO0VBQ2pDLFFBQVEsY0FBYyxDQUFDO0VBQ3ZCLEdBQUcsQ0FBQztFQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQy9CLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTTtFQUMzQixTQUFTLENBQUMsVUFBVSxHQUFHLENBQUMsR0FBRyxFQUFFO0VBQzdCLFFBQVEsVUFBVSxDQUFDO0VBQ25CLEdBQUcsQ0FBQztFQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQzlCLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksU0FBUyxDQUFDO0VBQ2hFLEdBQUcsQ0FBQztFQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQ3hCLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksR0FBRyxDQUFDO0VBQ3BELEdBQUcsQ0FBQztBQUNKO0VBQ0EsRUFBRSxPQUFPLEVBQUUsQ0FBQztFQUNaLENBQUM7O0VDblNNLE1BQU0sSUFBSSxHQUFHLE1BQU07RUFDMUIsRUFBRSxJQUFJLEVBQUUsQ0FBQztFQUNULEVBQUUsSUFBSSxTQUFTLENBQUM7RUFDaEIsRUFBRSxJQUFJLE9BQU8sQ0FBQztFQUNkLEVBQUUsTUFBTSxTQUFTLEdBQUdDLGFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUN2QztFQUNBLEVBQUUsTUFBTSxFQUFFLEdBQUcsQ0FBQyxTQUFTLEtBQUs7RUFDNUIsSUFBSSxTQUFTO0VBQ2IsT0FBTyxTQUFTLENBQUMsT0FBTyxDQUFDO0VBQ3pCLE9BQU8sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDbkIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0VBQ3BCLE9BQU8sSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUM7RUFDdEIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDdkI7RUFDQSxJQUFJLFNBQVM7RUFDYixPQUFPLFNBQVMsQ0FBQyxRQUFRLENBQUM7RUFDMUIsT0FBTyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUNuQixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7RUFDckIsT0FBTyxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQztFQUNyQixPQUFPLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLEtBQUs7RUFDL0IsUUFBUSxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztFQUMzRCxPQUFPLENBQUM7RUFDUixPQUFPLFNBQVMsQ0FBQyxRQUFRLENBQUM7RUFDMUIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0VBQ3BCLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQztFQUNyQixPQUFPLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztFQUNwQyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDM0IsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDdkIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLENBQUM7RUFDbEQsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDOUIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNO0VBQzNCLFNBQVMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxHQUFHLEVBQUU7RUFDNUIsUUFBUSxTQUFTLENBQUM7RUFDbEIsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDNUIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxPQUFPLENBQUM7RUFDNUQsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEdBQUcsWUFBWTtFQUN0QixJQUFJLElBQUksS0FBSyxHQUFHLFNBQVMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztFQUN6RCxJQUFJLE9BQU8sS0FBSyxLQUFLLFNBQVMsR0FBRyxFQUFFLEdBQUcsS0FBSyxDQUFDO0VBQzVDLEdBQUcsQ0FBQztBQUNKO0VBQ0EsRUFBRSxPQUFPLEVBQUUsQ0FBQztFQUNaLENBQUM7O0VDMUNNLE1BQU0sU0FBUyxHQUFHLE1BQU07RUFHL0IsRUFBRSxJQUFJLElBQUksQ0FBQztFQUNYLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDWDtFQUNBLEVBQUUsTUFBTSxFQUFFLEdBQUcsQ0FBQyxTQUFTLEtBQUs7RUFDNUIsSUFBSSxNQUFNLGFBQWEsR0FBR0wsV0FBTSxDQUFDLE1BQU0sQ0FBQztFQUN4QyxNQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUM7RUFDbkIsTUFBTSxJQUFJLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUM7RUFDdEMsSUFBSSxNQUFNLFVBQVUsR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0VBQ25ELElBQUksTUFBTSxLQUFLLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztFQUM5QztFQUNBLElBQUksU0FBUyxVQUFVLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUU7RUFDNUMsTUFBTSxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssS0FBSyxDQUFDO0VBQzNDLEtBQUs7RUFDTCxJQUFJLE1BQU0sTUFBTSxHQUFHLElBQUk7RUFDdkIsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUM3QixPQUFPLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztFQUMxQixJQUFJLE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUs7RUFDdEMsTUFBTSxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFLENBQUM7RUFDbkMsS0FBSyxDQUFDLENBQUM7RUFDUDtFQUNBLElBQUksVUFBVSxDQUFDLElBQUk7RUFDbkIsTUFBTSxJQUFJLEVBQUU7RUFDWixTQUFTLEVBQUUsQ0FBQyxZQUFZLENBQUM7RUFDekIsU0FBUyxTQUFTLENBQUMsUUFBUSxDQUFDO0VBQzVCLFNBQVMsT0FBTyxDQUFDLE9BQU8sQ0FBQztFQUN6QixTQUFTLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLEtBQUs7RUFDakMsVUFBVSxTQUFTLENBQUMsSUFBSTtFQUN4QixZQUFZLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO0VBQ3RDLFdBQVcsQ0FBQztFQUNaLFNBQVMsQ0FBQztFQUNWLEtBQUssQ0FBQztFQUNOLEdBQUcsQ0FBQztBQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQ3pCLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxDQUFDO0VBQ3RELEdBQUcsQ0FBQztFQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQ3pCLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFJLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxDQUFDO0VBQ3RELEdBQUcsQ0FBQztFQUNKO0VBQ0EsRUFBRSxPQUFPLEVBQUUsQ0FBQztFQUNaLENBQUM7O0VDbENNLE1BQU0sVUFBVSxHQUFHLE1BQU07RUFHaEMsRUFBRSxJQUFJLElBQUksQ0FBQztFQUNYLEVBQUUsSUFBSSxRQUFRLENBQUM7RUFDZixFQUFFLElBQUksZUFBZSxDQUFDO0VBQ3RCLEVBQUUsSUFBSSxhQUFhLENBQUM7RUFFcEIsRUFBRSxJQUFJLE9BQU8sQ0FBQztFQUNkLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDWCxFQUFFLElBQUksVUFBVSxDQUFDO0VBQ2pCLEVBQUUsSUFBSSxXQUFXLENBQUM7RUFDbEI7RUFDQSxFQUFFLFNBQVMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7RUFDL0IsSUFBSSxPQUFPO0VBQ1gsT0FBTyxLQUFLLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztFQUM1QyxPQUFPLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEtBQUssR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUM7RUFDOUMsR0FBRztBQUNIO0VBQ0EsRUFBRSxTQUFTLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzVCO0VBQ0EsSUFBSSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUM7RUFDbEIsTUFBTSxPQUFPO0VBQ2IsT0FBTyxJQUFJO0VBQ1gsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7RUFDOUIsT0FBTztFQUNQLE9BQU8sS0FBSyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztFQUN0QyxLQUFLO0VBQ0w7RUFDQSxJQUFJLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQztFQUNwQixNQUFNLE9BQU87RUFDYixPQUFPLElBQUk7RUFDWCxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDckMsT0FBTztFQUNQLE9BQU8sS0FBSyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztFQUN0QyxLQUFLO0VBQ0wsR0FBRztBQUNIO0VBQ0EsRUFBRSxTQUFTLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0VBQzlCLE1BQU0sT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFDLENBQUM7RUFDckQsR0FBRztBQUNIO0VBQ0EsRUFBRSxTQUFTLGVBQWUsQ0FBQyxjQUFjLENBQUM7RUFDMUMsSUFBSSxHQUFHLElBQUksQ0FBQztFQUNaLEtBQUssTUFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxHQUFHLGNBQWMsRUFBRSxDQUFDLENBQUM7RUFDckYsS0FBSyxNQUFNLFFBQVEsR0FBR0EsV0FBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0VBQzVDLEtBQUssUUFBUSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3ZELEtBQUs7RUFDTCxHQUFHO0VBQ0g7RUFDQSxFQUFFLFNBQVMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7RUFDaEM7RUFDQSxJQUFJLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUNsQixNQUFNLFVBQVUsQ0FBQyxJQUFJO0VBQ3JCLFFBQVEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ3ZDLE9BQU8sQ0FBQztFQUNSLE1BQU0sZUFBZSxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUM7RUFDakMsS0FBSztFQUNMO0VBQ0EsSUFBSSxHQUFHLENBQUMsQ0FBQyxVQUFVLENBQUM7RUFDcEIsTUFBTSxVQUFVLENBQUMsSUFBSTtFQUNyQixRQUFRLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7RUFDOUMsT0FBTyxDQUFDO0VBQ1IsTUFBTSxlQUFlLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUM7RUFDeEMsS0FBSztFQUNMLEdBQUc7RUFDSDtFQUNBO0VBQ0EsRUFBRSxNQUFNLEVBQUUsR0FBRyxDQUFDLFNBQVMsS0FBSztFQUM1QixHQUFHLE1BQU0sVUFBVSxHQUFHTSxpQkFBWSxFQUFFLENBQUM7RUFDckMsSUFBSSxNQUFNLElBQUksR0FBR0MsWUFBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0VBQ3JDO0VBQ0EsSUFBSSxNQUFNLE1BQU0sR0FBRyxTQUFTO0VBQzVCLE9BQU8sU0FBUyxDQUFDLE1BQU0sQ0FBQztFQUN4QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUN6RSxPQUFPLElBQUk7RUFDWCxRQUFRLENBQUMsS0FBSztFQUNkLFVBQVUsS0FBSztFQUNmLGFBQWEsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUMzQixhQUFhLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO0VBQzVCLGFBQWEsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztFQUNqRCxhQUFhLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUMxQyxhQUFhLElBQUksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDO0VBQ3BDLGFBQWEsSUFBSSxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUM7RUFDdEMsV0FBVyxFQUFFLENBQUMsV0FBVyxFQUFFLFlBQVksQ0FBQztFQUN4QyxXQUFXLEVBQUUsQ0FBQyxXQUFXLEVBQUUsY0FBYyxDQUFDO0VBQzFDLFdBQVcsRUFBRSxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUM7RUFDeEMsV0FBVyxFQUFFLENBQUMsV0FBVyxFQUFFLGVBQWUsQ0FBQztFQUMzQyxRQUFRLENBQUMsTUFBTTtFQUNmLFVBQVUsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUM7RUFDeEMsUUFBUSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFO0VBQy9CLE9BQU8sQ0FBQztFQUNSO0VBQ0E7RUFDQSxJQUFJLFNBQVMsV0FBVyxDQUFDLElBQUksRUFBRTtFQUMvQixNQUFNLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxhQUFhLENBQUMsT0FBTyxFQUFFO0VBQzNELFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxhQUFhLENBQUMsUUFBUSxFQUFFO0VBQ3hELFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7RUFDL0QsS0FBSztFQUNMLElBQUksTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztFQUMvQztFQUNBLElBQUksSUFBSSxRQUFRLEdBQUcsYUFBWTtFQUMvQixJQUFJLFNBQVMsa0JBQWtCLENBQUMsU0FBUyxFQUFFO0VBQzNDLE1BQU0sT0FBTyxTQUFTLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQztFQUN4QyxLQUFLO0FBQ0w7RUFDQSxJQUFJLElBQUksS0FBSyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUs7RUFDckMsTUFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUM1QixNQUFNLE1BQU0sTUFBTSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNuRSxNQUFNLEdBQUcsTUFBTTtFQUNmLFFBQVEsT0FBTztFQUNmLFVBQVUsUUFBUSxHQUFHLENBQUMsQ0FBQyxRQUFRO0VBQy9CLFVBQVUsR0FBRyxHQUFHLE1BQU0sQ0FBQyxHQUFHO0VBQzFCLFVBQVUsR0FBRyxHQUFHLE1BQU0sQ0FBQyxHQUFHO0VBQzFCLFVBQVUsSUFBSSxHQUFHLENBQUMsQ0FBQyxtQ0FBbUM7RUFDdEQsVUFBVSxJQUFJLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QjtFQUNoRCxVQUFVLEtBQUssR0FBRyxDQUFDLENBQUMsZ0JBQWdCO0VBQ3BDLFNBQVM7RUFDVCxLQUFLLENBQUMsQ0FBQztFQUNQO0VBQ0EsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFVLE9BQU8sR0FBRztFQUM3QyxLQUFLLE9BQU8sT0FBTyxLQUFLLFNBQVMsQ0FBQztFQUNsQyxLQUFLLENBQUMsQ0FBQztBQUNQO0VBQ0EsSUFBSSxNQUFNLFlBQVksR0FBR0MsUUFBRyxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsRUFBRTtFQUNqRCxRQUFRLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQztFQUN0QixLQUFLLENBQUMsQ0FBQztFQUNQO0VBQ0E7RUFDQSxJQUFJLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztFQUN2QixJQUFJLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQztFQUN6QixJQUFJLFNBQVMsV0FBVyxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFO0VBQ2hELEtBQUssSUFBSSxLQUFLLEdBQUcsV0FBVyxDQUFDO0VBQzdCLE1BQU0sSUFBSSxLQUFLLEdBQUcsV0FBVyxHQUFHLFVBQVUsQ0FBQztFQUMzQyxNQUFNLElBQUksS0FBSyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztFQUMvQyxNQUFNLElBQUksTUFBTSxHQUFHQyxRQUFHLEVBQUU7RUFDeEIsU0FBUyxXQUFXLENBQUMsS0FBSyxDQUFDO0VBQzNCLFNBQVMsV0FBVyxDQUFDLEtBQUssQ0FBQztFQUMzQixTQUFTLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDdEIsU0FBUyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDekIsTUFBTSxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN2QixLQUFLO0VBQ0w7RUFDQTtFQUNBLElBQUksTUFBTSxZQUFZLEdBQUcsRUFBRTtFQUMzQixPQUFPLFNBQVMsRUFBRTtFQUNsQixPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQztFQUNoQyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ3RCO0VBQ0EsSUFBSSxTQUFTLE1BQU0sRUFBRSxDQUFDLEVBQUU7RUFDeEIsT0FBTyxPQUFPLFdBQVcsQ0FBQztFQUMxQixLQUFLO0FBQ0w7RUFDQSxJQUFJLElBQUksVUFBVSxHQUFHQyxvQkFBZSxDQUFDLEtBQUssQ0FBQztFQUMzQyxPQUFPLEtBQUssQ0FBQyxHQUFHLEVBQUVDLFdBQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTtFQUNyQyxRQUFRLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDOUMsT0FBTyxDQUFDLENBQUM7RUFDVCxPQUFPLEtBQUssQ0FBQyxHQUFHLEVBQUVDLFdBQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTtFQUNyQyxRQUFRLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDOUMsT0FBTyxDQUFDLENBQUM7RUFDVCxPQUFPLEtBQUssQ0FBQyxTQUFTLEVBQUVDLGlCQUFZLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUN4RSxPQUFPLElBQUksRUFBRSxDQUFDO0VBQ2QsSUFBSSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztFQUNwRDtFQUNBO0VBQ0EsSUFBSSxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0VBQ3JDLElBQUksTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7RUFDNUM7RUFDQSxJQUFJLFNBQVMsUUFBUSxFQUFFLEtBQUssQ0FBQztFQUM3QixNQUFNLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztFQUN2RDtFQUNBLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7RUFDeEIsU0FBUyxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQztFQUNqQyxXQUFXLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNqQyxXQUFXLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNqQyxXQUFXLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUN4QyxXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO0VBQ2xDLFdBQVcsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUM7RUFDbEMsV0FBVyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztFQUNsQyxXQUFXLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO0VBQzdCLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksTUFBTSxDQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDcEQ7RUFDQSxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQ3RCLFdBQVcsSUFBSSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUM7RUFDckMsV0FBVyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO0VBQ3JDLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNwQyxXQUFXLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQzlDO0VBQ0EsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUN0QixXQUFXLElBQUksQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDO0VBQ3RDLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLFdBQVcsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDM0UsV0FBVyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSTtFQUNsQyxZQUFZLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO0VBQ25ELFdBQVcsQ0FBQztFQUNaLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ3hDLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUM7RUFDL0I7RUFDQSxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQ3RCLFdBQVcsSUFBSSxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUM7RUFDdEMsV0FBVyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sV0FBVyxDQUFDLENBQUMsRUFBRSxVQUFVLEdBQUcsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDeEYsV0FBVyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSTtFQUNsQyxZQUFZLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO0VBQ25ELFdBQVcsQ0FBQztFQUNaLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ3hDLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztFQUNqQztFQUNBLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUM7RUFDdEMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxjQUFjLENBQUMsQ0FBQztFQUN4QyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0VBQ3RDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7RUFDekM7RUFDQSxNQUFNLE9BQU8sQ0FBQyxDQUFDO0VBQ2YsS0FBSztFQUNMO0VBQ0EsSUFBSSxTQUFTLFVBQVUsQ0FBQyxNQUFNLENBQUM7RUFDL0IsTUFBTSxTQUFTLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7RUFDbkQsU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUM1QztFQUNBLE1BQU0sU0FBUyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0VBQy9DLFNBQVMsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUN2QixXQUFXLElBQUksQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDO0VBQ3RDLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLFdBQVcsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDM0UsV0FBVyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSTtFQUNsQyxZQUFZLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO0VBQ25ELFdBQVcsQ0FBQztFQUNaLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ3hDLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztFQUNoQztFQUNBLE1BQU0sU0FBUyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQ2xELFdBQVcsSUFBSSxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUM7RUFDdEMsV0FBVyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sV0FBVyxDQUFDLENBQUMsRUFBRSxVQUFVLEdBQUcsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDeEYsV0FBVyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSTtFQUNsQyxZQUFZLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO0VBQ25ELFdBQVcsQ0FBQztFQUNaLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ3hDLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztFQUNqQyxLQUFLO0VBQ0w7RUFDQSxJQUFJLE1BQU0sTUFBTSxJQUFJLFNBQVM7RUFDN0IsT0FBTyxTQUFTLENBQUMsUUFBUSxDQUFDO0VBQzFCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQztFQUNsQixNQUFNLElBQUk7RUFDVixRQUFRLENBQUMsS0FBSyxLQUFLLFFBQVEsQ0FBQyxLQUFLLENBQUM7RUFDbEMsUUFBUSxDQUFDLE1BQU0sS0FBSyxVQUFVLENBQU8sQ0FBQztFQUN0QyxRQUFRLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUU7RUFDL0IsT0FBTyxDQUFDO0VBQ1IsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDekIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDdEQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDN0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxRQUFRLENBQUM7RUFDOUQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDcEMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxlQUFlLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxlQUFlLENBQUM7RUFDNUUsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxhQUFhLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDbEMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxhQUFhLENBQUM7RUFDeEUsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDekIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDdEQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDL0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxVQUFVLENBQUM7RUFDbEUsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDNUIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxPQUFPLENBQUM7RUFDNUQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDaEMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxXQUFXLENBQUM7RUFDcEUsR0FBRyxDQUFDO0VBR0o7RUFDQSxFQUFFLE9BQU8sRUFBRSxDQUFDO0VBQ1osQ0FBQzs7RUM5U0QsTUFBTTtFQUNOLEVBQUUsR0FBRztFQUNMLEVBQUUsTUFBTTtFQUNSLEVBQUUsSUFBSTtFQUNOLEVBQUUsTUFBTTtFQUNSLENBQUMsR0FBRyxFQUFFLENBQUM7QUFLUDtFQUNBO0VBQ0EsTUFBTSxNQUFNLEdBQUc7RUFDZixFQUFFLHFDQUFxQztFQUN2QyxFQUFFLG1CQUFtQjtFQUNyQixFQUFFLG1DQUFtQztFQUNyQyxFQUFFLE1BQU07RUFDUixFQUFFLGtCQUFrQjtFQUNwQixDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ1g7RUFDQSxNQUFNLE9BQU8sR0FBRztFQUNoQixDQUFDLHFDQUFxQztFQUN0QyxFQUFFLG1CQUFtQjtFQUNyQixFQUFFLG1DQUFtQztFQUNyQyxFQUFFLE1BQU07RUFDUixFQUFFLHNCQUFzQjtFQUN4QixDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBQztBQUNWO0VBQ0EsTUFBTSxNQUFNLEdBQUcsbURBQWtEO0FBQ2pFO0VBQ0E7RUFDQSxNQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsS0FBSztFQUN4QixFQUFFLENBQUMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0VBQzVCLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO0VBQy9DLEVBQUUsQ0FBQyxDQUFDLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDO0VBQzdDLEVBQUUsQ0FBQyxDQUFDLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDO0VBQzdDLEVBQUUsQ0FBQyxDQUFDLG1DQUFtQyxHQUFHLENBQUMsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDO0VBQ2pGLEVBQUUsQ0FBQyxDQUFDLDhCQUE4QixHQUFHLENBQUMsQ0FBQyxDQUFDLDhCQUE4QixDQUFDO0VBQ3ZFLEVBQUUsQ0FBQyxDQUFDLHVCQUF1QixHQUFHLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDO0VBQ3pELEVBQUUsQ0FBQyxDQUFDLDZCQUE2QixHQUFHLENBQUMsQ0FBQyxDQUFDLDZCQUE2QixDQUFDO0VBQ3JFLEVBQUUsQ0FBQyxDQUFDLHVCQUF1QixHQUFHLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDO0VBQ3pELEVBQUUsQ0FBQyxDQUFDLHNCQUFzQixHQUFHLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDO0VBQ3ZELEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO0VBQy9DLEVBQUUsQ0FBQyxDQUFDLDhCQUE4QixHQUFHLENBQUMsQ0FBQyxDQUFDLDhCQUE4QixDQUFDO0VBQ3ZFLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0VBQzNDLEVBQUUsT0FBTyxDQUFDLENBQUM7RUFDWCxDQUFDLENBQUM7QUFDRjtFQUNBO0VBQ0EsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQztFQUNoQyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsV0FBVyxDQUFDO0FBQ2xDO0VBQ0EsTUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUMxQixHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7RUFDaEIsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLEtBQUssR0FBRyxHQUFHLENBQUM7RUFDN0IsR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLE1BQU0sR0FBRyxHQUFHLENBQUM7RUFDL0IsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0FBQzNCO0VBQ0EsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUMzQixHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7RUFDaEIsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLEtBQUssR0FBRyxFQUFFLENBQUM7RUFDNUIsR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQztFQUN0QixFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFDM0I7RUFDQSxJQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQzVCLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztFQUNoQixFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUM7RUFDZixLQUFLLElBQUksQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDO0VBQzFCLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQztFQUNyQyxLQUFLLEtBQUssQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO0VBQ2pDLEtBQUssS0FBSyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUMsQ0FBQztBQUNuQztFQUNBLE1BQU0sV0FBVyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUM7RUFDbEMsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO0VBQ2hCLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUM7RUFDOUIsR0FBRyxLQUFLLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQztFQUNoQyxHQUFHLEtBQUssQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDO0VBQ3pCLEdBQUcsS0FBSyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUM7RUFDaEMsR0FBRyxLQUFLLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQztFQUMzQixHQUFHLEtBQUssQ0FBQyxZQUFZLEVBQUUsaUJBQWlCLENBQUM7RUFDekMsR0FBRyxLQUFLLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQztFQUNoQyxHQUFHLEtBQUssQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFDM0I7RUFDQSxNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBQztFQUNqQyxNQUFNLFNBQVMsR0FBRyxJQUFHO0VBQ3JCLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDO0VBQ2xDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQzFDO0VBQ0EsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNuQyxNQUFNLGVBQWUsR0FBRyxHQUFHLENBQUM7QUFDNUI7RUFDQSxJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFO0VBQ3BCLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUs7RUFDdkIsR0FBRyxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUM7RUFDaEMsR0FBRyxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUM7RUFDaEMsR0FBRyxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUM7RUFDcEMsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxRQUFRLEVBQUUsV0FBVyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBQztFQUNuRyxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0E7QUFDQTtFQUNBLE1BQU0sSUFBSSxHQUFHLFlBQVk7RUFDekI7RUFDQSxFQUFFLE1BQU0sSUFBSSxHQUFHLE1BQU0sR0FBRyxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztFQUMzQyxFQUFFLE1BQU0sU0FBUyxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0VBQ3ZDLEVBQUUsSUFBSSxjQUFjLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7RUFDM0M7RUFDQSxFQUFFLFNBQVMsVUFBVSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFO0VBQzFDLEdBQUcsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEtBQUssQ0FBQztFQUN4QyxFQUFFO0VBQ0YsQ0FBQyxNQUFNLFdBQVcsR0FBRyxJQUFJO0VBQ3pCLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUM7RUFDMUIsSUFBSSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7RUFJdkIsR0FBRyxNQUFNLFFBQVEsR0FBRyxVQUFVLEVBQUU7RUFDaEMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2QsSUFBSSxRQUFRLENBQUMsU0FBUyxDQUFDO0VBQ3ZCLElBQUksZUFBZSxDQUFDLGNBQWMsQ0FBQztFQUNuQyxLQUFLLGFBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztFQUMxQyxLQUFLLFdBQVcsQ0FBQyxXQUFXLENBQUM7RUFDN0IsS0FBSyxVQUFVLENBQUMsU0FBUyxDQUFDO0VBQzFCLEtBQUssT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0VBQzFCLEVBQUUsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUMzQjtFQUNBO0VBQ0EsRUFBRSxNQUFNLFFBQVEsR0FBRyxjQUFjLEVBQUU7RUFDbkMsS0FBSyxLQUFLLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztFQUN0QixLQUFLLE1BQU0sQ0FBQyxlQUFlLENBQUM7RUFDNUIsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2YsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztFQUMxQixLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsa0JBQWtCLENBQUM7RUFDeEMsS0FBSyxNQUFNLENBQUM7RUFDWixNQUFNLEdBQUcsRUFBRSxFQUFFO0VBQ2IsTUFBTSxLQUFLLEVBQUUsRUFBRTtFQUNmLE1BQU0sTUFBTSxFQUFFLEVBQUU7RUFDaEIsTUFBTSxJQUFJLEVBQUUsR0FBRztFQUNmLEtBQUssQ0FBQztFQUNOLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztFQUNqQixLQUFLLFNBQVMsQ0FBQyxTQUFTLENBQUM7RUFDekIsSUFBSSxXQUFXLENBQUMsR0FBRyxDQUFDO0VBQ3BCLEtBQUssY0FBYyxDQUFDLFNBQVMsQ0FBQztFQUM5QixJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUM7RUFDckIsSUFBSSxTQUFTLENBQUMsU0FBUyxDQUFDO0VBQ3hCLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0VBQ2xCLEVBQUUsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUMzQjtFQUNBLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUMxQjtFQUNBO0VBQ0EsRUFBRSxNQUFNLE9BQU8sR0FBRyxTQUFTLEVBQUU7RUFDN0IsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2QsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7RUFDbkIsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0VBQ3pCLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQjtFQUNBLENBQUMsQ0FBQztBQUNGO0VBQ0EsSUFBSSxFQUFFOzs7OyJ9