import {
  scaleLinear,
  extent,
  axisLeft,
  axisBottom,
  transition,
  select,
  scaleTime,
  brushX
} from 'd3';


export const linePlot = () => {
  let width;
  let height;
  let state_data;
  let data;
  let xValue;
  let yValue;
  let margin;
  let line_color;
  let selected_state;
  let label_size;
	let map_group;
  let map;
  let line_element;
  let mindate;
  let maxdate;
  let yaxis;
  let xaxis;
  
  const my = (selection) => {
    function filter_state(list) {
      return list.location == selected_state;
    }
    function filter_date(list) {
      return list.date > mindate && list.date < maxdate;
    }
    
    // Create a time scale for the x-axis
    // mindate = new Date('2021-04-01');
    // maxdate = new Date('2021-09-04');
    
    const x = scaleTime()
      .domain([mindate, maxdate])
      .range([margin.left, width - margin.right]);

    state_data = data.filter(filter_state).filter(filter_date);

    const y = scaleLinear()
      .domain([
        extent(state_data, yValue)[0] * 100,
        extent(state_data, yValue)[1] * 100 * 1.01,
      ])
      .range([height - margin.bottom, margin.top]);

    // create a set of marks to visualize
    const correctDate = (d) => {
      let date = new Date(d.valueOf());
      date.setDate(date.getDate() + 32);
      return date;
    };
    
    // animation functions
    const t = transition().duration(800);
    
    const lineGenerator = d3.line()
    .x(d => x(xValue(d)))
    .y(d => y(yValue(d) * 100));
    
    function filter_state(list) {
      return list.location == selected_state;
    }
    
    
    if(line_element){
    	line_element
        .attr("fill", "none")
        .attr("stroke", "green")
        .attr("stroke-width", 1.5)
        .attr("id", selected_state)
      	.transition(t)
        .attr("d", lineGenerator(state_data));
    }
    else{
      line_element = selection.append("path")
        .attr("fill", "none")
        .attr("stroke", "green")
        .attr("stroke-width", 1.5)
        .attr("d", lineGenerator(state_data))
        .attr("id", selected_state);
    }
    
    // redraw y axis
    selection
      .selectAll('.y-axis')
      .data([null])
      .join('g')
      .attr('class', 'y-axis')
      .attr('transform', `translate(${margin.left},0)`)
      .transition(t)
      .call(axisLeft(y));

    // redraw x axis
    selection
      .selectAll('.x-axis')
      .data([null])
      .join('g')
      .attr('class', 'x-axis')
      .attr(
        'transform',
        `translate(0,${height - margin.bottom})`
      )
      .transition(t)
      .call(axisBottom(x))
    	.selectAll("text")  
        .style("text-anchor", "end")
        .attr("dx", "-.8em")
        .attr("dy", ".15em")
        .attr("transform", "rotate(-65)" );;
  };

  my.width = function (_) {
    return arguments.length ? ((width = +_), my) : width;
  };

  my.height = function (_) {
    return arguments.length ? ((height = +_), my) : height;
  };

  my.data = function (_) {
    return arguments.length ? ((data = _), my) : data;
  };

  my.xValue = function (_) {
    return arguments.length ? ((xValue = _), my) : xValue;
  };

  my.yValue = function (_) {
    return arguments.length ? ((yValue = _), my) : yValue;
  };

  my.margin = function (_) {
    return arguments.length ? ((margin = _), my) : margin;
  };

  my.line_color = function (_) {
    return arguments.length
      ? ((line_color = _), my)
      : line_color;
  };

  my.selected_state = function (_) {
    return arguments.length
      ? ((selected_state = _), my)
      : selected_state;
  };
  
  my.label_size = function (_) {
    return arguments.length
      ? ((label_size = _), my)
      : label_size;
  };
  
  my.map_group = function (_) {
    return arguments.length ? ((map_group = _), my) : map_group;
  };
  
  my.map = function (_) {
    return arguments.length ? ((map = _), my) : map;
  };
  
  my.mindate = function (_) {
    return arguments.length ? ((mindate = _), my) : mindate;
  };
  
  my.maxdate = function (_) {
    return arguments.length ? ((maxdate = _), my) : maxdate;
  };



  return my;
};
