const { csv, select, json } = d3;

// ##### DATA SOURCE AND MANIPULATION #####
// data source url
const csvUrl = [
  'https://gist.githubusercontent.com/',
  'PeterVanNostrand/', // User
  'd449b0a3e5914278dfa79ba60e48df5d/', // Id of the Gist
  'raw/', // commit
  'vaccine_data.csv', // File name
].join('');

// parsing the dataset
const parseRow = (d) => {
  d.date = new Date(d.date);
  d.total_vaccinations = +d.total_vaccinations;
  d.total_distributed = +d.total_distributed;
  d.people_vaccinated = +d.people_vaccinated;
  d.people_fully_vaccinated_per_hundred = +d.people_fully_vaccinated_per_hundred;
  d.total_vaccinations_per_hundred = +d.total_vaccinations_per_hundred;
  d.people_fully_vaccinated = +d.people_fully_vaccinated;
  d.people_vaccinated_per_hundred = +d.people_vaccinated_per_hundred;
  d.distributed_per_hundred = +d.distributed_per_hundred;
  d.daily_vaccinations_raw = +d.daily_vaccinations_raw;
  d.daily_vaccinations = +d.daily_vaccinations;
  d.daily_vaccinations_per_million = +d.daily_vaccinations_per_million;
  d.share_doses_used = +d.share_doses_used;
  return d;
};

// Select the SVG element
const width = window.innerWidth;
const height = window.innerHeight;
const svg = select('body')
  .append('svg')
  .attr('width', width)
  .attr('height', height);

const main = async () => {
  // load and filter the data
  const data = await csv(csvUrl, parseRow);
  const us = await json('https://unpkg.com/us-atlas@3.0.0/states-10m.json');
  const fipsToState = await json('fipsToState.json');
  let stateCentroids = await json('state_centers_formatted_with_suggested_zoom.json');;
  let nytresults2020 = await json('https://static01.nyt.com/elections-assets/2020/data/api/2020-11-03/national-map-page/national/president.json');
  let results2020 = await csv('https://raw.githubusercontent.com/almccon/US_County_Level_Election_Results_08-20/master/2020_US_County_Level_Presidential_Results.csv');
  
  const projection = d3.geoAlbersUsa();
	const path = d3.geoPath(projection);
  
  var color = d3
    .scaleLinear()
    .domain([20, 50, 80])
    .range(['blue', 'purple', 'red']);
  
  const states = svg
    .append('g')
    .attr('class', 'states')
    .selectAll('path')
    .data(topojson.feature(us, us.objects.states).features)
    .enter()
    .append('path')
    	.attr('d', path)
  		.attr('id', (d) => d.properties.name);
  
  
  const selected_date = new Date('2021-09-04');
  function filter_date(list) {
    return list.date.getDate() == selected_date.getDate()&& 
      list.date.getMonth() == selected_date.getMonth()&& 
      list.date.getFullYear() == selected_date.getFullYear();
  }
  const date_data = data.filter(filter_date);  
  
  console.log(stateCentroids);
  
  
  
  // const marks = date_data.map((d) => {
  //   return { state : [d.lat, d.lon]};
  // });
  
  let my_state = "California"
  function get_state_centroid(centroids) {
  	return centroids.name == my_state;
  }
  
  let marks = date_data.map((d) => {
  	my_state = d.location;
    const center = stateCentroids.filter(get_state_centroid)[0];
    if(center)
    	return { 
      	location : d.location,
      	lat : center.lat,
        lon : center.lon,
        full : d.people_fully_vaccinated_per_hundred,
        part : d.people_vaccinated_per_hundred,
        doses : d.share_doses_used
    	}
  });
  
  marks = marks.filter(function( element ) {
   return element !== undefined;
	});
  

  const highest_vacc = d3.max(marks, function (d) {
      return d.full;
  });
  
  const circleRadius = d3
    .scaleLinear()
    .domain([0, highest_vacc])
    .range([0, 25]); // 0 to maximum radius in pixels
  
  const circles  = svg
  	.selectAll('circle')
  	.data(marks)
  	.join('circle')
  		.attr('r', (d) => circleRadius(d.full))
  		.attr('cx', (d) => projection([d.lon, d.lat])[0])
  		.attr('cy', (d) => projection([d.lon, d.lat])[1])
  		.attr('id', (d) => d.location)
  		.attr('fill', 'blue')
  		.attr('opacity', 0.5);
}

main();
