A map of the United States showing the total percent of a state which is fully vaccinated against COVID-19 as of 09/04/2021. The radius of each circle is proportional the fraction of eligible people in that state which have been fully vaccinated.

Data Source: [US Vaccination Data by State/Territory](https://gist.github.com/PeterVanNostrand/d449b0a3e5914278dfa79ba60e48df5d)