import {
  scaleLinear,
  extent,
  axisLeft,
  axisBottom,
  transition,
  select,
  scaleTime,
  brushX
} from 'd3';


export const linePlot = () => {
  let width;
  let height;
  let state_data;
  let data;
  let xValue;
  let yValue;
  let margin;
  let line_color;
  let selected_state;
  let label_size;
	let map_group;
  let map;
  
  const my = (selection) => {
    function filter_state(list) {
      return list.location == selected_state;
    }
    
    // Create a time scale for the x-axis
    const mindate = new Date('2021-04-01');
    const maxdate = new Date('2021-09-04');
    
    const x = scaleTime()
      .domain([mindate, maxdate])
      .range([margin.left, width - margin.right]);

    state_data = data.filter(filter_state);

    const y = scaleLinear()
      .domain([
        extent(state_data, yValue)[0],
        extent(state_data, yValue)[1] * 1.1,
      ])
      .range([height - margin.bottom, margin.top]);

    // create a set of marks to visualize
    const correctDate = (d) => {
      let date = new Date(d.valueOf());
      date.setDate(date.getDate() + 32);
      return date;
    };
    
    // animation functions
    const t = transition().duration(500);
    
    const lineGenerator = d3.line()
    .x(d => x(xValue(d)))
    .y(d => y(yValue(d)));
    
    function filter_state(list) {
      return list.location == selected_state;
    }
    
    selection.append("path")
      .attr("fill", "none")
      .attr("stroke", "green")
      .attr("stroke-width", 1.5)
      .attr("d", lineGenerator(state_data));
    
    // redraw y axis
    selection
      .selectAll('.y-axis')
      .data([null])
      .join('g')
      .attr('class', 'y-axis')
      .attr('transform', `translate(${margin.left},0)`)
      .transition(t)
      .call(axisLeft(y));

    // redraw x axis
    selection
      .selectAll('.x-axis')
      .data([null])
      .join('g')
      .attr('class', 'x-axis')
      .attr(
        'transform',
        `translate(0,${height - margin.bottom})`
      )
      .transition(t)
      .call(axisBottom(x));
  };

  my.width = function (_) {
    return arguments.length ? ((width = +_), my) : width;
  };

  my.height = function (_) {
    return arguments.length ? ((height = +_), my) : height;
  };

  my.data = function (_) {
    return arguments.length ? ((data = _), my) : data;
  };

  my.xValue = function (_) {
    return arguments.length ? ((xValue = _), my) : xValue;
  };

  my.yValue = function (_) {
    return arguments.length ? ((yValue = _), my) : yValue;
  };

  my.margin = function (_) {
    return arguments.length ? ((margin = _), my) : margin;
  };

  my.line_color = function (_) {
    return arguments.length
      ? ((line_color = _), my)
      : line_color;
  };

  my.selected_state = function (_) {
    return arguments.length
      ? ((selected_state = _), my)
      : selected_state;
  };
  
  my.label_size = function (_) {
    return arguments.length
      ? ((label_size = _), my)
      : label_size;
  };
  
  my.map_group = function (_) {
    return arguments.length ? ((map_group = _), my) : map_group;
  };
  
  my.map = function (_) {
    return arguments.length ? ((map = _), my) : map;
  };

  return my;
};
