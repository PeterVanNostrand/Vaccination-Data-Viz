(function (d3$1, react) {
  'use strict';

  var react__default = 'default' in react ? react['default'] : react;

  const interactiveBar = () => {
    let width;
    let height;
    let state_data;
    let data;
    let xValue;
    let yValue;
    let margin;
    let bar_width;
    let bar_color;
    let bar_opacity;
    let selected_state;
    let label_size;
  	let map_group;
    let map;
    
    const my = (selection) => {
      function filter_state(list) {
        return list.location == selected_state;
      }

      // Create a time scale for the x-axis
      const mindate = new Date('2021-04-01');
      const maxdate = new Date('2021-09-04');
      const x = d3$1.scaleTime()
        .domain([mindate, maxdate])
        .range([margin.left, width - margin.right]);

      state_data = data.filter(filter_state);

      // create y scale, y is used to determine the bar height y1 is just used
      // to plot the axis in the right direction
      const y = d3$1.scaleLinear()
        .domain([
          d3$1.extent(state_data, yValue)[1] * 1.1,
          d3$1.extent(state_data, yValue)[0],
        ])
        .range([height - margin.bottom, margin.top]);
      const y1 = d3$1.scaleLinear()
        .domain([
          d3$1.extent(state_data, yValue)[0],
          d3$1.extent(state_data, yValue)[1] * 1.1,
        ])
        .range([height - margin.bottom, margin.top]);

      // create a set of marks to visualize
      const correctDate = (d) => {
        let date = new Date(d.valueOf());
        date.setDate(date.getDate() + 32);
        return date;
      };
      const marks = state_data.map((d) => {
        return {
          x: x(xValue(d)),
          y: y(yValue(d)),
          date: correctDate(d.date),
          doses: d.daily_vaccinations,
        };
      });

      // hover animation functions
      function handle_mouse_over(e, d) {
        // console.log('mover');
        selection
          .selectAll('rect')
          .transition()
          .duration('100')
          .attr('opacity', bar_opacity / 2);
        d3$1.select(this)
          .transition()
          .duration('100')
          .attr('opacity', bar_opacity);
        d3$1.select('#tooltip')
          .style('visibility', 'visible')
          .text(
            'Date: ' +
              d.date.getMonth() +
              '/' +
              d.date.getDate() +
              ', Doses: ' +
              d.doses
          );
      }

      function handle_mouse_move(e, d) {
        // console.log(event.PageX, event.PageY);
        d3$1.select('#tooltip')
          .style('top', event.pageY - 25 + 'px')
          .style('left', event.pageX + 'px');
      }

      function handle_mouse_out(e, d) {
        selection
          .selectAll('rect')
          .transition()
          .duration('100')
          .attr('opacity', bar_opacity);
        d3$1.select('#tooltip').style('visibility', 'hidden');
      }
      
      // animation functions
      const t = d3$1.transition().duration(500);
      const positionBars = (bars) => {
        bars
          .attr('x', (d) => {
            return d.x + bar_width / 2;
          })
          .attr('y', (d) => {
            // place the bottom of each bar at the x-axis
            return height - margin.bottom - d.y;
          })
          .attr('fill', bar_color)
          .attr('opacity', bar_opacity)
          .attr('height', (d) => d.y);
      };

      const set_handlers = (bars) => {
        bars.on('mouseover', handle_mouse_over);
        bars.on('mousemove', handle_mouse_move);
        bars.on('mouseout', handle_mouse_out);
      };
      
      const initializeWidth = (bars) => {
        bars.attr('width', 0);
        bars.attr('height', 0);
      };
      const growWidth = (enter) => {
        enter.transition(t).attr('width', bar_width);
        enter.transition(t).attr('height', (d) => d.y);
      };


      // draw the bars
      const bars = selection
        .selectAll('rect')
        .data(marks)
        .join(
          (enter) =>
            enter
              .append('rect')
          		.attr("pointer-events", "all")
              .call(positionBars)
              .call(initializeWidth)
              .call(growWidth)
          		.call(set_handlers),
          (update) =>
            update.call((update) =>
              update
                .transition(t)
                .delay((d, i) => i * 10)
                .call(positionBars)
            ),
          (exit) => exit.remove()
        );
      // redraw y axis
      selection
        .selectAll('.y-axis')
        .data([null])
        .join('g')
        .attr('class', 'y-axis')
        .attr('transform', `translate(${margin.left},0)`)
        .transition(t)
        .call(d3$1.axisLeft(y1));

      // redraw x axis
      selection
        .selectAll('.x-axis')
        .data([null])
        .join('g')
        .attr('class', 'x-axis')
        .attr(
          'transform',
          `translate(0,${height - margin.bottom})`
        )
        .transition(t)
        .call(d3$1.axisBottom(x));
      
      // brushing
      function brushed(e, d){
        const brush_area = e.selection;
        
        let end_date = new Date('2021-09-04');
        if(brush_area){
          const start_date = x.invert(brush_area[0]);
        	end_date = x.invert(brush_area[1]);
        }
        map_group.call(map.selected_date(end_date));
      }
      const brush = d3$1.brushX()
        .extent([[0,0], [width, height]])
        .on("brush end", brushed);
      selection.call(brush);
      // select('.overlay').attr('display', 'none');
      
      // Add axis labels
      selection
        .selectAll('.x-axis-label')
      	.data([null])
      	.join('text')
        .attr('y', height - 10)
        .attr('x', width / 2 - 10)
        .text('Date, 2021')
        .attr('font-size', label_size)
      	.attr('class', 'x-axis-label');
      
      selection
        .selectAll('.y-axis-label')
      	.data([null])
      	.join('text')
        .attr('x', 0)
        .attr('y', height/2-20)
        .text('Daily Doses Distributed')
        .attr('transform', `rotate(270, 70, ${height/2})`)
        .attr('font-size', label_size)
      	.attr('class', 'y-axis-label');
    };

    my.width = function (_) {
      return arguments.length ? ((width = +_), my) : width;
    };

    my.height = function (_) {
      return arguments.length ? ((height = +_), my) : height;
    };

    my.data = function (_) {
      return arguments.length ? ((data = _), my) : data;
    };

    my.xValue = function (_) {
      return arguments.length ? ((xValue = _), my) : xValue;
    };

    my.yValue = function (_) {
      return arguments.length ? ((yValue = _), my) : yValue;
    };

    my.margin = function (_) {
      return arguments.length ? ((margin = _), my) : margin;
    };

    my.bar_width = function (_) {
      return arguments.length
        ? ((bar_width = +_), my)
        : bar_width;
    };

    my.bar_opacity = function (_) {
      return arguments.length
        ? ((bar_opacity = +_), my)
        : bar_opacity;
    };

    my.bar_color = function (_) {
      return arguments.length
        ? ((bar_color = _), my)
        : bar_color;
    };

    my.selected_state = function (_) {
      return arguments.length
        ? ((selected_state = _), my)
        : selected_state;
    };
    
    my.label_size = function (_) {
      return arguments.length
        ? ((label_size = _), my)
        : label_size;
    };
    
    my.map_group = function (_) {
      return arguments.length ? ((map_group = _), my) : map_group;
    };
    
    my.map = function (_) {
      return arguments.length ? ((map = _), my) : map;
    };

    return my;
  };

  const menu = () => {
    let id;
    let labelText;
    let options;
    const listeners = d3$1.dispatch('change');
    
    const my = (selection) => {
      selection
        .selectAll('label')
        .data([null])
        .join('label')
        .attr('for', id)
        .text(labelText);

      selection
        .selectAll('select')
        .data([null])
        .join('select')
        .attr('id', id)
        .on('change', (event) => {
          listeners.call('change', null, event.target.value);
        })
        .selectAll('option')
        .data(options)
        .join('option')
        .attr('value', (d) => d.value)
        .text((d) => d.text);
    };

    my.id = function (_) {
      return arguments.length ? ((id = _), my) : id;
    };

    my.labelText = function (_) {
      return arguments.length
        ? ((labelText = _), my)
        : labelText;
    };

    my.options = function (_) {
      return arguments.length ? ((options = _), my) : options;
    };

    my.on = function () {
      var value = listeners.on.apply(listeners, arguments);
      return value === listeners ? my : value;
    };

    return my;
  };

  const stateMenu = () => {
    let data;
    let plot;
    
    const my = (selection) => {
      const menuContainer = d3$1.select('body')
      	.append('div')
      	.attr('class', 'menu-container');
      const state_menu = menuContainer.append('div');
      const yMenu = menuContainer.append('div');
      
      function onlyUnique(value, index, self) {
        return self.indexOf(value) === index;
      }
      const states = data
        .map((d) => d.location)
        .filter(onlyUnique);
      const options = states.map((d) => {
        return { value: d, text: d };
      });
      
      state_menu.call(
        menu()
          .id('state-menu')
          .labelText('State:')
          .options(options)
          .on('change', (state) => {
            selection.call(
              plot.selected_state(state)
            );
          })
      );
    };

    my.data = function (_) {
      return arguments.length ? ((data = _), my) : data;
    };
      
    my.plot = function (_) {
      return arguments.length ? ((plot = _), my) : plot;
    };
    
    return my;
  };

  const mapElement = () => {
    let data;
    let map_data;
    let state_centroids;
    let selected_date;
    let tooltip;
    let plot;
    let plot_group;
    let states_list;
    
    function map_mouse_move(e,d) {
      tooltip
        .style('top', event.pageY - 10 + 'px')
        .style('left', event.pageX + 10 + 'px');
    }

    function map_mouse_on(e,d){
      // hover on dougnut plot group
      if(d.location){
        tooltip
        .html(
          `State: ${d.location}`
        )
        .style('visibility', 'visible');
      }
      // hover on state path
      if(d.properties){
        tooltip
        .html(
          `State: ${d.properties.name}`
        )
        .style('visibility', 'visible');
      }
    }

    function map_mouse_out(e,d) {
        tooltip.html(``).style('visibility', 'hidden');
    }

    function update_dropdown(selected_state){
      if(data){
      	const state_index = states_list.findIndex((f) => { return f > selected_state });
      	const dropdown = d3$1.select('#state-menu');
      	dropdown.property('selectedIndex', state_index-1);
      }
    }
    
    function map_mouse_click(e,d) {
      // click on dougnut plot group
      if(d.location){
        plot_group.call(
          plot.selected_state(d.location)
        );
        update_dropdown(d.location);
      }
      // click on state path
      if(d.properties && d.properties.name){
        plot_group.call(
          plot.selected_state(d.properties.name)
        );
        update_dropdown(d.properties.name);
      }
    }
      
    const my = (selection) => {
    	const projection = d3$1.geoAlbersUsa();
      const path = d3$1.geoPath(projection);
      
      const states = selection
        .selectAll('path')
        .data(topojson.feature(map_data, map_data.objects.states).features)
        .join(
          (enter) =>
            enter
              .append('path')
              .attr('d', path)
              .attr('id', (d) => d.properties.name)
              .attr('id', (d) => d.location)
              .attr('stroke', 'black')
              .attr('fill', 'lightgray')
          		.on('mouseover', map_mouse_on)
          		.on('mousemove', map_mouse_move)
          		.on('mouseout', map_mouse_out)
          		.on('mousedown', map_mouse_click),
          (update) =>
            update.call((update) =>update),
          (exit) => exit.remove()
        );
      
      // const selected_date = new Date('2021-09-04');
      function filter_date(list) {
        return list.date.getDate() == selected_date.getDate()&& 
          list.date.getMonth() == selected_date.getMonth()&& 
          list.date.getFullYear() == selected_date.getFullYear();
      }
      const date_data = data.filter(filter_date);  
      
      let my_state = "California";
      function get_state_centroid(centroids) {
        return centroids.name == my_state;
      }

      let marks = date_data.map((d) => {
        my_state = d.location;
        const center = state_centroids.filter(get_state_centroid)[0];
        if(center)
          return { 
            location : d.location,
            lat : center.lat,
            lon : center.lon,
            full : d.people_fully_vaccinated_per_hundred,
            part : d.people_vaccinated_per_hundred,
            doses : d.share_doses_used
          }
      });
      
      marks = marks.filter(function( element ) {
       return element !== undefined;
      });

      const highest_vacc = d3$1.max(marks, function (d) {
          return d.full;
      });
      
      // ARC STUFF
      let ring_width = 7;
      let ring_radius = 12;
      function generateArc(d, base_radius, value) {
      	let inner = base_radius;
        let outer = base_radius + ring_width;
        let angle = (value(d) / 100) * 2*Math.PI;
        let arcGen = d3$1.arc()
          .innerRadius(inner)
          .outerRadius(outer)
          .startAngle(0)
          .endAngle(angle);
        return arcGen(d);
      }
      // END ARC STUFF
    
      const circleRadius = d3
        .scaleSqrt()
        .domain([0, highest_vacc])
        .range([0, 25]); // 0 to maximum radius in pixels
      
     	function radius (d) { 
         return ring_radius;
      }	

      var simulation = d3$1.forceSimulation(marks)
        .force("x", d3$1.forceX(function(d) {
          return projection([+d.lon,+d.lat])[0];
        }))
        .force("y", d3$1.forceY(function(d) {
          return projection([+d.lon,+d.lat])[1];
        }))
        .force("collide", d3$1.forceCollide(d => radius() + ring_width*2 + 1))
        .stop();
      for (var i = 0; i < 120; ++i) simulation.tick();
         
      
      const vacc_value = (d) => d.full;
      const dose_value = (d) => d.doses * 100;
      
      function drawmark (enter){
        let g = enter.append('g').attr('class', 'marks');
        
        g.append('circle')
        		.attr('class', 'circles')
            .attr('cx', (d) => d.x)
            .attr('cy', (d) => d.y)
            .attr('id', (d) => d.location)
            .attr('fill', '#e0dcdc')
            .attr('stroke', 'black')
            .attr('stroke-width', 2)
            .attr('opacity', 1)
            .attr('r', d => radius() + ring_width*2);
        
        g.append("text")
            .attr('class', 'vacc-text')
            .attr('x', (d) => d.x - 10)
            .attr('y', (d) => d.y + 5)
            .text((d) => "" + parseInt(d.full));
        
        g.append("path")
            .attr('class', 'vacc-rings')
            .attr("d", d => {return generateArc(d, ring_radius, vacc_value)})
            .attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
            .attr('id', (d) => d.location)
            .attr('fill', 'blue');
        
        g.append("path")
            .attr('class', 'dose-rings')
            .attr("d", d => {return generateArc(d, ring_width + ring_radius, dose_value)})
            .attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
            .attr('id', (d) => d.location)
            .attr('fill', 'green');
        
        g.on('mouseover', map_mouse_on);
        g.on('mousemove', map_mouse_move);
        g.on('mouseout', map_mouse_out);
        g.on('mousedown', map_mouse_click);
        
        return g;
      }
      
      function updatemark(update){
        selection.selectAll('.vacc-text').data(marks)
          .text((d) => "" + parseInt(d.full));
        
        selection.selectAll('.marks').data(marks)
          .append("path")
            .attr('class', 'vacc-rings')
            .attr("d", d => {return generateArc(d, ring_radius, vacc_value)})
            .attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
            .attr('id', (d) => d.location)
            .attr('fill', 'blue');
        
        selection.selectAll('.marks').append("path")
            .attr('class', 'dose-rings')
            .attr("d", d => {return generateArc(d, ring_width + ring_radius, dose_value)})
            .attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
            .attr('id', (d) => d.location)
            .attr('fill', 'green');
      }
      
      const groups  = selection
        .selectAll('.marks')
        .data(marks)
      	.join(
          (enter) => drawmark(enter),
          (update) => updatemark(),
          (exit) => exit.remove()
        );
    };
    
    my.data = function (_) {
      return arguments.length ? ((data = _), my) : data;
    };
    
    my.map_data = function (_) {
      return arguments.length ? ((map_data = _), my) : map_data;
    };
    
    my.state_centroids = function (_) {
      return arguments.length ? ((state_centroids = _), my) : state_centroids;
    };
    
    my.selected_date = function (_) {
      return arguments.length ? ((selected_date = _), my) : selected_date;
    };
    
    my.plot = function (_) {
      return arguments.length ? ((plot = _), my) : plot;
    };
    
    my.plot_group = function (_) {
      return arguments.length ? ((plot_group = _), my) : plot_group;
    };
    
    my.tooltip = function (_) {
      return arguments.length ? ((tooltip = _), my) : tooltip;
    };
    
    my.states_list = function (_) {
      return arguments.length ? ((states_list = _), my) : states_list;
    };
    
    return my;
  };

  const linePlot = () => {
    let width;
    let height;
    let state_data;
    let data;
    let xValue;
    let yValue;
    let margin;
    let line_color;
    let selected_state;
    let label_size;
  	let map_group;
    let map;
    
    const my = (selection) => {
      function filter_state(list) {
        return list.location == selected_state;
      }
      
      // Create a time scale for the x-axis
      const mindate = new Date('2021-04-01');
      const maxdate = new Date('2021-09-04');
      
      const x = d3$1.scaleTime()
        .domain([mindate, maxdate])
        .range([margin.left, width - margin.right]);

      state_data = data.filter(filter_state);

      const y = d3$1.scaleLinear()
        .domain([
          d3$1.extent(state_data, yValue)[0],
          d3$1.extent(state_data, yValue)[1] * 1.1,
        ])
        .range([height - margin.bottom, margin.top]);
      
      // animation functions
      const t = d3$1.transition().duration(500);
      
      const lineGenerator = d3.line()
      .x(d => x(xValue(d)))
      .y(d => y(yValue(d)));
      
      function filter_state(list) {
        return list.location == selected_state;
      }
      
      selection.append("path")
        .attr("fill", "none")
        .attr("stroke", "green")
        .attr("stroke-width", 1.5)
        .attr("d", lineGenerator(state_data));
      
      // redraw y axis
      selection
        .selectAll('.y-axis')
        .data([null])
        .join('g')
        .attr('class', 'y-axis')
        .attr('transform', `translate(${margin.left},0)`)
        .transition(t)
        .call(d3$1.axisLeft(y));

      // redraw x axis
      selection
        .selectAll('.x-axis')
        .data([null])
        .join('g')
        .attr('class', 'x-axis')
        .attr(
          'transform',
          `translate(0,${height - margin.bottom})`
        )
        .transition(t)
        .call(d3$1.axisBottom(x));
    };

    my.width = function (_) {
      return arguments.length ? ((width = +_), my) : width;
    };

    my.height = function (_) {
      return arguments.length ? ((height = +_), my) : height;
    };

    my.data = function (_) {
      return arguments.length ? ((data = _), my) : data;
    };

    my.xValue = function (_) {
      return arguments.length ? ((xValue = _), my) : xValue;
    };

    my.yValue = function (_) {
      return arguments.length ? ((yValue = _), my) : yValue;
    };

    my.margin = function (_) {
      return arguments.length ? ((margin = _), my) : margin;
    };

    my.line_color = function (_) {
      return arguments.length
        ? ((line_color = _), my)
        : line_color;
    };

    my.selected_state = function (_) {
      return arguments.length
        ? ((selected_state = _), my)
        : selected_state;
    };
    
    my.label_size = function (_) {
      return arguments.length
        ? ((label_size = _), my)
        : label_size;
    };
    
    my.map_group = function (_) {
      return arguments.length ? ((map_group = _), my) : map_group;
    };
    
    my.map = function (_) {
      return arguments.length ? ((map = _), my) : map;
    };

    return my;
  };

  const { 
    csv,
    select,
    json,
    brushX
  } = d3;

  // data source url
  const csvUrl = [
    'https://gist.githubusercontent.com/',
    'PeterVanNostrand/', // User
    'd449b0a3e5914278dfa79ba60e48df5d/', // Id of the Gist
    'raw/', // commit
    'vaccine_data.csv', // File name
  ].join('');

  const jsonURL = [
  	'https://gist.githubusercontent.com/',
    'PeterVanNostrand/',
    'd449b0a3e5914278dfa79ba60e48df5d/',
    'raw/',
    'state_centroids.json'
  ].join('');

  const mapURL = 'https://unpkg.com/us-atlas@3.0.0/states-10m.json';

  // parsing the dataset
  const parseRow = (d) => {
    d.date = new Date(d.date);
    d.total_vaccinations = +d.total_vaccinations;
    d.total_distributed = +d.total_distributed;
    d.people_vaccinated = +d.people_vaccinated;
    d.people_fully_vaccinated_per_hundred = +d.people_fully_vaccinated_per_hundred;
    d.total_vaccinations_per_hundred = +d.total_vaccinations_per_hundred;
    d.people_fully_vaccinated = +d.people_fully_vaccinated;
    d.people_vaccinated_per_hundred = +d.people_vaccinated_per_hundred;
    d.distributed_per_hundred = +d.distributed_per_hundred;
    d.daily_vaccinations_raw = +d.daily_vaccinations_raw;
    d.daily_vaccinations = +d.daily_vaccinations;
    d.daily_vaccinations_per_million = +d.daily_vaccinations_per_million;
    d.share_doses_used = +d.share_doses_used;
    return d;
  };

  // Select the SVG element
  const width = window.innerWidth;
  const height = window.innerHeight;

  const svg = select('body')
    .append('svg')
    .attr('width', width - 300)
    .attr('height', height - 200)
  	.attr('class', 'map_svg');

  const svg3 = select('body')
    .append('svg')
    .attr('width', 268)
    .attr('height', height - 200)
  	.attr('class', 'map_svg')
  	.attr('style', 'margin-left: 5px');

  const svg2 = select('body')
    .append('svg')
    .attr('width', width - 20)
    .attr('height', 180)
  	.attr('class', 'bar_svg');

  var tooltip = select('body')
    .append('div')
  	.append('div')
      .attr('id', 'tooltip')
  		.attr('class', 'tooltip-container')
      .style('position','absolute')
      .style('visibility', 'hidden');

  const map_tooltip = select('body')
    .append('div')
    .attr('class', 'd3-tooltip')
    .style('position', 'absolute')
    .style('z-index', '10')
    .style('visibility', 'hidden')
    .style('padding', '10px')
    .style('background', 'rgba(0,0,0,0.6)')
    .style('border-radius', '5px')
    .style('color', 'white');

  const map_group = svg.append('g');
  const map_scale = 0.6;
  map_group.attr('id', 'map_group');
  map_group.attr('transform', 'scale(0.6)');

  const bar_group = svg2.append('g');
  const bar_plot_height = 180;

  const line_group = svg3.append('g');

  let zoom = d3.zoom()
   .on('zoom', (e, d) => {
     const trans_x = e.transform.x;
     const trans_y = e.transform.y;
     const trans_scale = e.transform.k;
     map_group.attr('transform',`translate(${trans_x},${trans_y}) scale(${trans_scale * map_scale})`);
  });



  const main = async () => {
    // load data
    const data = await csv(csvUrl, parseRow);
    const us_states = await json(mapURL);
    let stateCentroids = await json(jsonURL);
    
    function onlyUnique(value, index, self) {
    	return self.indexOf(value) === index;
  	}	
  	const states_list = data
    	.map((d) => d.location)
    	.filter(onlyUnique);
     const map_plot = mapElement()
    	.data(data)
    	.map_data(us_states)
    	.state_centroids(stateCentroids)
     	.selected_date(new Date('2021-09-04'))
      .states_list(states_list)
     	.plot_group(bar_group)
     	.tooltip(map_tooltip);
    map_group.call(map_plot);
    
    // create bar plot
    const bar_plot = interactiveBar()
      .width(width - 20)
      .height(bar_plot_height)
      .data(data)
      .xValue((d) => d.date)
      .yValue((d) => d.daily_vaccinations)
      .margin({
        top: 20,
        right: 20,
        bottom: 40,
        left: 100,
      })
      .bar_width(3)
      .bar_color('#5DABF4')
    	.bar_opacity(1.0)
      .selected_state("Alabama")
    	.label_size('1em')
    	.map_group(map_group)
    	.map(map_plot);
    
    bar_group.call(bar_plot);
    
    const line_plot = linePlot()
    	.width(270)
      .height(200)
      .data(data)
      .xValue((d) => d.date)
      .yValue((d) => d.share_doses_used)
      .margin({
        top: 10,
        right: 10,
        bottom: 10,
        left: 40,
      })
      .line_color('#5DABF4')
      .selected_state("Alabama")
    	.label_size('1em')
    	.map_group(map_group)
    	.map(map_plot);
    line_group.call(line_plot);
    
    map_plot.plot(bar_plot);
    
    // create menu
    const my_menu = stateMenu()
    	.data(data)
    	.plot(bar_plot);
  	bar_group.call(my_menu);
    svg.call(zoom);

  };

  const map_legend = svg.append('g');

  let legend_x = 550;
  let legend_y = 15;
  let item_margin = 10;
  let item_size = 10;

  map_legend.append('rect')
    .attr('width', 100)
    .attr('height', 80)
  	.attr('x', legend_x)
  	.attr('y', legend_y)
  	.attr('fill', 'white')
  	.attr('stroke', 'black');

  map_legend.append('rect')
  	.attr('width', item_size)
    .attr('height', item_size)
  	.attr('x', legend_x + item_margin)
  	.attr('y', legend_y + item_margin)
  	.attr('fill', 'green');

  map_legend.append('text')
  	.attr('font-size', '0.9em')
  	.append('tspan')
    	.attr('x', legend_x + item_margin * 1.5 + item_size)
  		.attr('y', legend_y + item_margin * 1.9)
  		.text('% Availible')
  	.append('tspan')
  		.attr('x', legend_x + item_margin * 1.5 + item_size)
  		.attr('y', legend_y + item_margin * 3.1)
  		.text('Doses Used');

  map_legend.append('rect')
  	.attr('width', item_size)
    .attr('height', item_size)
  	.attr('x', legend_x + item_margin)
  	.attr('y', legend_y + item_margin * 4.5)
  	.attr('fill', 'blue');

  map_legend.append('text')
  	.attr('font-size', '0.9em')
  	.append('tspan')
    	.attr('x', legend_x + item_margin * 1.5 + item_size)
  		.attr('y', legend_y + item_margin * 5.4)
  		.text('% Populace')
  	.append('tspan')
  		.attr('x', legend_x + item_margin * 1.5 + item_size)
  		.attr('y', legend_y + item_margin * 6.9)
  		.text('Vaccinated');

  svg2.append('text')
  	.text('Daily Doses Distributed')
    .attr('x', 30)
    .attr('y', 160)
    .attr('font-size', '0.9em')
    .attr('transform', 'rotate(-90, 30, 160)');

  svg2.append('text')
  	.text('Date - 2021')
    .attr('x', width / 2 - 20)
    .attr('y', 175)
    .attr('font-size', '0.9em');

  main();

}(d3, React));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbImludGVyYWN0aXZlQmFyLmpzIiwibWVudS5qcyIsInN0YXRlTWVudS5qcyIsIm1hcEVsZW1lbnQuanMiLCJsaW5lUGxvdC5qcyIsImluZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIHNjYWxlTGluZWFyLFxuICBleHRlbnQsXG4gIGF4aXNMZWZ0LFxuICBheGlzQm90dG9tLFxuICB0cmFuc2l0aW9uLFxuICBzZWxlY3QsXG4gIHNjYWxlVGltZSxcbiAgYnJ1c2hYXG59IGZyb20gJ2QzJztcblxuXG5leHBvcnQgY29uc3QgaW50ZXJhY3RpdmVCYXIgPSAoKSA9PiB7XG4gIGxldCB3aWR0aDtcbiAgbGV0IGhlaWdodDtcbiAgbGV0IHN0YXRlX2RhdGE7XG4gIGxldCBkYXRhO1xuICBsZXQgeFZhbHVlO1xuICBsZXQgeVZhbHVlO1xuICBsZXQgbWFyZ2luO1xuICBsZXQgYmFyX3dpZHRoO1xuICBsZXQgYmFyX2NvbG9yO1xuICBsZXQgYmFyX29wYWNpdHk7XG4gIGxldCBzZWxlY3RlZF9zdGF0ZTtcbiAgbGV0IGxhYmVsX3NpemU7XG5cdGxldCBtYXBfZ3JvdXA7XG4gIGxldCBtYXA7XG4gIFxuICBjb25zdCBteSA9IChzZWxlY3Rpb24pID0+IHtcbiAgICBmdW5jdGlvbiBmaWx0ZXJfc3RhdGUobGlzdCkge1xuICAgICAgcmV0dXJuIGxpc3QubG9jYXRpb24gPT0gc2VsZWN0ZWRfc3RhdGU7XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlIGEgdGltZSBzY2FsZSBmb3IgdGhlIHgtYXhpc1xuICAgIGNvbnN0IG1pbmRhdGUgPSBuZXcgRGF0ZSgnMjAyMS0wNC0wMScpO1xuICAgIGNvbnN0IG1heGRhdGUgPSBuZXcgRGF0ZSgnMjAyMS0wOS0wNCcpO1xuICAgIGNvbnN0IHggPSBzY2FsZVRpbWUoKVxuICAgICAgLmRvbWFpbihbbWluZGF0ZSwgbWF4ZGF0ZV0pXG4gICAgICAucmFuZ2UoW21hcmdpbi5sZWZ0LCB3aWR0aCAtIG1hcmdpbi5yaWdodF0pO1xuXG4gICAgc3RhdGVfZGF0YSA9IGRhdGEuZmlsdGVyKGZpbHRlcl9zdGF0ZSk7XG5cbiAgICAvLyBjcmVhdGUgeSBzY2FsZSwgeSBpcyB1c2VkIHRvIGRldGVybWluZSB0aGUgYmFyIGhlaWdodCB5MSBpcyBqdXN0IHVzZWRcbiAgICAvLyB0byBwbG90IHRoZSBheGlzIGluIHRoZSByaWdodCBkaXJlY3Rpb25cbiAgICBjb25zdCB5ID0gc2NhbGVMaW5lYXIoKVxuICAgICAgLmRvbWFpbihbXG4gICAgICAgIGV4dGVudChzdGF0ZV9kYXRhLCB5VmFsdWUpWzFdICogMS4xLFxuICAgICAgICBleHRlbnQoc3RhdGVfZGF0YSwgeVZhbHVlKVswXSxcbiAgICAgIF0pXG4gICAgICAucmFuZ2UoW2hlaWdodCAtIG1hcmdpbi5ib3R0b20sIG1hcmdpbi50b3BdKTtcbiAgICBjb25zdCB5MSA9IHNjYWxlTGluZWFyKClcbiAgICAgIC5kb21haW4oW1xuICAgICAgICBleHRlbnQoc3RhdGVfZGF0YSwgeVZhbHVlKVswXSxcbiAgICAgICAgZXh0ZW50KHN0YXRlX2RhdGEsIHlWYWx1ZSlbMV0gKiAxLjEsXG4gICAgICBdKVxuICAgICAgLnJhbmdlKFtoZWlnaHQgLSBtYXJnaW4uYm90dG9tLCBtYXJnaW4udG9wXSk7XG5cbiAgICAvLyBjcmVhdGUgYSBzZXQgb2YgbWFya3MgdG8gdmlzdWFsaXplXG4gICAgY29uc3QgY29ycmVjdERhdGUgPSAoZCkgPT4ge1xuICAgICAgbGV0IGRhdGUgPSBuZXcgRGF0ZShkLnZhbHVlT2YoKSk7XG4gICAgICBkYXRlLnNldERhdGUoZGF0ZS5nZXREYXRlKCkgKyAzMik7XG4gICAgICByZXR1cm4gZGF0ZTtcbiAgICB9O1xuICAgIGNvbnN0IG1hcmtzID0gc3RhdGVfZGF0YS5tYXAoKGQpID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHg6IHgoeFZhbHVlKGQpKSxcbiAgICAgICAgeTogeSh5VmFsdWUoZCkpLFxuICAgICAgICBkYXRlOiBjb3JyZWN0RGF0ZShkLmRhdGUpLFxuICAgICAgICBkb3NlczogZC5kYWlseV92YWNjaW5hdGlvbnMsXG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgLy8gaG92ZXIgYW5pbWF0aW9uIGZ1bmN0aW9uc1xuICAgIGZ1bmN0aW9uIGhhbmRsZV9tb3VzZV9vdmVyKGUsIGQpIHtcbiAgICAgIC8vIGNvbnNvbGUubG9nKCdtb3ZlcicpO1xuICAgICAgc2VsZWN0aW9uXG4gICAgICAgIC5zZWxlY3RBbGwoJ3JlY3QnKVxuICAgICAgICAudHJhbnNpdGlvbigpXG4gICAgICAgIC5kdXJhdGlvbignMTAwJylcbiAgICAgICAgLmF0dHIoJ29wYWNpdHknLCBiYXJfb3BhY2l0eSAvIDIpO1xuICAgICAgc2VsZWN0KHRoaXMpXG4gICAgICAgIC50cmFuc2l0aW9uKClcbiAgICAgICAgLmR1cmF0aW9uKCcxMDAnKVxuICAgICAgICAuYXR0cignb3BhY2l0eScsIGJhcl9vcGFjaXR5KTtcbiAgICAgIHNlbGVjdCgnI3Rvb2x0aXAnKVxuICAgICAgICAuc3R5bGUoJ3Zpc2liaWxpdHknLCAndmlzaWJsZScpXG4gICAgICAgIC50ZXh0KFxuICAgICAgICAgICdEYXRlOiAnICtcbiAgICAgICAgICAgIGQuZGF0ZS5nZXRNb250aCgpICtcbiAgICAgICAgICAgICcvJyArXG4gICAgICAgICAgICBkLmRhdGUuZ2V0RGF0ZSgpICtcbiAgICAgICAgICAgICcsIERvc2VzOiAnICtcbiAgICAgICAgICAgIGQuZG9zZXNcbiAgICAgICAgKTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBoYW5kbGVfbW91c2VfbW92ZShlLCBkKSB7XG4gICAgICAvLyBjb25zb2xlLmxvZyhldmVudC5QYWdlWCwgZXZlbnQuUGFnZVkpO1xuICAgICAgc2VsZWN0KCcjdG9vbHRpcCcpXG4gICAgICAgIC5zdHlsZSgndG9wJywgZXZlbnQucGFnZVkgLSAyNSArICdweCcpXG4gICAgICAgIC5zdHlsZSgnbGVmdCcsIGV2ZW50LnBhZ2VYICsgJ3B4Jyk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gaGFuZGxlX21vdXNlX291dChlLCBkKSB7XG4gICAgICBzZWxlY3Rpb25cbiAgICAgICAgLnNlbGVjdEFsbCgncmVjdCcpXG4gICAgICAgIC50cmFuc2l0aW9uKClcbiAgICAgICAgLmR1cmF0aW9uKCcxMDAnKVxuICAgICAgICAuYXR0cignb3BhY2l0eScsIGJhcl9vcGFjaXR5KTtcbiAgICAgIHNlbGVjdCgnI3Rvb2x0aXAnKS5zdHlsZSgndmlzaWJpbGl0eScsICdoaWRkZW4nKTtcbiAgICB9XG4gICAgXG4gICAgLy8gYW5pbWF0aW9uIGZ1bmN0aW9uc1xuICAgIGNvbnN0IHQgPSB0cmFuc2l0aW9uKCkuZHVyYXRpb24oNTAwKTtcbiAgICBjb25zdCBwb3NpdGlvbkJhcnMgPSAoYmFycykgPT4ge1xuICAgICAgYmFyc1xuICAgICAgICAuYXR0cigneCcsIChkKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQueCArIGJhcl93aWR0aCAvIDI7XG4gICAgICAgIH0pXG4gICAgICAgIC5hdHRyKCd5JywgKGQpID0+IHtcbiAgICAgICAgICAvLyBwbGFjZSB0aGUgYm90dG9tIG9mIGVhY2ggYmFyIGF0IHRoZSB4LWF4aXNcbiAgICAgICAgICByZXR1cm4gaGVpZ2h0IC0gbWFyZ2luLmJvdHRvbSAtIGQueTtcbiAgICAgICAgfSlcbiAgICAgICAgLmF0dHIoJ2ZpbGwnLCBiYXJfY29sb3IpXG4gICAgICAgIC5hdHRyKCdvcGFjaXR5JywgYmFyX29wYWNpdHkpXG4gICAgICAgIC5hdHRyKCdoZWlnaHQnLCAoZCkgPT4gZC55KTtcbiAgICB9O1xuXG4gICAgY29uc3Qgc2V0X2hhbmRsZXJzID0gKGJhcnMpID0+IHtcbiAgICAgIGJhcnMub24oJ21vdXNlb3ZlcicsIGhhbmRsZV9tb3VzZV9vdmVyKTtcbiAgICAgIGJhcnMub24oJ21vdXNlbW92ZScsIGhhbmRsZV9tb3VzZV9tb3ZlKTtcbiAgICAgIGJhcnMub24oJ21vdXNlb3V0JywgaGFuZGxlX21vdXNlX291dCk7XG4gICAgfTtcbiAgICBcbiAgICBjb25zdCBpbml0aWFsaXplV2lkdGggPSAoYmFycykgPT4ge1xuICAgICAgYmFycy5hdHRyKCd3aWR0aCcsIDApO1xuICAgICAgYmFycy5hdHRyKCdoZWlnaHQnLCAwKTtcbiAgICB9O1xuICAgIGNvbnN0IGdyb3dXaWR0aCA9IChlbnRlcikgPT4ge1xuICAgICAgZW50ZXIudHJhbnNpdGlvbih0KS5hdHRyKCd3aWR0aCcsIGJhcl93aWR0aCk7XG4gICAgICBlbnRlci50cmFuc2l0aW9uKHQpLmF0dHIoJ2hlaWdodCcsIChkKSA9PiBkLnkpO1xuICAgIH07XG5cblxuICAgIC8vIGRyYXcgdGhlIGJhcnNcbiAgICBjb25zdCBiYXJzID0gc2VsZWN0aW9uXG4gICAgICAuc2VsZWN0QWxsKCdyZWN0JylcbiAgICAgIC5kYXRhKG1hcmtzKVxuICAgICAgLmpvaW4oXG4gICAgICAgIChlbnRlcikgPT5cbiAgICAgICAgICBlbnRlclxuICAgICAgICAgICAgLmFwcGVuZCgncmVjdCcpXG4gICAgICAgIFx0XHQuYXR0cihcInBvaW50ZXItZXZlbnRzXCIsIFwiYWxsXCIpXG4gICAgICAgICAgICAuY2FsbChwb3NpdGlvbkJhcnMpXG4gICAgICAgICAgICAuY2FsbChpbml0aWFsaXplV2lkdGgpXG4gICAgICAgICAgICAuY2FsbChncm93V2lkdGgpXG4gICAgICAgIFx0XHQuY2FsbChzZXRfaGFuZGxlcnMpLFxuICAgICAgICAodXBkYXRlKSA9PlxuICAgICAgICAgIHVwZGF0ZS5jYWxsKCh1cGRhdGUpID0+XG4gICAgICAgICAgICB1cGRhdGVcbiAgICAgICAgICAgICAgLnRyYW5zaXRpb24odClcbiAgICAgICAgICAgICAgLmRlbGF5KChkLCBpKSA9PiBpICogMTApXG4gICAgICAgICAgICAgIC5jYWxsKHBvc2l0aW9uQmFycylcbiAgICAgICAgICApLFxuICAgICAgICAoZXhpdCkgPT4gZXhpdC5yZW1vdmUoKVxuICAgICAgKTtcbiAgICAvLyByZWRyYXcgeSBheGlzXG4gICAgc2VsZWN0aW9uXG4gICAgICAuc2VsZWN0QWxsKCcueS1heGlzJylcbiAgICAgIC5kYXRhKFtudWxsXSlcbiAgICAgIC5qb2luKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsICd5LWF4aXMnKVxuICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIGB0cmFuc2xhdGUoJHttYXJnaW4ubGVmdH0sMClgKVxuICAgICAgLnRyYW5zaXRpb24odClcbiAgICAgIC5jYWxsKGF4aXNMZWZ0KHkxKSk7XG5cbiAgICAvLyByZWRyYXcgeCBheGlzXG4gICAgc2VsZWN0aW9uXG4gICAgICAuc2VsZWN0QWxsKCcueC1heGlzJylcbiAgICAgIC5kYXRhKFtudWxsXSlcbiAgICAgIC5qb2luKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsICd4LWF4aXMnKVxuICAgICAgLmF0dHIoXG4gICAgICAgICd0cmFuc2Zvcm0nLFxuICAgICAgICBgdHJhbnNsYXRlKDAsJHtoZWlnaHQgLSBtYXJnaW4uYm90dG9tfSlgXG4gICAgICApXG4gICAgICAudHJhbnNpdGlvbih0KVxuICAgICAgLmNhbGwoYXhpc0JvdHRvbSh4KSk7XG4gICAgXG4gICAgLy8gYnJ1c2hpbmdcbiAgICBmdW5jdGlvbiBicnVzaGVkKGUsIGQpe1xuICAgICAgY29uc3QgYnJ1c2hfYXJlYSA9IGUuc2VsZWN0aW9uO1xuICAgICAgXG4gICAgICBsZXQgZW5kX2RhdGUgPSBuZXcgRGF0ZSgnMjAyMS0wOS0wNCcpO1xuICAgICAgaWYoYnJ1c2hfYXJlYSl7XG4gICAgICAgIGNvbnN0IHN0YXJ0X2RhdGUgPSB4LmludmVydChicnVzaF9hcmVhWzBdKTtcbiAgICAgIFx0ZW5kX2RhdGUgPSB4LmludmVydChicnVzaF9hcmVhWzFdKTtcbiAgICAgIH1cbiAgICAgIG1hcF9ncm91cC5jYWxsKG1hcC5zZWxlY3RlZF9kYXRlKGVuZF9kYXRlKSk7XG4gICAgfVxuICAgIGNvbnN0IGJydXNoID0gYnJ1c2hYKClcbiAgICAgIC5leHRlbnQoW1swLDBdLCBbd2lkdGgsIGhlaWdodF1dKVxuICAgICAgLm9uKFwiYnJ1c2ggZW5kXCIsIGJydXNoZWQpO1xuICAgIHNlbGVjdGlvbi5jYWxsKGJydXNoKTtcbiAgICAvLyBzZWxlY3QoJy5vdmVybGF5JykuYXR0cignZGlzcGxheScsICdub25lJyk7XG4gICAgXG4gICAgLy8gQWRkIGF4aXMgbGFiZWxzXG4gICAgc2VsZWN0aW9uXG4gICAgICAuc2VsZWN0QWxsKCcueC1heGlzLWxhYmVsJylcbiAgICBcdC5kYXRhKFtudWxsXSlcbiAgICBcdC5qb2luKCd0ZXh0JylcbiAgICAgIC5hdHRyKCd5JywgaGVpZ2h0IC0gMTApXG4gICAgICAuYXR0cigneCcsIHdpZHRoIC8gMiAtIDEwKVxuICAgICAgLnRleHQoJ0RhdGUsIDIwMjEnKVxuICAgICAgLmF0dHIoJ2ZvbnQtc2l6ZScsIGxhYmVsX3NpemUpXG4gICAgXHQuYXR0cignY2xhc3MnLCAneC1heGlzLWxhYmVsJyk7XG4gICAgXG4gICAgc2VsZWN0aW9uXG4gICAgICAuc2VsZWN0QWxsKCcueS1heGlzLWxhYmVsJylcbiAgICBcdC5kYXRhKFtudWxsXSlcbiAgICBcdC5qb2luKCd0ZXh0JylcbiAgICAgIC5hdHRyKCd4JywgMClcbiAgICAgIC5hdHRyKCd5JywgaGVpZ2h0LzItMjApXG4gICAgICAudGV4dCgnRGFpbHkgRG9zZXMgRGlzdHJpYnV0ZWQnKVxuICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIGByb3RhdGUoMjcwLCA3MCwgJHtoZWlnaHQvMn0pYClcbiAgICAgIC5hdHRyKCdmb250LXNpemUnLCBsYWJlbF9zaXplKVxuICAgIFx0LmF0dHIoJ2NsYXNzJywgJ3ktYXhpcy1sYWJlbCcpO1xuICB9O1xuXG4gIG15LndpZHRoID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgod2lkdGggPSArXyksIG15KSA6IHdpZHRoO1xuICB9O1xuXG4gIG15LmhlaWdodCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKGhlaWdodCA9ICtfKSwgbXkpIDogaGVpZ2h0O1xuICB9O1xuXG4gIG15LmRhdGEgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChkYXRhID0gXyksIG15KSA6IGRhdGE7XG4gIH07XG5cbiAgbXkueFZhbHVlID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgoeFZhbHVlID0gXyksIG15KSA6IHhWYWx1ZTtcbiAgfTtcblxuICBteS55VmFsdWUgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKCh5VmFsdWUgPSBfKSwgbXkpIDogeVZhbHVlO1xuICB9O1xuXG4gIG15Lm1hcmdpbiA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKG1hcmdpbiA9IF8pLCBteSkgOiBtYXJnaW47XG4gIH07XG5cbiAgbXkuYmFyX3dpZHRoID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aFxuICAgICAgPyAoKGJhcl93aWR0aCA9ICtfKSwgbXkpXG4gICAgICA6IGJhcl93aWR0aDtcbiAgfTtcblxuICBteS5iYXJfb3BhY2l0eSA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGhcbiAgICAgID8gKChiYXJfb3BhY2l0eSA9ICtfKSwgbXkpXG4gICAgICA6IGJhcl9vcGFjaXR5O1xuICB9O1xuXG4gIG15LmJhcl9jb2xvciA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGhcbiAgICAgID8gKChiYXJfY29sb3IgPSBfKSwgbXkpXG4gICAgICA6IGJhcl9jb2xvcjtcbiAgfTtcblxuICBteS5zZWxlY3RlZF9zdGF0ZSA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGhcbiAgICAgID8gKChzZWxlY3RlZF9zdGF0ZSA9IF8pLCBteSlcbiAgICAgIDogc2VsZWN0ZWRfc3RhdGU7XG4gIH07XG4gIFxuICBteS5sYWJlbF9zaXplID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aFxuICAgICAgPyAoKGxhYmVsX3NpemUgPSBfKSwgbXkpXG4gICAgICA6IGxhYmVsX3NpemU7XG4gIH07XG4gIFxuICBteS5tYXBfZ3JvdXAgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChtYXBfZ3JvdXAgPSBfKSwgbXkpIDogbWFwX2dyb3VwO1xuICB9O1xuICBcbiAgbXkubWFwID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgobWFwID0gXyksIG15KSA6IG1hcDtcbiAgfTtcblxuICByZXR1cm4gbXk7XG59O1xuIiwiaW1wb3J0IHsgZGlzcGF0Y2ggfSBmcm9tICdkMyc7XG5leHBvcnQgY29uc3QgbWVudSA9ICgpID0+IHtcbiAgbGV0IGlkO1xuICBsZXQgbGFiZWxUZXh0O1xuICBsZXQgb3B0aW9ucztcbiAgY29uc3QgbGlzdGVuZXJzID0gZGlzcGF0Y2goJ2NoYW5nZScpO1xuICBcbiAgY29uc3QgbXkgPSAoc2VsZWN0aW9uKSA9PiB7XG4gICAgc2VsZWN0aW9uXG4gICAgICAuc2VsZWN0QWxsKCdsYWJlbCcpXG4gICAgICAuZGF0YShbbnVsbF0pXG4gICAgICAuam9pbignbGFiZWwnKVxuICAgICAgLmF0dHIoJ2ZvcicsIGlkKVxuICAgICAgLnRleHQobGFiZWxUZXh0KTtcblxuICAgIHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgnc2VsZWN0JylcbiAgICAgIC5kYXRhKFtudWxsXSlcbiAgICAgIC5qb2luKCdzZWxlY3QnKVxuICAgICAgLmF0dHIoJ2lkJywgaWQpXG4gICAgICAub24oJ2NoYW5nZScsIChldmVudCkgPT4ge1xuICAgICAgICBsaXN0ZW5lcnMuY2FsbCgnY2hhbmdlJywgbnVsbCwgZXZlbnQudGFyZ2V0LnZhbHVlKTtcbiAgICAgIH0pXG4gICAgICAuc2VsZWN0QWxsKCdvcHRpb24nKVxuICAgICAgLmRhdGEob3B0aW9ucylcbiAgICAgIC5qb2luKCdvcHRpb24nKVxuICAgICAgLmF0dHIoJ3ZhbHVlJywgKGQpID0+IGQudmFsdWUpXG4gICAgICAudGV4dCgoZCkgPT4gZC50ZXh0KTtcbiAgfTtcblxuICBteS5pZCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKGlkID0gXyksIG15KSA6IGlkO1xuICB9O1xuXG4gIG15LmxhYmVsVGV4dCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGhcbiAgICAgID8gKChsYWJlbFRleHQgPSBfKSwgbXkpXG4gICAgICA6IGxhYmVsVGV4dDtcbiAgfTtcblxuICBteS5vcHRpb25zID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgob3B0aW9ucyA9IF8pLCBteSkgOiBvcHRpb25zO1xuICB9O1xuXG4gIG15Lm9uID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciB2YWx1ZSA9IGxpc3RlbmVycy5vbi5hcHBseShsaXN0ZW5lcnMsIGFyZ3VtZW50cyk7XG4gICAgcmV0dXJuIHZhbHVlID09PSBsaXN0ZW5lcnMgPyBteSA6IHZhbHVlO1xuICB9O1xuXG4gIHJldHVybiBteTtcbn07XG4iLCJpbXBvcnQge1xuICBtYXgsXG4gIGdlb0FsYmVyc1VzYSxcbiAgZ2VvUGF0aCxcbiAgc2VsZWN0XG59IGZyb20gJ2QzJztcbmltcG9ydCB7IG1lbnUgfSBmcm9tICcuL21lbnUnO1xuXG5leHBvcnQgY29uc3Qgc3RhdGVNZW51ID0gKCkgPT4ge1xuICBsZXQgd2lkdGg7XG4gIGxldCBoZWlnaHQ7XG4gIGxldCBkYXRhO1xuICBsZXQgcGxvdDtcbiAgXG4gIGNvbnN0IG15ID0gKHNlbGVjdGlvbikgPT4ge1xuICAgIGNvbnN0IG1lbnVDb250YWluZXIgPSBzZWxlY3QoJ2JvZHknKVxuICAgIFx0LmFwcGVuZCgnZGl2JylcbiAgICBcdC5hdHRyKCdjbGFzcycsICdtZW51LWNvbnRhaW5lcicpO1xuICAgIGNvbnN0IHN0YXRlX21lbnUgPSBtZW51Q29udGFpbmVyLmFwcGVuZCgnZGl2Jyk7XG4gICAgY29uc3QgeU1lbnUgPSBtZW51Q29udGFpbmVyLmFwcGVuZCgnZGl2Jyk7XG4gICAgXG4gICAgZnVuY3Rpb24gb25seVVuaXF1ZSh2YWx1ZSwgaW5kZXgsIHNlbGYpIHtcbiAgICAgIHJldHVybiBzZWxmLmluZGV4T2YodmFsdWUpID09PSBpbmRleDtcbiAgICB9XG4gICAgY29uc3Qgc3RhdGVzID0gZGF0YVxuICAgICAgLm1hcCgoZCkgPT4gZC5sb2NhdGlvbilcbiAgICAgIC5maWx0ZXIob25seVVuaXF1ZSk7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHN0YXRlcy5tYXAoKGQpID0+IHtcbiAgICAgIHJldHVybiB7IHZhbHVlOiBkLCB0ZXh0OiBkIH07XG4gICAgfSk7XG4gICAgXG4gICAgc3RhdGVfbWVudS5jYWxsKFxuICAgICAgbWVudSgpXG4gICAgICAgIC5pZCgnc3RhdGUtbWVudScpXG4gICAgICAgIC5sYWJlbFRleHQoJ1N0YXRlOicpXG4gICAgICAgIC5vcHRpb25zKG9wdGlvbnMpXG4gICAgICAgIC5vbignY2hhbmdlJywgKHN0YXRlKSA9PiB7XG4gICAgICAgICAgc2VsZWN0aW9uLmNhbGwoXG4gICAgICAgICAgICBwbG90LnNlbGVjdGVkX3N0YXRlKHN0YXRlKVxuICAgICAgICAgICk7XG4gICAgICAgIH0pXG4gICAgKTtcbiAgfTtcblxuICBteS5kYXRhID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgoZGF0YSA9IF8pLCBteSkgOiBkYXRhO1xuICB9O1xuICAgIFxuICBteS5wbG90ID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgocGxvdCA9IF8pLCBteSkgOiBwbG90O1xuICB9O1xuICBcbiAgcmV0dXJuIG15O1xufTtcbiIsImltcG9ydCB7XG4gIG1heCxcbiAgZ2VvQWxiZXJzVXNhLFxuICBnZW9QYXRoLFxuICB0b3Bqc29uLFxuICB0cmFuc2l0aW9uLFxuICBmb3JjZVNpbXVsYXRpb24sXG4gIGZvcmNlQ29sbGlkZSxcbiAgZm9yY2VYLFxuICBmb3JjZVksXG4gIGFyYyxcbiAgc2NhbGVTcXJ0LFxuICBzZWxlY3Rcbn0gZnJvbSAnZDMnO1xuXG5cblxuXG5cbmV4cG9ydCBjb25zdCBtYXBFbGVtZW50ID0gKCkgPT4ge1xuICBsZXQgd2lkdGg7XG4gIGxldCBoZWlnaHQ7XG4gIGxldCBkYXRhO1xuICBsZXQgbWFwX2RhdGE7XG4gIGxldCBzdGF0ZV9jZW50cm9pZHM7XG4gIGxldCBzZWxlY3RlZF9kYXRlO1xuICBsZXQgbWFya3M7XG4gIGxldCB0b29sdGlwO1xuICBsZXQgcGxvdDtcbiAgbGV0IHBsb3RfZ3JvdXA7XG4gIGxldCBzdGF0ZXNfbGlzdDtcbiAgXG4gIGZ1bmN0aW9uIG1hcF9tb3VzZV9tb3ZlKGUsZCkge1xuICAgIHRvb2x0aXBcbiAgICAgIC5zdHlsZSgndG9wJywgZXZlbnQucGFnZVkgLSAxMCArICdweCcpXG4gICAgICAuc3R5bGUoJ2xlZnQnLCBldmVudC5wYWdlWCArIDEwICsgJ3B4Jyk7XG4gIH1cblxuICBmdW5jdGlvbiBtYXBfbW91c2Vfb24oZSxkKXtcbiAgICAvLyBob3ZlciBvbiBkb3VnbnV0IHBsb3QgZ3JvdXBcbiAgICBpZihkLmxvY2F0aW9uKXtcbiAgICAgIHRvb2x0aXBcbiAgICAgIC5odG1sKFxuICAgICAgICBgU3RhdGU6ICR7ZC5sb2NhdGlvbn1gXG4gICAgICApXG4gICAgICAuc3R5bGUoJ3Zpc2liaWxpdHknLCAndmlzaWJsZScpO1xuICAgIH1cbiAgICAvLyBob3ZlciBvbiBzdGF0ZSBwYXRoXG4gICAgaWYoZC5wcm9wZXJ0aWVzKXtcbiAgICAgIHRvb2x0aXBcbiAgICAgIC5odG1sKFxuICAgICAgICBgU3RhdGU6ICR7ZC5wcm9wZXJ0aWVzLm5hbWV9YFxuICAgICAgKVxuICAgICAgLnN0eWxlKCd2aXNpYmlsaXR5JywgJ3Zpc2libGUnKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBtYXBfbW91c2Vfb3V0KGUsZCkge1xuICAgICAgdG9vbHRpcC5odG1sKGBgKS5zdHlsZSgndmlzaWJpbGl0eScsICdoaWRkZW4nKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHVwZGF0ZV9kcm9wZG93bihzZWxlY3RlZF9zdGF0ZSl7XG4gICAgaWYoZGF0YSl7XG4gICAgXHRjb25zdCBzdGF0ZV9pbmRleCA9IHN0YXRlc19saXN0LmZpbmRJbmRleCgoZikgPT4geyByZXR1cm4gZiA+IHNlbGVjdGVkX3N0YXRlIH0pO1xuICAgIFx0Y29uc3QgZHJvcGRvd24gPSBzZWxlY3QoJyNzdGF0ZS1tZW51Jyk7XG4gICAgXHRkcm9wZG93bi5wcm9wZXJ0eSgnc2VsZWN0ZWRJbmRleCcsIHN0YXRlX2luZGV4LTEpO1xuICAgIH1cbiAgfVxuICBcbiAgZnVuY3Rpb24gbWFwX21vdXNlX2NsaWNrKGUsZCkge1xuICAgIC8vIGNsaWNrIG9uIGRvdWdudXQgcGxvdCBncm91cFxuICAgIGlmKGQubG9jYXRpb24pe1xuICAgICAgcGxvdF9ncm91cC5jYWxsKFxuICAgICAgICBwbG90LnNlbGVjdGVkX3N0YXRlKGQubG9jYXRpb24pXG4gICAgICApO1xuICAgICAgdXBkYXRlX2Ryb3Bkb3duKGQubG9jYXRpb24pXG4gICAgfVxuICAgIC8vIGNsaWNrIG9uIHN0YXRlIHBhdGhcbiAgICBpZihkLnByb3BlcnRpZXMgJiYgZC5wcm9wZXJ0aWVzLm5hbWUpe1xuICAgICAgcGxvdF9ncm91cC5jYWxsKFxuICAgICAgICBwbG90LnNlbGVjdGVkX3N0YXRlKGQucHJvcGVydGllcy5uYW1lKVxuICAgICAgKTtcbiAgICAgIHVwZGF0ZV9kcm9wZG93bihkLnByb3BlcnRpZXMubmFtZSlcbiAgICB9XG4gIH1cbiAgICBcbiAgY29uc3QgbXkgPSAoc2VsZWN0aW9uKSA9PiB7XG4gIFx0Y29uc3QgcHJvamVjdGlvbiA9IGdlb0FsYmVyc1VzYSgpO1xuICAgIGNvbnN0IHBhdGggPSBnZW9QYXRoKHByb2plY3Rpb24pO1xuICAgIFxuICAgIGNvbnN0IHN0YXRlcyA9IHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgncGF0aCcpXG4gICAgICAuZGF0YSh0b3BvanNvbi5mZWF0dXJlKG1hcF9kYXRhLCBtYXBfZGF0YS5vYmplY3RzLnN0YXRlcykuZmVhdHVyZXMpXG4gICAgICAuam9pbihcbiAgICAgICAgKGVudGVyKSA9PlxuICAgICAgICAgIGVudGVyXG4gICAgICAgICAgICAuYXBwZW5kKCdwYXRoJylcbiAgICAgICAgICAgIC5hdHRyKCdkJywgcGF0aClcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiBkLnByb3BlcnRpZXMubmFtZSlcbiAgICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiBkLmxvY2F0aW9uKVxuICAgICAgICAgICAgLmF0dHIoJ3N0cm9rZScsICdibGFjaycpXG4gICAgICAgICAgICAuYXR0cignZmlsbCcsICdsaWdodGdyYXknKVxuICAgICAgICBcdFx0Lm9uKCdtb3VzZW92ZXInLCBtYXBfbW91c2Vfb24pXG4gICAgICAgIFx0XHQub24oJ21vdXNlbW92ZScsIG1hcF9tb3VzZV9tb3ZlKVxuICAgICAgICBcdFx0Lm9uKCdtb3VzZW91dCcsIG1hcF9tb3VzZV9vdXQpXG4gICAgICAgIFx0XHQub24oJ21vdXNlZG93bicsIG1hcF9tb3VzZV9jbGljayksXG4gICAgICAgICh1cGRhdGUpID0+XG4gICAgICAgICAgdXBkYXRlLmNhbGwoKHVwZGF0ZSkgPT51cGRhdGUpLFxuICAgICAgICAoZXhpdCkgPT4gZXhpdC5yZW1vdmUoKVxuICAgICAgKTtcbiAgICBcbiAgICAvLyBjb25zdCBzZWxlY3RlZF9kYXRlID0gbmV3IERhdGUoJzIwMjEtMDktMDQnKTtcbiAgICBmdW5jdGlvbiBmaWx0ZXJfZGF0ZShsaXN0KSB7XG4gICAgICByZXR1cm4gbGlzdC5kYXRlLmdldERhdGUoKSA9PSBzZWxlY3RlZF9kYXRlLmdldERhdGUoKSYmIFxuICAgICAgICBsaXN0LmRhdGUuZ2V0TW9udGgoKSA9PSBzZWxlY3RlZF9kYXRlLmdldE1vbnRoKCkmJiBcbiAgICAgICAgbGlzdC5kYXRlLmdldEZ1bGxZZWFyKCkgPT0gc2VsZWN0ZWRfZGF0ZS5nZXRGdWxsWWVhcigpO1xuICAgIH1cbiAgICBjb25zdCBkYXRlX2RhdGEgPSBkYXRhLmZpbHRlcihmaWx0ZXJfZGF0ZSk7ICBcbiAgICBcbiAgICBsZXQgbXlfc3RhdGUgPSBcIkNhbGlmb3JuaWFcIlxuICAgIGZ1bmN0aW9uIGdldF9zdGF0ZV9jZW50cm9pZChjZW50cm9pZHMpIHtcbiAgICAgIHJldHVybiBjZW50cm9pZHMubmFtZSA9PSBteV9zdGF0ZTtcbiAgICB9XG5cbiAgICBsZXQgbWFya3MgPSBkYXRlX2RhdGEubWFwKChkKSA9PiB7XG4gICAgICBteV9zdGF0ZSA9IGQubG9jYXRpb247XG4gICAgICBjb25zdCBjZW50ZXIgPSBzdGF0ZV9jZW50cm9pZHMuZmlsdGVyKGdldF9zdGF0ZV9jZW50cm9pZClbMF07XG4gICAgICBpZihjZW50ZXIpXG4gICAgICAgIHJldHVybiB7IFxuICAgICAgICAgIGxvY2F0aW9uIDogZC5sb2NhdGlvbixcbiAgICAgICAgICBsYXQgOiBjZW50ZXIubGF0LFxuICAgICAgICAgIGxvbiA6IGNlbnRlci5sb24sXG4gICAgICAgICAgZnVsbCA6IGQucGVvcGxlX2Z1bGx5X3ZhY2NpbmF0ZWRfcGVyX2h1bmRyZWQsXG4gICAgICAgICAgcGFydCA6IGQucGVvcGxlX3ZhY2NpbmF0ZWRfcGVyX2h1bmRyZWQsXG4gICAgICAgICAgZG9zZXMgOiBkLnNoYXJlX2Rvc2VzX3VzZWRcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIFxuICAgIG1hcmtzID0gbWFya3MuZmlsdGVyKGZ1bmN0aW9uKCBlbGVtZW50ICkge1xuICAgICByZXR1cm4gZWxlbWVudCAhPT0gdW5kZWZpbmVkO1xuICAgIH0pO1xuXG4gICAgY29uc3QgaGlnaGVzdF92YWNjID0gbWF4KG1hcmtzLCBmdW5jdGlvbiAoZCkge1xuICAgICAgICByZXR1cm4gZC5mdWxsO1xuICAgIH0pO1xuICAgIFxuICAgIC8vIEFSQyBTVFVGRlxuICAgIGxldCByaW5nX3dpZHRoID0gNztcbiAgICBsZXQgcmluZ19yYWRpdXMgPSAxMjtcbiAgICBmdW5jdGlvbiBnZW5lcmF0ZUFyYyhkLCBiYXNlX3JhZGl1cywgdmFsdWUpIHtcbiAgICBcdGxldCBpbm5lciA9IGJhc2VfcmFkaXVzO1xuICAgICAgbGV0IG91dGVyID0gYmFzZV9yYWRpdXMgKyByaW5nX3dpZHRoO1xuICAgICAgbGV0IGFuZ2xlID0gKHZhbHVlKGQpIC8gMTAwKSAqIDIqTWF0aC5QSTtcbiAgICAgIGxldCBhcmNHZW4gPSBhcmMoKVxuICAgICAgICAuaW5uZXJSYWRpdXMoaW5uZXIpXG4gICAgICAgIC5vdXRlclJhZGl1cyhvdXRlcilcbiAgICAgICAgLnN0YXJ0QW5nbGUoMClcbiAgICAgICAgLmVuZEFuZ2xlKGFuZ2xlKTtcbiAgICAgIHJldHVybiBhcmNHZW4oZCk7XG4gICAgfVxuICAgIC8vIEVORCBBUkMgU1RVRkZcbiAgXG4gICAgY29uc3QgY2lyY2xlUmFkaXVzID0gZDNcbiAgICAgIC5zY2FsZVNxcnQoKVxuICAgICAgLmRvbWFpbihbMCwgaGlnaGVzdF92YWNjXSlcbiAgICAgIC5yYW5nZShbMCwgMjVdKTsgLy8gMCB0byBtYXhpbXVtIHJhZGl1cyBpbiBwaXhlbHNcbiAgICBcbiAgIFx0ZnVuY3Rpb24gcmFkaXVzIChkKSB7IFxuICAgICAgIHJldHVybiByaW5nX3JhZGl1cztcbiAgICB9XHRcblxuICAgIHZhciBzaW11bGF0aW9uID0gZm9yY2VTaW11bGF0aW9uKG1hcmtzKVxuICAgICAgLmZvcmNlKFwieFwiLCBmb3JjZVgoZnVuY3Rpb24oZCkge1xuICAgICAgICByZXR1cm4gcHJvamVjdGlvbihbK2QubG9uLCtkLmxhdF0pWzBdO1xuICAgICAgfSkpXG4gICAgICAuZm9yY2UoXCJ5XCIsIGZvcmNlWShmdW5jdGlvbihkKSB7XG4gICAgICAgIHJldHVybiBwcm9qZWN0aW9uKFsrZC5sb24sK2QubGF0XSlbMV07XG4gICAgICB9KSlcbiAgICAgIC5mb3JjZShcImNvbGxpZGVcIiwgZm9yY2VDb2xsaWRlKGQgPT4gcmFkaXVzKGQpICsgcmluZ193aWR0aCoyICsgMSkpXG4gICAgICAuc3RvcCgpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMTIwOyArK2kpIHNpbXVsYXRpb24udGljaygpO1xuICAgICAgIFxuICAgIFxuICAgIGNvbnN0IHZhY2NfdmFsdWUgPSAoZCkgPT4gZC5mdWxsO1xuICAgIGNvbnN0IGRvc2VfdmFsdWUgPSAoZCkgPT4gZC5kb3NlcyAqIDEwMDtcbiAgICBcbiAgICBmdW5jdGlvbiBkcmF3bWFyayAoZW50ZXIpe1xuICAgICAgbGV0IGcgPSBlbnRlci5hcHBlbmQoJ2cnKS5hdHRyKCdjbGFzcycsICdtYXJrcycpO1xuICAgICAgXG4gICAgICBnLmFwcGVuZCgnY2lyY2xlJylcbiAgICAgIFx0XHQuYXR0cignY2xhc3MnLCAnY2lyY2xlcycpXG4gICAgICAgICAgLmF0dHIoJ2N4JywgKGQpID0+IGQueClcbiAgICAgICAgICAuYXR0cignY3knLCAoZCkgPT4gZC55KVxuICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiBkLmxvY2F0aW9uKVxuICAgICAgICAgIC5hdHRyKCdmaWxsJywgJyNlMGRjZGMnKVxuICAgICAgICAgIC5hdHRyKCdzdHJva2UnLCAnYmxhY2snKVxuICAgICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCAyKVxuICAgICAgICAgIC5hdHRyKCdvcGFjaXR5JywgMSlcbiAgICAgICAgICAuYXR0cigncicsIGQgPT4gcmFkaXVzKGQpICsgcmluZ193aWR0aCoyKTtcbiAgICAgIFxuICAgICAgZy5hcHBlbmQoXCJ0ZXh0XCIpXG4gICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ3ZhY2MtdGV4dCcpXG4gICAgICAgICAgLmF0dHIoJ3gnLCAoZCkgPT4gZC54IC0gMTApXG4gICAgICAgICAgLmF0dHIoJ3knLCAoZCkgPT4gZC55ICsgNSlcbiAgICAgICAgICAudGV4dCgoZCkgPT4gXCJcIiArIHBhcnNlSW50KGQuZnVsbCkpO1xuICAgICAgXG4gICAgICBnLmFwcGVuZChcInBhdGhcIilcbiAgICAgICAgICAuYXR0cignY2xhc3MnLCAndmFjYy1yaW5ncycpXG4gICAgICAgICAgLmF0dHIoXCJkXCIsIGQgPT4ge3JldHVybiBnZW5lcmF0ZUFyYyhkLCByaW5nX3JhZGl1cywgdmFjY192YWx1ZSl9KVxuICAgICAgICAgIC5hdHRyKFwidHJhbnNmb3JtXCIsIGQgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIFwidHJhbnNsYXRlKFwiICsgW2QueCwgZC55XSArIFwiKVwiO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ2lkJywgKGQpID0+IGQubG9jYXRpb24pXG4gICAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnYmx1ZScpXG4gICAgICBcbiAgICAgIGcuYXBwZW5kKFwicGF0aFwiKVxuICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdkb3NlLXJpbmdzJylcbiAgICAgICAgICAuYXR0cihcImRcIiwgZCA9PiB7cmV0dXJuIGdlbmVyYXRlQXJjKGQsIHJpbmdfd2lkdGggKyByaW5nX3JhZGl1cywgZG9zZV92YWx1ZSl9KVxuICAgICAgICAgIC5hdHRyKFwidHJhbnNmb3JtXCIsIGQgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIFwidHJhbnNsYXRlKFwiICsgW2QueCwgZC55XSArIFwiKVwiO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ2lkJywgKGQpID0+IGQubG9jYXRpb24pXG4gICAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnZ3JlZW4nKTtcbiAgICAgIFxuICAgICAgZy5vbignbW91c2VvdmVyJywgbWFwX21vdXNlX29uKTtcbiAgICAgIGcub24oJ21vdXNlbW92ZScsIG1hcF9tb3VzZV9tb3ZlKTtcbiAgICAgIGcub24oJ21vdXNlb3V0JywgbWFwX21vdXNlX291dCk7XG4gICAgICBnLm9uKCdtb3VzZWRvd24nLCBtYXBfbW91c2VfY2xpY2spO1xuICAgICAgXG4gICAgICByZXR1cm4gZztcbiAgICB9XG4gICAgXG4gICAgZnVuY3Rpb24gdXBkYXRlbWFyayh1cGRhdGUpe1xuICAgICAgc2VsZWN0aW9uLnNlbGVjdEFsbCgnLnZhY2MtdGV4dCcpLmRhdGEobWFya3MpXG4gICAgICAgIC50ZXh0KChkKSA9PiBcIlwiICsgcGFyc2VJbnQoZC5mdWxsKSk7XG4gICAgICBcbiAgICAgIHNlbGVjdGlvbi5zZWxlY3RBbGwoJy5tYXJrcycpLmRhdGEobWFya3MpXG4gICAgICAgIC5hcHBlbmQoXCJwYXRoXCIpXG4gICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ3ZhY2MtcmluZ3MnKVxuICAgICAgICAgIC5hdHRyKFwiZFwiLCBkID0+IHtyZXR1cm4gZ2VuZXJhdGVBcmMoZCwgcmluZ19yYWRpdXMsIHZhY2NfdmFsdWUpfSlcbiAgICAgICAgICAuYXR0cihcInRyYW5zZm9ybVwiLCBkID0+IHtcbiAgICAgICAgICAgIHJldHVybiBcInRyYW5zbGF0ZShcIiArIFtkLngsIGQueV0gKyBcIilcIjtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5hdHRyKCdpZCcsIChkKSA9PiBkLmxvY2F0aW9uKVxuICAgICAgICAgIC5hdHRyKCdmaWxsJywgJ2JsdWUnKTtcbiAgICAgIFxuICAgICAgc2VsZWN0aW9uLnNlbGVjdEFsbCgnLm1hcmtzJykuYXBwZW5kKFwicGF0aFwiKVxuICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdkb3NlLXJpbmdzJylcbiAgICAgICAgICAuYXR0cihcImRcIiwgZCA9PiB7cmV0dXJuIGdlbmVyYXRlQXJjKGQsIHJpbmdfd2lkdGggKyByaW5nX3JhZGl1cywgZG9zZV92YWx1ZSl9KVxuICAgICAgICAgIC5hdHRyKFwidHJhbnNmb3JtXCIsIGQgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIFwidHJhbnNsYXRlKFwiICsgW2QueCwgZC55XSArIFwiKVwiO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ2lkJywgKGQpID0+IGQubG9jYXRpb24pXG4gICAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnZ3JlZW4nKTtcbiAgICB9XG4gICAgXG4gICAgY29uc3QgZ3JvdXBzICA9IHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgnLm1hcmtzJylcbiAgICAgIC5kYXRhKG1hcmtzKVxuICAgIFx0LmpvaW4oXG4gICAgICAgIChlbnRlcikgPT4gZHJhd21hcmsoZW50ZXIpLFxuICAgICAgICAodXBkYXRlKSA9PiB1cGRhdGVtYXJrKHVwZGF0ZSksXG4gICAgICAgIChleGl0KSA9PiBleGl0LnJlbW92ZSgpXG4gICAgICApO1xuICB9O1xuICBcbiAgbXkuZGF0YSA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKGRhdGEgPSBfKSwgbXkpIDogZGF0YTtcbiAgfTtcbiAgXG4gIG15Lm1hcF9kYXRhID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgobWFwX2RhdGEgPSBfKSwgbXkpIDogbWFwX2RhdGE7XG4gIH07XG4gIFxuICBteS5zdGF0ZV9jZW50cm9pZHMgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChzdGF0ZV9jZW50cm9pZHMgPSBfKSwgbXkpIDogc3RhdGVfY2VudHJvaWRzO1xuICB9O1xuICBcbiAgbXkuc2VsZWN0ZWRfZGF0ZSA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKHNlbGVjdGVkX2RhdGUgPSBfKSwgbXkpIDogc2VsZWN0ZWRfZGF0ZTtcbiAgfTtcbiAgXG4gIG15LnBsb3QgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChwbG90ID0gXyksIG15KSA6IHBsb3Q7XG4gIH07XG4gIFxuICBteS5wbG90X2dyb3VwID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgocGxvdF9ncm91cCA9IF8pLCBteSkgOiBwbG90X2dyb3VwO1xuICB9O1xuICBcbiAgbXkudG9vbHRpcCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKHRvb2x0aXAgPSBfKSwgbXkpIDogdG9vbHRpcDtcbiAgfTtcbiAgXG4gIG15LnN0YXRlc19saXN0ID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgoc3RhdGVzX2xpc3QgPSBfKSwgbXkpIDogc3RhdGVzX2xpc3Q7XG4gIH07XG4gIFxuICByZXR1cm4gbXk7XG59O1xuIiwiaW1wb3J0IHtcbiAgc2NhbGVMaW5lYXIsXG4gIGV4dGVudCxcbiAgYXhpc0xlZnQsXG4gIGF4aXNCb3R0b20sXG4gIHRyYW5zaXRpb24sXG4gIHNlbGVjdCxcbiAgc2NhbGVUaW1lLFxuICBicnVzaFhcbn0gZnJvbSAnZDMnO1xuXG5cbmV4cG9ydCBjb25zdCBsaW5lUGxvdCA9ICgpID0+IHtcbiAgbGV0IHdpZHRoO1xuICBsZXQgaGVpZ2h0O1xuICBsZXQgc3RhdGVfZGF0YTtcbiAgbGV0IGRhdGE7XG4gIGxldCB4VmFsdWU7XG4gIGxldCB5VmFsdWU7XG4gIGxldCBtYXJnaW47XG4gIGxldCBsaW5lX2NvbG9yO1xuICBsZXQgc2VsZWN0ZWRfc3RhdGU7XG4gIGxldCBsYWJlbF9zaXplO1xuXHRsZXQgbWFwX2dyb3VwO1xuICBsZXQgbWFwO1xuICBcbiAgY29uc3QgbXkgPSAoc2VsZWN0aW9uKSA9PiB7XG4gICAgZnVuY3Rpb24gZmlsdGVyX3N0YXRlKGxpc3QpIHtcbiAgICAgIHJldHVybiBsaXN0LmxvY2F0aW9uID09IHNlbGVjdGVkX3N0YXRlO1xuICAgIH1cbiAgICBcbiAgICAvLyBDcmVhdGUgYSB0aW1lIHNjYWxlIGZvciB0aGUgeC1heGlzXG4gICAgY29uc3QgbWluZGF0ZSA9IG5ldyBEYXRlKCcyMDIxLTA0LTAxJyk7XG4gICAgY29uc3QgbWF4ZGF0ZSA9IG5ldyBEYXRlKCcyMDIxLTA5LTA0Jyk7XG4gICAgXG4gICAgY29uc3QgeCA9IHNjYWxlVGltZSgpXG4gICAgICAuZG9tYWluKFttaW5kYXRlLCBtYXhkYXRlXSlcbiAgICAgIC5yYW5nZShbbWFyZ2luLmxlZnQsIHdpZHRoIC0gbWFyZ2luLnJpZ2h0XSk7XG5cbiAgICBzdGF0ZV9kYXRhID0gZGF0YS5maWx0ZXIoZmlsdGVyX3N0YXRlKTtcblxuICAgIGNvbnN0IHkgPSBzY2FsZUxpbmVhcigpXG4gICAgICAuZG9tYWluKFtcbiAgICAgICAgZXh0ZW50KHN0YXRlX2RhdGEsIHlWYWx1ZSlbMF0sXG4gICAgICAgIGV4dGVudChzdGF0ZV9kYXRhLCB5VmFsdWUpWzFdICogMS4xLFxuICAgICAgXSlcbiAgICAgIC5yYW5nZShbaGVpZ2h0IC0gbWFyZ2luLmJvdHRvbSwgbWFyZ2luLnRvcF0pO1xuXG4gICAgLy8gY3JlYXRlIGEgc2V0IG9mIG1hcmtzIHRvIHZpc3VhbGl6ZVxuICAgIGNvbnN0IGNvcnJlY3REYXRlID0gKGQpID0+IHtcbiAgICAgIGxldCBkYXRlID0gbmV3IERhdGUoZC52YWx1ZU9mKCkpO1xuICAgICAgZGF0ZS5zZXREYXRlKGRhdGUuZ2V0RGF0ZSgpICsgMzIpO1xuICAgICAgcmV0dXJuIGRhdGU7XG4gICAgfTtcbiAgICBcbiAgICAvLyBhbmltYXRpb24gZnVuY3Rpb25zXG4gICAgY29uc3QgdCA9IHRyYW5zaXRpb24oKS5kdXJhdGlvbig1MDApO1xuICAgIFxuICAgIGNvbnN0IGxpbmVHZW5lcmF0b3IgPSBkMy5saW5lKClcbiAgICAueChkID0+IHgoeFZhbHVlKGQpKSlcbiAgICAueShkID0+IHkoeVZhbHVlKGQpKSk7XG4gICAgXG4gICAgZnVuY3Rpb24gZmlsdGVyX3N0YXRlKGxpc3QpIHtcbiAgICAgIHJldHVybiBsaXN0LmxvY2F0aW9uID09IHNlbGVjdGVkX3N0YXRlO1xuICAgIH1cbiAgICBcbiAgICBzZWxlY3Rpb24uYXBwZW5kKFwicGF0aFwiKVxuICAgICAgLmF0dHIoXCJmaWxsXCIsIFwibm9uZVwiKVxuICAgICAgLmF0dHIoXCJzdHJva2VcIiwgXCJncmVlblwiKVxuICAgICAgLmF0dHIoXCJzdHJva2Utd2lkdGhcIiwgMS41KVxuICAgICAgLmF0dHIoXCJkXCIsIGxpbmVHZW5lcmF0b3Ioc3RhdGVfZGF0YSkpO1xuICAgIFxuICAgIC8vIHJlZHJhdyB5IGF4aXNcbiAgICBzZWxlY3Rpb25cbiAgICAgIC5zZWxlY3RBbGwoJy55LWF4aXMnKVxuICAgICAgLmRhdGEoW251bGxdKVxuICAgICAgLmpvaW4oJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgJ3ktYXhpcycpXG4gICAgICAuYXR0cigndHJhbnNmb3JtJywgYHRyYW5zbGF0ZSgke21hcmdpbi5sZWZ0fSwwKWApXG4gICAgICAudHJhbnNpdGlvbih0KVxuICAgICAgLmNhbGwoYXhpc0xlZnQoeSkpO1xuXG4gICAgLy8gcmVkcmF3IHggYXhpc1xuICAgIHNlbGVjdGlvblxuICAgICAgLnNlbGVjdEFsbCgnLngtYXhpcycpXG4gICAgICAuZGF0YShbbnVsbF0pXG4gICAgICAuam9pbignZycpXG4gICAgICAuYXR0cignY2xhc3MnLCAneC1heGlzJylcbiAgICAgIC5hdHRyKFxuICAgICAgICAndHJhbnNmb3JtJyxcbiAgICAgICAgYHRyYW5zbGF0ZSgwLCR7aGVpZ2h0IC0gbWFyZ2luLmJvdHRvbX0pYFxuICAgICAgKVxuICAgICAgLnRyYW5zaXRpb24odClcbiAgICAgIC5jYWxsKGF4aXNCb3R0b20oeCkpO1xuICB9O1xuXG4gIG15LndpZHRoID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgod2lkdGggPSArXyksIG15KSA6IHdpZHRoO1xuICB9O1xuXG4gIG15LmhlaWdodCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKGhlaWdodCA9ICtfKSwgbXkpIDogaGVpZ2h0O1xuICB9O1xuXG4gIG15LmRhdGEgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChkYXRhID0gXyksIG15KSA6IGRhdGE7XG4gIH07XG5cbiAgbXkueFZhbHVlID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA/ICgoeFZhbHVlID0gXyksIG15KSA6IHhWYWx1ZTtcbiAgfTtcblxuICBteS55VmFsdWUgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKCh5VmFsdWUgPSBfKSwgbXkpIDogeVZhbHVlO1xuICB9O1xuXG4gIG15Lm1hcmdpbiA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKG1hcmdpbiA9IF8pLCBteSkgOiBtYXJnaW47XG4gIH07XG5cbiAgbXkubGluZV9jb2xvciA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGhcbiAgICAgID8gKChsaW5lX2NvbG9yID0gXyksIG15KVxuICAgICAgOiBsaW5lX2NvbG9yO1xuICB9O1xuXG4gIG15LnNlbGVjdGVkX3N0YXRlID0gZnVuY3Rpb24gKF8pIHtcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aFxuICAgICAgPyAoKHNlbGVjdGVkX3N0YXRlID0gXyksIG15KVxuICAgICAgOiBzZWxlY3RlZF9zdGF0ZTtcbiAgfTtcbiAgXG4gIG15LmxhYmVsX3NpemUgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoXG4gICAgICA/ICgobGFiZWxfc2l6ZSA9IF8pLCBteSlcbiAgICAgIDogbGFiZWxfc2l6ZTtcbiAgfTtcbiAgXG4gIG15Lm1hcF9ncm91cCA9IGZ1bmN0aW9uIChfKSB7XG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPyAoKG1hcF9ncm91cCA9IF8pLCBteSkgOiBtYXBfZ3JvdXA7XG4gIH07XG4gIFxuICBteS5tYXAgPSBmdW5jdGlvbiAoXykge1xuICAgIHJldHVybiBhcmd1bWVudHMubGVuZ3RoID8gKChtYXAgPSBfKSwgbXkpIDogbWFwO1xuICB9O1xuXG4gIHJldHVybiBteTtcbn07XG4iLCJjb25zdCB7IFxuICBjc3YsXG4gIHNlbGVjdCxcbiAganNvbixcbiAgYnJ1c2hYXG59ID0gZDM7XG5pbXBvcnQgeyBpbnRlcmFjdGl2ZUJhciB9IGZyb20gJy4vaW50ZXJhY3RpdmVCYXInO1xuaW1wb3J0IHsgc3RhdGVNZW51IH0gZnJvbSAnLi9zdGF0ZU1lbnUnO1xuaW1wb3J0IHsgbWFwRWxlbWVudCB9IGZyb20gJy4vbWFwRWxlbWVudCc7XG5pbXBvcnQgeyBsaW5lUGxvdCB9IGZyb20gJy4vbGluZVBsb3QnO1xuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5cbi8vIGRhdGEgc291cmNlIHVybFxuY29uc3QgY3N2VXJsID0gW1xuICAnaHR0cHM6Ly9naXN0LmdpdGh1YnVzZXJjb250ZW50LmNvbS8nLFxuICAnUGV0ZXJWYW5Ob3N0cmFuZC8nLCAvLyBVc2VyXG4gICdkNDQ5YjBhM2U1OTE0Mjc4ZGZhNzliYTYwZTQ4ZGY1ZC8nLCAvLyBJZCBvZiB0aGUgR2lzdFxuICAncmF3LycsIC8vIGNvbW1pdFxuICAndmFjY2luZV9kYXRhLmNzdicsIC8vIEZpbGUgbmFtZVxuXS5qb2luKCcnKTtcblxuY29uc3QganNvblVSTCA9IFtcblx0J2h0dHBzOi8vZ2lzdC5naXRodWJ1c2VyY29udGVudC5jb20vJyxcbiAgJ1BldGVyVmFuTm9zdHJhbmQvJyxcbiAgJ2Q0NDliMGEzZTU5MTQyNzhkZmE3OWJhNjBlNDhkZjVkLycsXG4gICdyYXcvJyxcbiAgJ3N0YXRlX2NlbnRyb2lkcy5qc29uJ1xuXS5qb2luKCcnKVxuXG5jb25zdCBtYXBVUkwgPSAnaHR0cHM6Ly91bnBrZy5jb20vdXMtYXRsYXNAMy4wLjAvc3RhdGVzLTEwbS5qc29uJ1xuXG4vLyBwYXJzaW5nIHRoZSBkYXRhc2V0XG5jb25zdCBwYXJzZVJvdyA9IChkKSA9PiB7XG4gIGQuZGF0ZSA9IG5ldyBEYXRlKGQuZGF0ZSk7XG4gIGQudG90YWxfdmFjY2luYXRpb25zID0gK2QudG90YWxfdmFjY2luYXRpb25zO1xuICBkLnRvdGFsX2Rpc3RyaWJ1dGVkID0gK2QudG90YWxfZGlzdHJpYnV0ZWQ7XG4gIGQucGVvcGxlX3ZhY2NpbmF0ZWQgPSArZC5wZW9wbGVfdmFjY2luYXRlZDtcbiAgZC5wZW9wbGVfZnVsbHlfdmFjY2luYXRlZF9wZXJfaHVuZHJlZCA9ICtkLnBlb3BsZV9mdWxseV92YWNjaW5hdGVkX3Blcl9odW5kcmVkO1xuICBkLnRvdGFsX3ZhY2NpbmF0aW9uc19wZXJfaHVuZHJlZCA9ICtkLnRvdGFsX3ZhY2NpbmF0aW9uc19wZXJfaHVuZHJlZDtcbiAgZC5wZW9wbGVfZnVsbHlfdmFjY2luYXRlZCA9ICtkLnBlb3BsZV9mdWxseV92YWNjaW5hdGVkO1xuICBkLnBlb3BsZV92YWNjaW5hdGVkX3Blcl9odW5kcmVkID0gK2QucGVvcGxlX3ZhY2NpbmF0ZWRfcGVyX2h1bmRyZWQ7XG4gIGQuZGlzdHJpYnV0ZWRfcGVyX2h1bmRyZWQgPSArZC5kaXN0cmlidXRlZF9wZXJfaHVuZHJlZDtcbiAgZC5kYWlseV92YWNjaW5hdGlvbnNfcmF3ID0gK2QuZGFpbHlfdmFjY2luYXRpb25zX3JhdztcbiAgZC5kYWlseV92YWNjaW5hdGlvbnMgPSArZC5kYWlseV92YWNjaW5hdGlvbnM7XG4gIGQuZGFpbHlfdmFjY2luYXRpb25zX3Blcl9taWxsaW9uID0gK2QuZGFpbHlfdmFjY2luYXRpb25zX3Blcl9taWxsaW9uO1xuICBkLnNoYXJlX2Rvc2VzX3VzZWQgPSArZC5zaGFyZV9kb3Nlc191c2VkO1xuICByZXR1cm4gZDtcbn07XG5cbi8vIFNlbGVjdCB0aGUgU1ZHIGVsZW1lbnRcbmNvbnN0IHdpZHRoID0gd2luZG93LmlubmVyV2lkdGg7XG5jb25zdCBoZWlnaHQgPSB3aW5kb3cuaW5uZXJIZWlnaHQ7XG5cbmNvbnN0IHN2ZyA9IHNlbGVjdCgnYm9keScpXG4gIC5hcHBlbmQoJ3N2ZycpXG4gIC5hdHRyKCd3aWR0aCcsIHdpZHRoIC0gMzAwKVxuICAuYXR0cignaGVpZ2h0JywgaGVpZ2h0IC0gMjAwKVxuXHQuYXR0cignY2xhc3MnLCAnbWFwX3N2ZycpO1xuXG5jb25zdCBzdmczID0gc2VsZWN0KCdib2R5JylcbiAgLmFwcGVuZCgnc3ZnJylcbiAgLmF0dHIoJ3dpZHRoJywgMjY4KVxuICAuYXR0cignaGVpZ2h0JywgaGVpZ2h0IC0gMjAwKVxuXHQuYXR0cignY2xhc3MnLCAnbWFwX3N2ZycpXG5cdC5hdHRyKCdzdHlsZScsICdtYXJnaW4tbGVmdDogNXB4Jyk7XG5cbmNvbnN0IHN2ZzIgPSBzZWxlY3QoJ2JvZHknKVxuICAuYXBwZW5kKCdzdmcnKVxuICAuYXR0cignd2lkdGgnLCB3aWR0aCAtIDIwKVxuICAuYXR0cignaGVpZ2h0JywgMTgwKVxuXHQuYXR0cignY2xhc3MnLCAnYmFyX3N2ZycpO1xuXG52YXIgdG9vbHRpcCA9IHNlbGVjdCgnYm9keScpXG4gIC5hcHBlbmQoJ2RpdicpXG5cdC5hcHBlbmQoJ2RpdicpXG4gICAgLmF0dHIoJ2lkJywgJ3Rvb2x0aXAnKVxuXHRcdC5hdHRyKCdjbGFzcycsICd0b29sdGlwLWNvbnRhaW5lcicpXG4gICAgLnN0eWxlKCdwb3NpdGlvbicsJ2Fic29sdXRlJylcbiAgICAuc3R5bGUoJ3Zpc2liaWxpdHknLCAnaGlkZGVuJyk7XG5cbmNvbnN0IG1hcF90b29sdGlwID0gc2VsZWN0KCdib2R5JylcbiAgLmFwcGVuZCgnZGl2JylcbiAgLmF0dHIoJ2NsYXNzJywgJ2QzLXRvb2x0aXAnKVxuICAuc3R5bGUoJ3Bvc2l0aW9uJywgJ2Fic29sdXRlJylcbiAgLnN0eWxlKCd6LWluZGV4JywgJzEwJylcbiAgLnN0eWxlKCd2aXNpYmlsaXR5JywgJ2hpZGRlbicpXG4gIC5zdHlsZSgncGFkZGluZycsICcxMHB4JylcbiAgLnN0eWxlKCdiYWNrZ3JvdW5kJywgJ3JnYmEoMCwwLDAsMC42KScpXG4gIC5zdHlsZSgnYm9yZGVyLXJhZGl1cycsICc1cHgnKVxuICAuc3R5bGUoJ2NvbG9yJywgJ3doaXRlJyk7XG5cbmNvbnN0IG1hcF9ncm91cCA9IHN2Zy5hcHBlbmQoJ2cnKVxuY29uc3QgbWFwX3NjYWxlID0gMC42XG5tYXBfZ3JvdXAuYXR0cignaWQnLCAnbWFwX2dyb3VwJyk7XG5tYXBfZ3JvdXAuYXR0cigndHJhbnNmb3JtJywgJ3NjYWxlKDAuNiknKTtcblxuY29uc3QgYmFyX2dyb3VwID0gc3ZnMi5hcHBlbmQoJ2cnKTtcbmNvbnN0IGJhcl9wbG90X2hlaWdodCA9IDE4MDtcblxuY29uc3QgbGluZV9ncm91cCA9IHN2ZzMuYXBwZW5kKCdnJyk7XG5cbmxldCB6b29tID0gZDMuem9vbSgpXG4gLm9uKCd6b29tJywgKGUsIGQpID0+IHtcbiAgIGNvbnN0IHRyYW5zX3ggPSBlLnRyYW5zZm9ybS54XG4gICBjb25zdCB0cmFuc195ID0gZS50cmFuc2Zvcm0ueVxuICAgY29uc3QgdHJhbnNfc2NhbGUgPSBlLnRyYW5zZm9ybS5rXG4gICBtYXBfZ3JvdXAuYXR0cigndHJhbnNmb3JtJyxgdHJhbnNsYXRlKCR7dHJhbnNfeH0sJHt0cmFuc195fSkgc2NhbGUoJHt0cmFuc19zY2FsZSAqIG1hcF9zY2FsZX0pYClcbn0pO1xuXG5cblxuY29uc3QgbWFpbiA9IGFzeW5jICgpID0+IHtcbiAgLy8gbG9hZCBkYXRhXG4gIGNvbnN0IGRhdGEgPSBhd2FpdCBjc3YoY3N2VXJsLCBwYXJzZVJvdyk7XG4gIGNvbnN0IHVzX3N0YXRlcyA9IGF3YWl0IGpzb24obWFwVVJMKTtcbiAgbGV0IHN0YXRlQ2VudHJvaWRzID0gYXdhaXQganNvbihqc29uVVJMKTtcbiAgXG4gIGZ1bmN0aW9uIG9ubHlVbmlxdWUodmFsdWUsIGluZGV4LCBzZWxmKSB7XG4gIFx0cmV0dXJuIHNlbGYuaW5kZXhPZih2YWx1ZSkgPT09IGluZGV4O1xuXHR9XHRcblx0Y29uc3Qgc3RhdGVzX2xpc3QgPSBkYXRhXG4gIFx0Lm1hcCgoZCkgPT4gZC5sb2NhdGlvbilcbiAgXHQuZmlsdGVyKG9ubHlVbmlxdWUpO1xuICBcbiAgLy8gY3JlYXRlIG1hcCAgXG4gIGNvbnN0IG1hcF9oZWlnaHQgPSBoZWlnaHQgLSBiYXJfcGxvdF9oZWlnaHQ7XG4gICBjb25zdCBtYXBfcGxvdCA9IG1hcEVsZW1lbnQoKVxuICBcdC5kYXRhKGRhdGEpXG4gIFx0Lm1hcF9kYXRhKHVzX3N0YXRlcylcbiAgXHQuc3RhdGVfY2VudHJvaWRzKHN0YXRlQ2VudHJvaWRzKVxuICAgXHQuc2VsZWN0ZWRfZGF0ZShuZXcgRGF0ZSgnMjAyMS0wOS0wNCcpKVxuICAgIC5zdGF0ZXNfbGlzdChzdGF0ZXNfbGlzdClcbiAgIFx0LnBsb3RfZ3JvdXAoYmFyX2dyb3VwKVxuICAgXHQudG9vbHRpcChtYXBfdG9vbHRpcCk7XG4gIG1hcF9ncm91cC5jYWxsKG1hcF9wbG90KTtcbiAgXG4gIC8vIGNyZWF0ZSBiYXIgcGxvdFxuICBjb25zdCBiYXJfcGxvdCA9IGludGVyYWN0aXZlQmFyKClcbiAgICAud2lkdGgod2lkdGggLSAyMClcbiAgICAuaGVpZ2h0KGJhcl9wbG90X2hlaWdodClcbiAgICAuZGF0YShkYXRhKVxuICAgIC54VmFsdWUoKGQpID0+IGQuZGF0ZSlcbiAgICAueVZhbHVlKChkKSA9PiBkLmRhaWx5X3ZhY2NpbmF0aW9ucylcbiAgICAubWFyZ2luKHtcbiAgICAgIHRvcDogMjAsXG4gICAgICByaWdodDogMjAsXG4gICAgICBib3R0b206IDQwLFxuICAgICAgbGVmdDogMTAwLFxuICAgIH0pXG4gICAgLmJhcl93aWR0aCgzKVxuICAgIC5iYXJfY29sb3IoJyM1REFCRjQnKVxuICBcdC5iYXJfb3BhY2l0eSgxLjApXG4gICAgLnNlbGVjdGVkX3N0YXRlKFwiQWxhYmFtYVwiKVxuICBcdC5sYWJlbF9zaXplKCcxZW0nKVxuICBcdC5tYXBfZ3JvdXAobWFwX2dyb3VwKVxuICBcdC5tYXAobWFwX3Bsb3QpO1xuICBcbiAgYmFyX2dyb3VwLmNhbGwoYmFyX3Bsb3QpO1xuICBcbiAgY29uc3QgbGluZV9wbG90ID0gbGluZVBsb3QoKVxuICBcdC53aWR0aCgyNzApXG4gICAgLmhlaWdodCgyMDApXG4gICAgLmRhdGEoZGF0YSlcbiAgICAueFZhbHVlKChkKSA9PiBkLmRhdGUpXG4gICAgLnlWYWx1ZSgoZCkgPT4gZC5zaGFyZV9kb3Nlc191c2VkKVxuICAgIC5tYXJnaW4oe1xuICAgICAgdG9wOiAxMCxcbiAgICAgIHJpZ2h0OiAxMCxcbiAgICAgIGJvdHRvbTogMTAsXG4gICAgICBsZWZ0OiA0MCxcbiAgICB9KVxuICAgIC5saW5lX2NvbG9yKCcjNURBQkY0JylcbiAgICAuc2VsZWN0ZWRfc3RhdGUoXCJBbGFiYW1hXCIpXG4gIFx0LmxhYmVsX3NpemUoJzFlbScpXG4gIFx0Lm1hcF9ncm91cChtYXBfZ3JvdXApXG4gIFx0Lm1hcChtYXBfcGxvdCk7XG4gIGxpbmVfZ3JvdXAuY2FsbChsaW5lX3Bsb3QpO1xuICBcbiAgbWFwX3Bsb3QucGxvdChiYXJfcGxvdCk7XG4gIFxuICAvLyBjcmVhdGUgbWVudVxuICBjb25zdCBteV9tZW51ID0gc3RhdGVNZW51KClcbiAgXHQuZGF0YShkYXRhKVxuICBcdC5wbG90KGJhcl9wbG90KTtcblx0YmFyX2dyb3VwLmNhbGwobXlfbWVudSk7XG4gIHN2Zy5jYWxsKHpvb20pO1xuXG59O1xuXG5jb25zdCBtYXBfbGVnZW5kID0gc3ZnLmFwcGVuZCgnZycpO1xuXG5sZXQgbGVnZW5kX3ggPSA1NTA7XG5sZXQgbGVnZW5kX3kgPSAxNTtcbmxldCBpdGVtX21hcmdpbiA9IDEwO1xubGV0IGl0ZW1fc2l6ZSA9IDEwO1xuXG5tYXBfbGVnZW5kLmFwcGVuZCgncmVjdCcpXG4gIC5hdHRyKCd3aWR0aCcsIDEwMClcbiAgLmF0dHIoJ2hlaWdodCcsIDgwKVxuXHQuYXR0cigneCcsIGxlZ2VuZF94KVxuXHQuYXR0cigneScsIGxlZ2VuZF95KVxuXHQuYXR0cignZmlsbCcsICd3aGl0ZScpXG5cdC5hdHRyKCdzdHJva2UnLCAnYmxhY2snKTtcblxubWFwX2xlZ2VuZC5hcHBlbmQoJ3JlY3QnKVxuXHQuYXR0cignd2lkdGgnLCBpdGVtX3NpemUpXG4gIC5hdHRyKCdoZWlnaHQnLCBpdGVtX3NpemUpXG5cdC5hdHRyKCd4JywgbGVnZW5kX3ggKyBpdGVtX21hcmdpbilcblx0LmF0dHIoJ3knLCBsZWdlbmRfeSArIGl0ZW1fbWFyZ2luKVxuXHQuYXR0cignZmlsbCcsICdncmVlbicpO1xuXG5tYXBfbGVnZW5kLmFwcGVuZCgndGV4dCcpXG5cdC5hdHRyKCdmb250LXNpemUnLCAnMC45ZW0nKVxuXHQuYXBwZW5kKCd0c3BhbicpXG4gIFx0LmF0dHIoJ3gnLCBsZWdlbmRfeCArIGl0ZW1fbWFyZ2luICogMS41ICsgaXRlbV9zaXplKVxuXHRcdC5hdHRyKCd5JywgbGVnZW5kX3kgKyBpdGVtX21hcmdpbiAqIDEuOSlcblx0XHQudGV4dCgnJSBBdmFpbGlibGUnKVxuXHQuYXBwZW5kKCd0c3BhbicpXG5cdFx0LmF0dHIoJ3gnLCBsZWdlbmRfeCArIGl0ZW1fbWFyZ2luICogMS41ICsgaXRlbV9zaXplKVxuXHRcdC5hdHRyKCd5JywgbGVnZW5kX3kgKyBpdGVtX21hcmdpbiAqIDMuMSlcblx0XHQudGV4dCgnRG9zZXMgVXNlZCcpO1xuXG5tYXBfbGVnZW5kLmFwcGVuZCgncmVjdCcpXG5cdC5hdHRyKCd3aWR0aCcsIGl0ZW1fc2l6ZSlcbiAgLmF0dHIoJ2hlaWdodCcsIGl0ZW1fc2l6ZSlcblx0LmF0dHIoJ3gnLCBsZWdlbmRfeCArIGl0ZW1fbWFyZ2luKVxuXHQuYXR0cigneScsIGxlZ2VuZF95ICsgaXRlbV9tYXJnaW4gKiA0LjUpXG5cdC5hdHRyKCdmaWxsJywgJ2JsdWUnKTtcblxubWFwX2xlZ2VuZC5hcHBlbmQoJ3RleHQnKVxuXHQuYXR0cignZm9udC1zaXplJywgJzAuOWVtJylcblx0LmFwcGVuZCgndHNwYW4nKVxuICBcdC5hdHRyKCd4JywgbGVnZW5kX3ggKyBpdGVtX21hcmdpbiAqIDEuNSArIGl0ZW1fc2l6ZSlcblx0XHQuYXR0cigneScsIGxlZ2VuZF95ICsgaXRlbV9tYXJnaW4gKiA1LjQpXG5cdFx0LnRleHQoJyUgUG9wdWxhY2UnKVxuXHQuYXBwZW5kKCd0c3BhbicpXG5cdFx0LmF0dHIoJ3gnLCBsZWdlbmRfeCArIGl0ZW1fbWFyZ2luICogMS41ICsgaXRlbV9zaXplKVxuXHRcdC5hdHRyKCd5JywgbGVnZW5kX3kgKyBpdGVtX21hcmdpbiAqIDYuOSlcblx0XHQudGV4dCgnVmFjY2luYXRlZCcpO1xuXG5zdmcyLmFwcGVuZCgndGV4dCcpXG5cdC50ZXh0KCdEYWlseSBEb3NlcyBEaXN0cmlidXRlZCcpXG4gIC5hdHRyKCd4JywgMzApXG4gIC5hdHRyKCd5JywgMTYwKVxuICAuYXR0cignZm9udC1zaXplJywgJzAuOWVtJylcbiAgLmF0dHIoJ3RyYW5zZm9ybScsICdyb3RhdGUoLTkwLCAzMCwgMTYwKScpO1xuXG5zdmcyLmFwcGVuZCgndGV4dCcpXG5cdC50ZXh0KCdEYXRlIC0gMjAyMScpXG4gIC5hdHRyKCd4Jywgd2lkdGggLyAyIC0gMjApXG4gIC5hdHRyKCd5JywgMTc1KVxuICAuYXR0cignZm9udC1zaXplJywgJzAuOWVtJyk7XG5cbm1haW4oKTtcbiJdLCJuYW1lcyI6WyJzY2FsZVRpbWUiLCJzY2FsZUxpbmVhciIsImV4dGVudCIsInNlbGVjdCIsInRyYW5zaXRpb24iLCJheGlzTGVmdCIsImF4aXNCb3R0b20iLCJicnVzaFgiLCJkaXNwYXRjaCIsImdlb0FsYmVyc1VzYSIsImdlb1BhdGgiLCJtYXgiLCJhcmMiLCJmb3JjZVNpbXVsYXRpb24iLCJmb3JjZVgiLCJmb3JjZVkiLCJmb3JjZUNvbGxpZGUiXSwibWFwcGluZ3MiOiI7Ozs7O0VBWU8sTUFBTSxjQUFjLEdBQUcsTUFBTTtFQUNwQyxFQUFFLElBQUksS0FBSyxDQUFDO0VBQ1osRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUNiLEVBQUUsSUFBSSxVQUFVLENBQUM7RUFDakIsRUFBRSxJQUFJLElBQUksQ0FBQztFQUNYLEVBQUUsSUFBSSxNQUFNLENBQUM7RUFDYixFQUFFLElBQUksTUFBTSxDQUFDO0VBQ2IsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUNiLEVBQUUsSUFBSSxTQUFTLENBQUM7RUFDaEIsRUFBRSxJQUFJLFNBQVMsQ0FBQztFQUNoQixFQUFFLElBQUksV0FBVyxDQUFDO0VBQ2xCLEVBQUUsSUFBSSxjQUFjLENBQUM7RUFDckIsRUFBRSxJQUFJLFVBQVUsQ0FBQztFQUNqQixDQUFDLElBQUksU0FBUyxDQUFDO0VBQ2YsRUFBRSxJQUFJLEdBQUcsQ0FBQztFQUNWO0VBQ0EsRUFBRSxNQUFNLEVBQUUsR0FBRyxDQUFDLFNBQVMsS0FBSztFQUM1QixJQUFJLFNBQVMsWUFBWSxDQUFDLElBQUksRUFBRTtFQUNoQyxNQUFNLE9BQU8sSUFBSSxDQUFDLFFBQVEsSUFBSSxjQUFjLENBQUM7RUFDN0MsS0FBSztBQUNMO0VBQ0E7RUFDQSxJQUFJLE1BQU0sT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQzNDLElBQUksTUFBTSxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7RUFDM0MsSUFBSSxNQUFNLENBQUMsR0FBR0EsY0FBUyxFQUFFO0VBQ3pCLE9BQU8sTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0VBQ2pDLE9BQU8sS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDbEQ7RUFDQSxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQzNDO0VBQ0E7RUFDQTtFQUNBLElBQUksTUFBTSxDQUFDLEdBQUdDLGdCQUFXLEVBQUU7RUFDM0IsT0FBTyxNQUFNLENBQUM7RUFDZCxRQUFRQyxXQUFNLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUc7RUFDM0MsUUFBUUEsV0FBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDckMsT0FBTyxDQUFDO0VBQ1IsT0FBTyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUNuRCxJQUFJLE1BQU0sRUFBRSxHQUFHRCxnQkFBVyxFQUFFO0VBQzVCLE9BQU8sTUFBTSxDQUFDO0VBQ2QsUUFBUUMsV0FBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDckMsUUFBUUEsV0FBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHO0VBQzNDLE9BQU8sQ0FBQztFQUNSLE9BQU8sS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDbkQ7RUFDQTtFQUNBLElBQUksTUFBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUs7RUFDL0IsTUFBTSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztFQUN2QyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0VBQ3hDLE1BQU0sT0FBTyxJQUFJLENBQUM7RUFDbEIsS0FBSyxDQUFDO0VBQ04sSUFBSSxNQUFNLEtBQUssR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLO0VBQ3hDLE1BQU0sT0FBTztFQUNiLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDdkIsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN2QixRQUFRLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztFQUNqQyxRQUFRLEtBQUssRUFBRSxDQUFDLENBQUMsa0JBQWtCO0VBQ25DLE9BQU8sQ0FBQztFQUNSLEtBQUssQ0FBQyxDQUFDO0FBQ1A7RUFDQTtFQUNBLElBQUksU0FBUyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFO0VBQ3JDO0VBQ0EsTUFBTSxTQUFTO0VBQ2YsU0FBUyxTQUFTLENBQUMsTUFBTSxDQUFDO0VBQzFCLFNBQVMsVUFBVSxFQUFFO0VBQ3JCLFNBQVMsUUFBUSxDQUFDLEtBQUssQ0FBQztFQUN4QixTQUFTLElBQUksQ0FBQyxTQUFTLEVBQUUsV0FBVyxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQzFDLE1BQU1DLFdBQU0sQ0FBQyxJQUFJLENBQUM7RUFDbEIsU0FBUyxVQUFVLEVBQUU7RUFDckIsU0FBUyxRQUFRLENBQUMsS0FBSyxDQUFDO0VBQ3hCLFNBQVMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQztFQUN0QyxNQUFNQSxXQUFNLENBQUMsVUFBVSxDQUFDO0VBQ3hCLFNBQVMsS0FBSyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUM7RUFDdkMsU0FBUyxJQUFJO0VBQ2IsVUFBVSxRQUFRO0VBQ2xCLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUU7RUFDN0IsWUFBWSxHQUFHO0VBQ2YsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRTtFQUM1QixZQUFZLFdBQVc7RUFDdkIsWUFBWSxDQUFDLENBQUMsS0FBSztFQUNuQixTQUFTLENBQUM7RUFDVixLQUFLO0FBQ0w7RUFDQSxJQUFJLFNBQVMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRTtFQUNyQztFQUNBLE1BQU1BLFdBQU0sQ0FBQyxVQUFVLENBQUM7RUFDeEIsU0FBUyxLQUFLLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQztFQUM5QyxTQUFTLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQztFQUMzQyxLQUFLO0FBQ0w7RUFDQSxJQUFJLFNBQVMsZ0JBQWdCLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRTtFQUNwQyxNQUFNLFNBQVM7RUFDZixTQUFTLFNBQVMsQ0FBQyxNQUFNLENBQUM7RUFDMUIsU0FBUyxVQUFVLEVBQUU7RUFDckIsU0FBUyxRQUFRLENBQUMsS0FBSyxDQUFDO0VBQ3hCLFNBQVMsSUFBSSxDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQztFQUN0QyxNQUFNQSxXQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUMsQ0FBQztFQUN2RCxLQUFLO0VBQ0w7RUFDQTtFQUNBLElBQUksTUFBTSxDQUFDLEdBQUdDLGVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUN6QyxJQUFJLE1BQU0sWUFBWSxHQUFHLENBQUMsSUFBSSxLQUFLO0VBQ25DLE1BQU0sSUFBSTtFQUNWLFNBQVMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSztFQUMxQixVQUFVLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLEdBQUcsQ0FBQyxDQUFDO0VBQ3JDLFNBQVMsQ0FBQztFQUNWLFNBQVMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSztFQUMxQjtFQUNBLFVBQVUsT0FBTyxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzlDLFNBQVMsQ0FBQztFQUNWLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7RUFDaEMsU0FBUyxJQUFJLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQztFQUNyQyxTQUFTLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3BDLEtBQUssQ0FBQztBQUNOO0VBQ0EsSUFBSSxNQUFNLFlBQVksR0FBRyxDQUFDLElBQUksS0FBSztFQUNuQyxNQUFNLElBQUksQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFLGlCQUFpQixDQUFDLENBQUM7RUFDOUMsTUFBTSxJQUFJLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO0VBQzlDLE1BQU0sSUFBSSxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztFQUM1QyxLQUFLLENBQUM7RUFDTjtFQUNBLElBQUksTUFBTSxlQUFlLEdBQUcsQ0FBQyxJQUFJLEtBQUs7RUFDdEMsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztFQUM1QixNQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQzdCLEtBQUssQ0FBQztFQUNOLElBQUksTUFBTSxTQUFTLEdBQUcsQ0FBQyxLQUFLLEtBQUs7RUFDakMsTUFBTSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7RUFDbkQsTUFBTSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3JELEtBQUssQ0FBQztBQUNOO0FBQ0E7RUFDQTtFQUNBLElBQUksTUFBTSxJQUFJLEdBQUcsU0FBUztFQUMxQixPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUM7RUFDeEIsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDO0VBQ2xCLE9BQU8sSUFBSTtFQUNYLFFBQVEsQ0FBQyxLQUFLO0VBQ2QsVUFBVSxLQUFLO0VBQ2YsYUFBYSxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQzNCLFdBQVcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQztFQUN4QyxhQUFhLElBQUksQ0FBQyxZQUFZLENBQUM7RUFDL0IsYUFBYSxJQUFJLENBQUMsZUFBZSxDQUFDO0VBQ2xDLGFBQWEsSUFBSSxDQUFDLFNBQVMsQ0FBQztFQUM1QixXQUFXLElBQUksQ0FBQyxZQUFZLENBQUM7RUFDN0IsUUFBUSxDQUFDLE1BQU07RUFDZixVQUFVLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNO0VBQzdCLFlBQVksTUFBTTtFQUNsQixlQUFlLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDNUIsZUFBZSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUM7RUFDdEMsZUFBZSxJQUFJLENBQUMsWUFBWSxDQUFDO0VBQ2pDLFdBQVc7RUFDWCxRQUFRLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUU7RUFDL0IsT0FBTyxDQUFDO0VBQ1I7RUFDQSxJQUFJLFNBQVM7RUFDYixPQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUM7RUFDM0IsT0FBTyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUNuQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUM7RUFDaEIsT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQztFQUM5QixPQUFPLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUN2RCxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDcEIsT0FBTyxJQUFJLENBQUNDLGFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQzFCO0VBQ0E7RUFDQSxJQUFJLFNBQVM7RUFDYixPQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUM7RUFDM0IsT0FBTyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUNuQixPQUFPLElBQUksQ0FBQyxHQUFHLENBQUM7RUFDaEIsT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQztFQUM5QixPQUFPLElBQUk7RUFDWCxRQUFRLFdBQVc7RUFDbkIsUUFBUSxDQUFDLFlBQVksRUFBRSxNQUFNLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDaEQsT0FBTztFQUNQLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQztFQUNwQixPQUFPLElBQUksQ0FBQ0MsZUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDM0I7RUFDQTtFQUNBLElBQUksU0FBUyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUMxQixNQUFNLE1BQU0sVUFBVSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUM7RUFDckM7RUFDQSxNQUFNLElBQUksUUFBUSxHQUFHLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQzVDLE1BQU0sR0FBRyxVQUFVLENBQUM7RUFDcEIsUUFBUSxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ25ELE9BQU8sUUFBUSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDMUMsT0FBTztFQUNQLE1BQU0sU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7RUFDbEQsS0FBSztFQUNMLElBQUksTUFBTSxLQUFLLEdBQUdDLFdBQU0sRUFBRTtFQUMxQixPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDdkMsT0FBTyxFQUFFLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0VBQ2hDLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztFQUMxQjtFQUNBO0VBQ0E7RUFDQSxJQUFJLFNBQVM7RUFDYixPQUFPLFNBQVMsQ0FBQyxlQUFlLENBQUM7RUFDakMsTUFBTSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUNsQixNQUFNLElBQUksQ0FBQyxNQUFNLENBQUM7RUFDbEIsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7RUFDN0IsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO0VBQ2hDLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztFQUN6QixPQUFPLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBVSxDQUFDO0VBQ3BDLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQztFQUNwQztFQUNBLElBQUksU0FBUztFQUNiLE9BQU8sU0FBUyxDQUFDLGVBQWUsQ0FBQztFQUNqQyxNQUFNLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0VBQ2xCLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQztFQUNsQixPQUFPLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0VBQ25CLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztFQUM3QixPQUFPLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztFQUN0QyxPQUFPLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3hELE9BQU8sSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUM7RUFDcEMsTUFBTSxJQUFJLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQyxDQUFDO0VBQ3BDLEdBQUcsQ0FBQztBQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQzFCLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxLQUFLLENBQUM7RUFDekQsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDM0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUMzRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsRUFBRTtFQUN6QixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLElBQUksQ0FBQztFQUN0RCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsRUFBRTtFQUMzQixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUMxRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsRUFBRTtFQUMzQixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUMxRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsRUFBRTtFQUMzQixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUMxRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsRUFBRTtFQUM5QixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU07RUFDM0IsU0FBUyxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFO0VBQzdCLFFBQVEsU0FBUyxDQUFDO0VBQ2xCLEdBQUcsQ0FBQztBQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQ2hDLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTTtFQUMzQixTQUFTLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUU7RUFDL0IsUUFBUSxXQUFXLENBQUM7RUFDcEIsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDOUIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNO0VBQzNCLFNBQVMsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxHQUFHLEVBQUU7RUFDNUIsUUFBUSxTQUFTLENBQUM7RUFDbEIsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxjQUFjLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDbkMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNO0VBQzNCLFNBQVMsQ0FBQyxjQUFjLEdBQUcsQ0FBQyxHQUFHLEVBQUU7RUFDakMsUUFBUSxjQUFjLENBQUM7RUFDdkIsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDL0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNO0VBQzNCLFNBQVMsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxHQUFHLEVBQUU7RUFDN0IsUUFBUSxVQUFVLENBQUM7RUFDbkIsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDOUIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxTQUFTLENBQUM7RUFDaEUsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDeEIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxHQUFHLENBQUM7RUFDcEQsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLE9BQU8sRUFBRSxDQUFDO0VBQ1osQ0FBQzs7RUNuU00sTUFBTSxJQUFJLEdBQUcsTUFBTTtFQUMxQixFQUFFLElBQUksRUFBRSxDQUFDO0VBQ1QsRUFBRSxJQUFJLFNBQVMsQ0FBQztFQUNoQixFQUFFLElBQUksT0FBTyxDQUFDO0VBQ2QsRUFBRSxNQUFNLFNBQVMsR0FBR0MsYUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0VBQ3ZDO0VBQ0EsRUFBRSxNQUFNLEVBQUUsR0FBRyxDQUFDLFNBQVMsS0FBSztFQUM1QixJQUFJLFNBQVM7RUFDYixPQUFPLFNBQVMsQ0FBQyxPQUFPLENBQUM7RUFDekIsT0FBTyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUNuQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7RUFDcEIsT0FBTyxJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQztFQUN0QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN2QjtFQUNBLElBQUksU0FBUztFQUNiLE9BQU8sU0FBUyxDQUFDLFFBQVEsQ0FBQztFQUMxQixPQUFPLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0VBQ25CLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQztFQUNyQixPQUFPLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO0VBQ3JCLE9BQU8sRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssS0FBSztFQUMvQixRQUFRLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0VBQzNELE9BQU8sQ0FBQztFQUNSLE9BQU8sU0FBUyxDQUFDLFFBQVEsQ0FBQztFQUMxQixPQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7RUFDcEIsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0VBQ3JCLE9BQU8sSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDO0VBQ3BDLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUMzQixHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLEVBQUUsR0FBRyxVQUFVLENBQUMsRUFBRTtFQUN2QixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQztFQUNsRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsRUFBRTtFQUM5QixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU07RUFDM0IsU0FBUyxDQUFDLFNBQVMsR0FBRyxDQUFDLEdBQUcsRUFBRTtFQUM1QixRQUFRLFNBQVMsQ0FBQztFQUNsQixHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLE9BQU8sR0FBRyxVQUFVLENBQUMsRUFBRTtFQUM1QixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLE9BQU8sQ0FBQztFQUM1RCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLEVBQUUsR0FBRyxZQUFZO0VBQ3RCLElBQUksSUFBSSxLQUFLLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0VBQ3pELElBQUksT0FBTyxLQUFLLEtBQUssU0FBUyxHQUFHLEVBQUUsR0FBRyxLQUFLLENBQUM7RUFDNUMsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLE9BQU8sRUFBRSxDQUFDO0VBQ1osQ0FBQzs7RUMxQ00sTUFBTSxTQUFTLEdBQUcsTUFBTTtFQUcvQixFQUFFLElBQUksSUFBSSxDQUFDO0VBQ1gsRUFBRSxJQUFJLElBQUksQ0FBQztFQUNYO0VBQ0EsRUFBRSxNQUFNLEVBQUUsR0FBRyxDQUFDLFNBQVMsS0FBSztFQUM1QixJQUFJLE1BQU0sYUFBYSxHQUFHTCxXQUFNLENBQUMsTUFBTSxDQUFDO0VBQ3hDLE1BQU0sTUFBTSxDQUFDLEtBQUssQ0FBQztFQUNuQixNQUFNLElBQUksQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztFQUN0QyxJQUFJLE1BQU0sVUFBVSxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDbkQsSUFBSSxNQUFNLEtBQUssR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0VBQzlDO0VBQ0EsSUFBSSxTQUFTLFVBQVUsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRTtFQUM1QyxNQUFNLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxLQUFLLENBQUM7RUFDM0MsS0FBSztFQUNMLElBQUksTUFBTSxNQUFNLEdBQUcsSUFBSTtFQUN2QixPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQzdCLE9BQU8sTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0VBQzFCLElBQUksTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSztFQUN0QyxNQUFNLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQztFQUNuQyxLQUFLLENBQUMsQ0FBQztFQUNQO0VBQ0EsSUFBSSxVQUFVLENBQUMsSUFBSTtFQUNuQixNQUFNLElBQUksRUFBRTtFQUNaLFNBQVMsRUFBRSxDQUFDLFlBQVksQ0FBQztFQUN6QixTQUFTLFNBQVMsQ0FBQyxRQUFRLENBQUM7RUFDNUIsU0FBUyxPQUFPLENBQUMsT0FBTyxDQUFDO0VBQ3pCLFNBQVMsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssS0FBSztFQUNqQyxVQUFVLFNBQVMsQ0FBQyxJQUFJO0VBQ3hCLFlBQVksSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7RUFDdEMsV0FBVyxDQUFDO0VBQ1osU0FBUyxDQUFDO0VBQ1YsS0FBSyxDQUFDO0VBQ04sR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDekIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDdEQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDekIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDdEQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLE9BQU8sRUFBRSxDQUFDO0VBQ1osQ0FBQzs7RUNsQ00sTUFBTSxVQUFVLEdBQUcsTUFBTTtFQUdoQyxFQUFFLElBQUksSUFBSSxDQUFDO0VBQ1gsRUFBRSxJQUFJLFFBQVEsQ0FBQztFQUNmLEVBQUUsSUFBSSxlQUFlLENBQUM7RUFDdEIsRUFBRSxJQUFJLGFBQWEsQ0FBQztFQUVwQixFQUFFLElBQUksT0FBTyxDQUFDO0VBQ2QsRUFBRSxJQUFJLElBQUksQ0FBQztFQUNYLEVBQUUsSUFBSSxVQUFVLENBQUM7RUFDakIsRUFBRSxJQUFJLFdBQVcsQ0FBQztFQUNsQjtFQUNBLEVBQUUsU0FBUyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtFQUMvQixJQUFJLE9BQU87RUFDWCxPQUFPLEtBQUssQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUssR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDO0VBQzVDLE9BQU8sS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsS0FBSyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQztFQUM5QyxHQUFHO0FBQ0g7RUFDQSxFQUFFLFNBQVMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDNUI7RUFDQSxJQUFJLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUNsQixNQUFNLE9BQU87RUFDYixPQUFPLElBQUk7RUFDWCxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUM5QixPQUFPO0VBQ1AsT0FBTyxLQUFLLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0VBQ3RDLEtBQUs7RUFDTDtFQUNBLElBQUksR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDO0VBQ3BCLE1BQU0sT0FBTztFQUNiLE9BQU8sSUFBSTtFQUNYLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUNyQyxPQUFPO0VBQ1AsT0FBTyxLQUFLLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0VBQ3RDLEtBQUs7RUFDTCxHQUFHO0FBQ0g7RUFDQSxFQUFFLFNBQVMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7RUFDOUIsTUFBTSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUMsQ0FBQztFQUNyRCxHQUFHO0FBQ0g7RUFDQSxFQUFFLFNBQVMsZUFBZSxDQUFDLGNBQWMsQ0FBQztFQUMxQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0VBQ1osS0FBSyxNQUFNLFdBQVcsR0FBRyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEdBQUcsY0FBYyxFQUFFLENBQUMsQ0FBQztFQUNyRixLQUFLLE1BQU0sUUFBUSxHQUFHQSxXQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7RUFDNUMsS0FBSyxRQUFRLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDdkQsS0FBSztFQUNMLEdBQUc7RUFDSDtFQUNBLEVBQUUsU0FBUyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtFQUNoQztFQUNBLElBQUksR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ2xCLE1BQU0sVUFBVSxDQUFDLElBQUk7RUFDckIsUUFBUSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7RUFDdkMsT0FBTyxDQUFDO0VBQ1IsTUFBTSxlQUFlLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBQztFQUNqQyxLQUFLO0VBQ0w7RUFDQSxJQUFJLEdBQUcsQ0FBQyxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztFQUN6QyxNQUFNLFVBQVUsQ0FBQyxJQUFJO0VBQ3JCLFFBQVEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztFQUM5QyxPQUFPLENBQUM7RUFDUixNQUFNLGVBQWUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksRUFBQztFQUN4QyxLQUFLO0VBQ0wsR0FBRztFQUNIO0VBQ0EsRUFBRSxNQUFNLEVBQUUsR0FBRyxDQUFDLFNBQVMsS0FBSztFQUM1QixHQUFHLE1BQU0sVUFBVSxHQUFHTSxpQkFBWSxFQUFFLENBQUM7RUFDckMsSUFBSSxNQUFNLElBQUksR0FBR0MsWUFBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0VBQ3JDO0VBQ0EsSUFBSSxNQUFNLE1BQU0sR0FBRyxTQUFTO0VBQzVCLE9BQU8sU0FBUyxDQUFDLE1BQU0sQ0FBQztFQUN4QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUN6RSxPQUFPLElBQUk7RUFDWCxRQUFRLENBQUMsS0FBSztFQUNkLFVBQVUsS0FBSztFQUNmLGFBQWEsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUMzQixhQUFhLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO0VBQzVCLGFBQWEsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztFQUNqRCxhQUFhLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUMxQyxhQUFhLElBQUksQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDO0VBQ3BDLGFBQWEsSUFBSSxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUM7RUFDdEMsV0FBVyxFQUFFLENBQUMsV0FBVyxFQUFFLFlBQVksQ0FBQztFQUN4QyxXQUFXLEVBQUUsQ0FBQyxXQUFXLEVBQUUsY0FBYyxDQUFDO0VBQzFDLFdBQVcsRUFBRSxDQUFDLFVBQVUsRUFBRSxhQUFhLENBQUM7RUFDeEMsV0FBVyxFQUFFLENBQUMsV0FBVyxFQUFFLGVBQWUsQ0FBQztFQUMzQyxRQUFRLENBQUMsTUFBTTtFQUNmLFVBQVUsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUM7RUFDeEMsUUFBUSxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFO0VBQy9CLE9BQU8sQ0FBQztFQUNSO0VBQ0E7RUFDQSxJQUFJLFNBQVMsV0FBVyxDQUFDLElBQUksRUFBRTtFQUMvQixNQUFNLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxhQUFhLENBQUMsT0FBTyxFQUFFO0VBQzNELFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxhQUFhLENBQUMsUUFBUSxFQUFFO0VBQ3hELFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsSUFBSSxhQUFhLENBQUMsV0FBVyxFQUFFLENBQUM7RUFDL0QsS0FBSztFQUNMLElBQUksTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztFQUMvQztFQUNBLElBQUksSUFBSSxRQUFRLEdBQUcsYUFBWTtFQUMvQixJQUFJLFNBQVMsa0JBQWtCLENBQUMsU0FBUyxFQUFFO0VBQzNDLE1BQU0sT0FBTyxTQUFTLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQztFQUN4QyxLQUFLO0FBQ0w7RUFDQSxJQUFJLElBQUksS0FBSyxHQUFHLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUs7RUFDckMsTUFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUM1QixNQUFNLE1BQU0sTUFBTSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNuRSxNQUFNLEdBQUcsTUFBTTtFQUNmLFFBQVEsT0FBTztFQUNmLFVBQVUsUUFBUSxHQUFHLENBQUMsQ0FBQyxRQUFRO0VBQy9CLFVBQVUsR0FBRyxHQUFHLE1BQU0sQ0FBQyxHQUFHO0VBQzFCLFVBQVUsR0FBRyxHQUFHLE1BQU0sQ0FBQyxHQUFHO0VBQzFCLFVBQVUsSUFBSSxHQUFHLENBQUMsQ0FBQyxtQ0FBbUM7RUFDdEQsVUFBVSxJQUFJLEdBQUcsQ0FBQyxDQUFDLDZCQUE2QjtFQUNoRCxVQUFVLEtBQUssR0FBRyxDQUFDLENBQUMsZ0JBQWdCO0VBQ3BDLFNBQVM7RUFDVCxLQUFLLENBQUMsQ0FBQztFQUNQO0VBQ0EsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxVQUFVLE9BQU8sR0FBRztFQUM3QyxLQUFLLE9BQU8sT0FBTyxLQUFLLFNBQVMsQ0FBQztFQUNsQyxLQUFLLENBQUMsQ0FBQztBQUNQO0VBQ0EsSUFBSSxNQUFNLFlBQVksR0FBR0MsUUFBRyxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsRUFBRTtFQUNqRCxRQUFRLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQztFQUN0QixLQUFLLENBQUMsQ0FBQztFQUNQO0VBQ0E7RUFDQSxJQUFJLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztFQUN2QixJQUFJLElBQUksV0FBVyxHQUFHLEVBQUUsQ0FBQztFQUN6QixJQUFJLFNBQVMsV0FBVyxDQUFDLENBQUMsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFO0VBQ2hELEtBQUssSUFBSSxLQUFLLEdBQUcsV0FBVyxDQUFDO0VBQzdCLE1BQU0sSUFBSSxLQUFLLEdBQUcsV0FBVyxHQUFHLFVBQVUsQ0FBQztFQUMzQyxNQUFNLElBQUksS0FBSyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztFQUMvQyxNQUFNLElBQUksTUFBTSxHQUFHQyxRQUFHLEVBQUU7RUFDeEIsU0FBUyxXQUFXLENBQUMsS0FBSyxDQUFDO0VBQzNCLFNBQVMsV0FBVyxDQUFDLEtBQUssQ0FBQztFQUMzQixTQUFTLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDdEIsU0FBUyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDekIsTUFBTSxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN2QixLQUFLO0VBQ0w7RUFDQTtFQUNBLElBQUksTUFBTSxZQUFZLEdBQUcsRUFBRTtFQUMzQixPQUFPLFNBQVMsRUFBRTtFQUNsQixPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQztFQUNoQyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ3RCO0VBQ0EsSUFBSSxTQUFTLE1BQU0sRUFBRSxDQUFDLEVBQUU7RUFDeEIsT0FBTyxPQUFPLFdBQVcsQ0FBQztFQUMxQixLQUFLO0FBQ0w7RUFDQSxJQUFJLElBQUksVUFBVSxHQUFHQyxvQkFBZSxDQUFDLEtBQUssQ0FBQztFQUMzQyxPQUFPLEtBQUssQ0FBQyxHQUFHLEVBQUVDLFdBQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTtFQUNyQyxRQUFRLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDOUMsT0FBTyxDQUFDLENBQUM7RUFDVCxPQUFPLEtBQUssQ0FBQyxHQUFHLEVBQUVDLFdBQU0sQ0FBQyxTQUFTLENBQUMsRUFBRTtFQUNyQyxRQUFRLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDOUMsT0FBTyxDQUFDLENBQUM7RUFDVCxPQUFPLEtBQUssQ0FBQyxTQUFTLEVBQUVDLGlCQUFZLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUN4RSxPQUFPLElBQUksRUFBRSxDQUFDO0VBQ2QsSUFBSSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztFQUNwRDtFQUNBO0VBQ0EsSUFBSSxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDO0VBQ3JDLElBQUksTUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7RUFDNUM7RUFDQSxJQUFJLFNBQVMsUUFBUSxFQUFFLEtBQUssQ0FBQztFQUM3QixNQUFNLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztFQUN2RDtFQUNBLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7RUFDeEIsU0FBUyxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQztFQUNqQyxXQUFXLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNqQyxXQUFXLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNqQyxXQUFXLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztFQUN4QyxXQUFXLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO0VBQ2xDLFdBQVcsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUM7RUFDbEMsV0FBVyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQztFQUNsQyxXQUFXLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO0VBQzdCLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksTUFBTSxDQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDcEQ7RUFDQSxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQ3RCLFdBQVcsSUFBSSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUM7RUFDckMsV0FBVyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO0VBQ3JDLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNwQyxXQUFXLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQzlDO0VBQ0EsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUN0QixXQUFXLElBQUksQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDO0VBQ3RDLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLFdBQVcsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDM0UsV0FBVyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSTtFQUNsQyxZQUFZLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO0VBQ25ELFdBQVcsQ0FBQztFQUNaLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ3hDLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUM7RUFDL0I7RUFDQSxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQ3RCLFdBQVcsSUFBSSxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUM7RUFDdEMsV0FBVyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sV0FBVyxDQUFDLENBQUMsRUFBRSxVQUFVLEdBQUcsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDeEYsV0FBVyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSTtFQUNsQyxZQUFZLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO0VBQ25ELFdBQVcsQ0FBQztFQUNaLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ3hDLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztFQUNqQztFQUNBLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUM7RUFDdEMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxjQUFjLENBQUMsQ0FBQztFQUN4QyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0VBQ3RDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsZUFBZSxDQUFDLENBQUM7RUFDekM7RUFDQSxNQUFNLE9BQU8sQ0FBQyxDQUFDO0VBQ2YsS0FBSztFQUNMO0VBQ0EsSUFBSSxTQUFTLFVBQVUsQ0FBQyxNQUFNLENBQUM7RUFDL0IsTUFBTSxTQUFTLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7RUFDbkQsU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUM1QztFQUNBLE1BQU0sU0FBUyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0VBQy9DLFNBQVMsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUN2QixXQUFXLElBQUksQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDO0VBQ3RDLFdBQVcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxPQUFPLFdBQVcsQ0FBQyxDQUFDLEVBQUUsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDM0UsV0FBVyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSTtFQUNsQyxZQUFZLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO0VBQ25ELFdBQVcsQ0FBQztFQUNaLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ3hDLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztFQUNoQztFQUNBLE1BQU0sU0FBUyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQ2xELFdBQVcsSUFBSSxDQUFDLE9BQU8sRUFBRSxZQUFZLENBQUM7RUFDdEMsV0FBVyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sV0FBVyxDQUFDLENBQUMsRUFBRSxVQUFVLEdBQUcsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDeEYsV0FBVyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsSUFBSTtFQUNsQyxZQUFZLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO0VBQ25ELFdBQVcsQ0FBQztFQUNaLFdBQVcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0VBQ3hDLFdBQVcsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztFQUNqQyxLQUFLO0VBQ0w7RUFDQSxJQUFJLE1BQU0sTUFBTSxJQUFJLFNBQVM7RUFDN0IsT0FBTyxTQUFTLENBQUMsUUFBUSxDQUFDO0VBQzFCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQztFQUNsQixNQUFNLElBQUk7RUFDVixRQUFRLENBQUMsS0FBSyxLQUFLLFFBQVEsQ0FBQyxLQUFLLENBQUM7RUFDbEMsUUFBUSxDQUFDLE1BQU0sS0FBSyxVQUFVLENBQU8sQ0FBQztFQUN0QyxRQUFRLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUU7RUFDL0IsT0FBTyxDQUFDO0VBQ1IsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDekIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDdEQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDN0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxRQUFRLENBQUM7RUFDOUQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDcEMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxlQUFlLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxlQUFlLENBQUM7RUFDNUUsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxhQUFhLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDbEMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxhQUFhLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxhQUFhLENBQUM7RUFDeEUsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDekIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDdEQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDL0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxVQUFVLENBQUM7RUFDbEUsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDNUIsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxPQUFPLENBQUM7RUFDNUQsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDaEMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxXQUFXLENBQUM7RUFDcEUsR0FBRyxDQUFDO0VBQ0o7RUFDQSxFQUFFLE9BQU8sRUFBRSxDQUFDO0VBQ1osQ0FBQzs7RUMvUk0sTUFBTSxRQUFRLEdBQUcsTUFBTTtFQUM5QixFQUFFLElBQUksS0FBSyxDQUFDO0VBQ1osRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUNiLEVBQUUsSUFBSSxVQUFVLENBQUM7RUFDakIsRUFBRSxJQUFJLElBQUksQ0FBQztFQUNYLEVBQUUsSUFBSSxNQUFNLENBQUM7RUFDYixFQUFFLElBQUksTUFBTSxDQUFDO0VBQ2IsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUNiLEVBQUUsSUFBSSxVQUFVLENBQUM7RUFDakIsRUFBRSxJQUFJLGNBQWMsQ0FBQztFQUNyQixFQUFFLElBQUksVUFBVSxDQUFDO0VBQ2pCLENBQUMsSUFBSSxTQUFTLENBQUM7RUFDZixFQUFFLElBQUksR0FBRyxDQUFDO0VBQ1Y7RUFDQSxFQUFFLE1BQU0sRUFBRSxHQUFHLENBQUMsU0FBUyxLQUFLO0VBQzVCLElBQUksU0FBUyxZQUFZLENBQUMsSUFBSSxFQUFFO0VBQ2hDLE1BQU0sT0FBTyxJQUFJLENBQUMsUUFBUSxJQUFJLGNBQWMsQ0FBQztFQUM3QyxLQUFLO0VBQ0w7RUFDQTtFQUNBLElBQUksTUFBTSxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7RUFDM0MsSUFBSSxNQUFNLE9BQU8sR0FBRyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztFQUMzQztFQUNBLElBQUksTUFBTSxDQUFDLEdBQUdoQixjQUFTLEVBQUU7RUFDekIsT0FBTyxNQUFNLENBQUMsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7RUFDakMsT0FBTyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNsRDtFQUNBLElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDM0M7RUFDQSxJQUFJLE1BQU0sQ0FBQyxHQUFHQyxnQkFBVyxFQUFFO0VBQzNCLE9BQU8sTUFBTSxDQUFDO0VBQ2QsUUFBUUMsV0FBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDckMsUUFBUUEsV0FBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHO0VBQzNDLE9BQU8sQ0FBQztFQUNSLE9BQU8sS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFRbkQ7RUFDQTtFQUNBLElBQUksTUFBTSxDQUFDLEdBQUdFLGVBQVUsRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUN6QztFQUNBLElBQUksTUFBTSxhQUFhLEdBQUcsRUFBRSxDQUFDLElBQUksRUFBRTtFQUNuQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3pCLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUMxQjtFQUNBLElBQUksU0FBUyxZQUFZLENBQUMsSUFBSSxFQUFFO0VBQ2hDLE1BQU0sT0FBTyxJQUFJLENBQUMsUUFBUSxJQUFJLGNBQWMsQ0FBQztFQUM3QyxLQUFLO0VBQ0w7RUFDQSxJQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQzVCLE9BQU8sSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7RUFDM0IsT0FBTyxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQztFQUM5QixPQUFPLElBQUksQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDO0VBQ2hDLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztFQUM1QztFQUNBO0VBQ0EsSUFBSSxTQUFTO0VBQ2IsT0FBTyxTQUFTLENBQUMsU0FBUyxDQUFDO0VBQzNCLE9BQU8sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDbkIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQ2hCLE9BQU8sSUFBSSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUM7RUFDOUIsT0FBTyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDdkQsT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDO0VBQ3BCLE9BQU8sSUFBSSxDQUFDQyxhQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QjtFQUNBO0VBQ0EsSUFBSSxTQUFTO0VBQ2IsT0FBTyxTQUFTLENBQUMsU0FBUyxDQUFDO0VBQzNCLE9BQU8sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDbkIsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQ2hCLE9BQU8sSUFBSSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUM7RUFDOUIsT0FBTyxJQUFJO0VBQ1gsUUFBUSxXQUFXO0VBQ25CLFFBQVEsQ0FBQyxZQUFZLEVBQUUsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ2hELE9BQU87RUFDUCxPQUFPLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDcEIsT0FBTyxJQUFJLENBQUNDLGVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzNCLEdBQUcsQ0FBQztBQUNKO0VBQ0EsRUFBRSxFQUFFLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxFQUFFO0VBQzFCLElBQUksT0FBTyxTQUFTLENBQUMsTUFBTSxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxLQUFLLENBQUM7RUFDekQsR0FBRyxDQUFDO0FBQ0o7RUFDQSxFQUFFLEVBQUUsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLEVBQUU7RUFDM0IsSUFBSSxPQUFPLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUMzRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsRUFBRTtFQUN6QixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLElBQUksQ0FBQztFQUN0RCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsRUFBRTtFQUMzQixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUMxRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsRUFBRTtFQUMzQixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUMxRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLE1BQU0sR0FBRyxVQUFVLENBQUMsRUFBRTtFQUMzQixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQztFQUMxRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUMsRUFBRTtFQUMvQixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU07RUFDM0IsU0FBUyxDQUFDLFVBQVUsR0FBRyxDQUFDLEdBQUcsRUFBRTtFQUM3QixRQUFRLFVBQVUsQ0FBQztFQUNuQixHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLGNBQWMsR0FBRyxVQUFVLENBQUMsRUFBRTtFQUNuQyxJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU07RUFDM0IsU0FBUyxDQUFDLGNBQWMsR0FBRyxDQUFDLEdBQUcsRUFBRTtFQUNqQyxRQUFRLGNBQWMsQ0FBQztFQUN2QixHQUFHLENBQUM7RUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUMsRUFBRTtFQUMvQixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU07RUFDM0IsU0FBUyxDQUFDLFVBQVUsR0FBRyxDQUFDLEdBQUcsRUFBRTtFQUM3QixRQUFRLFVBQVUsQ0FBQztFQUNuQixHQUFHLENBQUM7RUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsRUFBRTtFQUM5QixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLFNBQVMsQ0FBQztFQUNoRSxHQUFHLENBQUM7RUFDSjtFQUNBLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsRUFBRTtFQUN4QixJQUFJLE9BQU8sU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsQ0FBQztFQUNwRCxHQUFHLENBQUM7QUFDSjtFQUNBLEVBQUUsT0FBTyxFQUFFLENBQUM7RUFDWixDQUFDOztFQ25KRCxNQUFNO0VBQ04sRUFBRSxHQUFHO0VBQ0wsRUFBRSxNQUFNO0VBQ1IsRUFBRSxJQUFJO0VBQ04sRUFBRSxNQUFNO0VBQ1IsQ0FBQyxHQUFHLEVBQUUsQ0FBQztBQU1QO0VBQ0E7RUFDQSxNQUFNLE1BQU0sR0FBRztFQUNmLEVBQUUscUNBQXFDO0VBQ3ZDLEVBQUUsbUJBQW1CO0VBQ3JCLEVBQUUsbUNBQW1DO0VBQ3JDLEVBQUUsTUFBTTtFQUNSLEVBQUUsa0JBQWtCO0VBQ3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDWDtFQUNBLE1BQU0sT0FBTyxHQUFHO0VBQ2hCLENBQUMscUNBQXFDO0VBQ3RDLEVBQUUsbUJBQW1CO0VBQ3JCLEVBQUUsbUNBQW1DO0VBQ3JDLEVBQUUsTUFBTTtFQUNSLEVBQUUsc0JBQXNCO0VBQ3hCLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFDO0FBQ1Y7RUFDQSxNQUFNLE1BQU0sR0FBRyxtREFBa0Q7QUFDakU7RUFDQTtFQUNBLE1BQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxLQUFLO0VBQ3hCLEVBQUUsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7RUFDNUIsRUFBRSxDQUFDLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUM7RUFDL0MsRUFBRSxDQUFDLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUM7RUFDN0MsRUFBRSxDQUFDLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUM7RUFDN0MsRUFBRSxDQUFDLENBQUMsbUNBQW1DLEdBQUcsQ0FBQyxDQUFDLENBQUMsbUNBQW1DLENBQUM7RUFDakYsRUFBRSxDQUFDLENBQUMsOEJBQThCLEdBQUcsQ0FBQyxDQUFDLENBQUMsOEJBQThCLENBQUM7RUFDdkUsRUFBRSxDQUFDLENBQUMsdUJBQXVCLEdBQUcsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUM7RUFDekQsRUFBRSxDQUFDLENBQUMsNkJBQTZCLEdBQUcsQ0FBQyxDQUFDLENBQUMsNkJBQTZCLENBQUM7RUFDckUsRUFBRSxDQUFDLENBQUMsdUJBQXVCLEdBQUcsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUM7RUFDekQsRUFBRSxDQUFDLENBQUMsc0JBQXNCLEdBQUcsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUM7RUFDdkQsRUFBRSxDQUFDLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUM7RUFDL0MsRUFBRSxDQUFDLENBQUMsOEJBQThCLEdBQUcsQ0FBQyxDQUFDLENBQUMsOEJBQThCLENBQUM7RUFDdkUsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7RUFDM0MsRUFBRSxPQUFPLENBQUMsQ0FBQztFQUNYLENBQUMsQ0FBQztBQUNGO0VBQ0E7RUFDQSxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDO0VBQ2hDLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFDbEM7RUFDQSxNQUFNLEdBQUcsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQzFCLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztFQUNoQixHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxHQUFHLEdBQUcsQ0FBQztFQUM3QixHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsTUFBTSxHQUFHLEdBQUcsQ0FBQztFQUMvQixFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFDM0I7RUFDQSxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQzNCLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztFQUNoQixHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDO0VBQ3JCLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxNQUFNLEdBQUcsR0FBRyxDQUFDO0VBQy9CLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUM7RUFDMUIsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLGtCQUFrQixDQUFDLENBQUM7QUFDcEM7RUFDQSxNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQzNCLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztFQUNoQixHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsS0FBSyxHQUFHLEVBQUUsQ0FBQztFQUM1QixHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDO0VBQ3RCLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztBQUMzQjtFQUNBLElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUM7RUFDNUIsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO0VBQ2hCLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQztFQUNmLEtBQUssSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUM7RUFDMUIsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDO0VBQ3JDLEtBQUssS0FBSyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7RUFDakMsS0FBSyxLQUFLLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQ25DO0VBQ0EsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUNsQyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7RUFDaEIsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQztFQUM5QixHQUFHLEtBQUssQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDO0VBQ2hDLEdBQUcsS0FBSyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUM7RUFDekIsR0FBRyxLQUFLLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQztFQUNoQyxHQUFHLEtBQUssQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDO0VBQzNCLEdBQUcsS0FBSyxDQUFDLFlBQVksRUFBRSxpQkFBaUIsQ0FBQztFQUN6QyxHQUFHLEtBQUssQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDO0VBQ2hDLEdBQUcsS0FBSyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztBQUMzQjtFQUNBLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFDO0VBQ2pDLE1BQU0sU0FBUyxHQUFHLElBQUc7RUFDckIsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUM7RUFDbEMsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDMUM7RUFDQSxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQ25DLE1BQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQztBQUM1QjtFQUNBLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDcEM7RUFDQSxJQUFJLElBQUksR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFO0VBQ3BCLEVBQUUsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUs7RUFDdkIsR0FBRyxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUM7RUFDaEMsR0FBRyxNQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUM7RUFDaEMsR0FBRyxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUM7RUFDcEMsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxRQUFRLEVBQUUsV0FBVyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBQztFQUNuRyxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0E7QUFDQTtFQUNBLE1BQU0sSUFBSSxHQUFHLFlBQVk7RUFDekI7RUFDQSxFQUFFLE1BQU0sSUFBSSxHQUFHLE1BQU0sR0FBRyxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQztFQUMzQyxFQUFFLE1BQU0sU0FBUyxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0VBQ3ZDLEVBQUUsSUFBSSxjQUFjLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7RUFDM0M7RUFDQSxFQUFFLFNBQVMsVUFBVSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFO0VBQzFDLEdBQUcsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLEtBQUssQ0FBQztFQUN4QyxFQUFFO0VBQ0YsQ0FBQyxNQUFNLFdBQVcsR0FBRyxJQUFJO0VBQ3pCLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUM7RUFDMUIsSUFBSSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7RUFJdkIsR0FBRyxNQUFNLFFBQVEsR0FBRyxVQUFVLEVBQUU7RUFDaEMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2QsSUFBSSxRQUFRLENBQUMsU0FBUyxDQUFDO0VBQ3ZCLElBQUksZUFBZSxDQUFDLGNBQWMsQ0FBQztFQUNuQyxLQUFLLGFBQWEsQ0FBQyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztFQUMxQyxLQUFLLFdBQVcsQ0FBQyxXQUFXLENBQUM7RUFDN0IsS0FBSyxVQUFVLENBQUMsU0FBUyxDQUFDO0VBQzFCLEtBQUssT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0VBQzFCLEVBQUUsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUMzQjtFQUNBO0VBQ0EsRUFBRSxNQUFNLFFBQVEsR0FBRyxjQUFjLEVBQUU7RUFDbkMsS0FBSyxLQUFLLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztFQUN0QixLQUFLLE1BQU0sQ0FBQyxlQUFlLENBQUM7RUFDNUIsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ2YsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztFQUMxQixLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsa0JBQWtCLENBQUM7RUFDeEMsS0FBSyxNQUFNLENBQUM7RUFDWixNQUFNLEdBQUcsRUFBRSxFQUFFO0VBQ2IsTUFBTSxLQUFLLEVBQUUsRUFBRTtFQUNmLE1BQU0sTUFBTSxFQUFFLEVBQUU7RUFDaEIsTUFBTSxJQUFJLEVBQUUsR0FBRztFQUNmLEtBQUssQ0FBQztFQUNOLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQztFQUNqQixLQUFLLFNBQVMsQ0FBQyxTQUFTLENBQUM7RUFDekIsSUFBSSxXQUFXLENBQUMsR0FBRyxDQUFDO0VBQ3BCLEtBQUssY0FBYyxDQUFDLFNBQVMsQ0FBQztFQUM5QixJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUM7RUFDckIsSUFBSSxTQUFTLENBQUMsU0FBUyxDQUFDO0VBQ3hCLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0VBQ2xCO0VBQ0EsRUFBRSxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0VBQzNCO0VBQ0EsRUFBRSxNQUFNLFNBQVMsR0FBRyxRQUFRLEVBQUU7RUFDOUIsSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDO0VBQ2QsS0FBSyxNQUFNLENBQUMsR0FBRyxDQUFDO0VBQ2hCLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQztFQUNmLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7RUFDMUIsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0VBQ3RDLEtBQUssTUFBTSxDQUFDO0VBQ1osTUFBTSxHQUFHLEVBQUUsRUFBRTtFQUNiLE1BQU0sS0FBSyxFQUFFLEVBQUU7RUFDZixNQUFNLE1BQU0sRUFBRSxFQUFFO0VBQ2hCLE1BQU0sSUFBSSxFQUFFLEVBQUU7RUFDZCxLQUFLLENBQUM7RUFDTixLQUFLLFVBQVUsQ0FBQyxTQUFTLENBQUM7RUFDMUIsS0FBSyxjQUFjLENBQUMsU0FBUyxDQUFDO0VBQzlCLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQztFQUNyQixJQUFJLFNBQVMsQ0FBQyxTQUFTLENBQUM7RUFDeEIsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7RUFDbEIsRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0VBQzdCO0VBQ0EsRUFBRSxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0VBQzFCO0VBQ0E7RUFDQSxFQUFFLE1BQU0sT0FBTyxHQUFHLFNBQVMsRUFBRTtFQUM3QixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUM7RUFDZCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUNuQixDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7RUFDekIsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pCO0VBQ0EsQ0FBQyxDQUFDO0FBQ0Y7RUFDQSxNQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25DO0VBQ0EsSUFBSSxRQUFRLEdBQUcsR0FBRyxDQUFDO0VBQ25CLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQztFQUNsQixJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7RUFDckIsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDO0FBQ25CO0VBQ0EsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7RUFDekIsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQztFQUNyQixHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO0VBQ3JCLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUM7RUFDckIsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQztFQUNyQixFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO0VBQ3ZCLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztBQUMxQjtFQUNBLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0VBQ3pCLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUM7RUFDMUIsR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQztFQUM1QixFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsUUFBUSxHQUFHLFdBQVcsQ0FBQztFQUNuQyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsUUFBUSxHQUFHLFdBQVcsQ0FBQztFQUNuQyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFDeEI7RUFDQSxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUN6QixFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDO0VBQzVCLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztFQUNqQixJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsUUFBUSxHQUFHLFdBQVcsR0FBRyxHQUFHLEdBQUcsU0FBUyxDQUFDO0VBQ3ZELEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxRQUFRLEdBQUcsV0FBVyxHQUFHLEdBQUcsQ0FBQztFQUMxQyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7RUFDdEIsRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0VBQ2pCLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxRQUFRLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxTQUFTLENBQUM7RUFDdEQsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLFFBQVEsR0FBRyxXQUFXLEdBQUcsR0FBRyxDQUFDO0VBQzFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ3RCO0VBQ0EsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7RUFDekIsRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQztFQUMxQixHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDO0VBQzVCLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxRQUFRLEdBQUcsV0FBVyxDQUFDO0VBQ25DLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxRQUFRLEdBQUcsV0FBVyxHQUFHLEdBQUcsQ0FBQztFQUN6QyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDdkI7RUFDQSxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUN6QixFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDO0VBQzVCLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztFQUNqQixJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsUUFBUSxHQUFHLFdBQVcsR0FBRyxHQUFHLEdBQUcsU0FBUyxDQUFDO0VBQ3ZELEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxRQUFRLEdBQUcsV0FBVyxHQUFHLEdBQUcsQ0FBQztFQUMxQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7RUFDckIsRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0VBQ2pCLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxRQUFRLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxTQUFTLENBQUM7RUFDdEQsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLFFBQVEsR0FBRyxXQUFXLEdBQUcsR0FBRyxDQUFDO0VBQzFDLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ3RCO0VBQ0EsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7RUFDbkIsRUFBRSxJQUFJLENBQUMseUJBQXlCLENBQUM7RUFDakMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQztFQUNoQixHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDO0VBQ2pCLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUM7RUFDN0IsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLHNCQUFzQixDQUFDLENBQUM7QUFDN0M7RUFDQSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUNuQixFQUFFLElBQUksQ0FBQyxhQUFhLENBQUM7RUFDckIsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO0VBQzVCLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7RUFDakIsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQzlCO0VBQ0EsSUFBSSxFQUFFOzs7OyJ9