import {
  max,
  geoAlbersUsa,
  geoPath,
  topjson,
  transition,
  forceSimulation,
  forceCollide,
  forceX,
  forceY,
  arc,
  scaleSqrt,
  select
} from 'd3';

let marks;

export const mapElement = () => {
  let width;
  let height;
  let data;
  let map_data;
  let state_centroids;
  let selected_date;
  
  const my = (selection) => {
  	const projection = geoAlbersUsa();
    const path = geoPath(projection);

    const states = selection
      .selectAll('path')
      .data(topojson.feature(map_data, map_data.objects.states).features)
      .join(
        (enter) =>
          enter
            .append('path')
            .attr('d', path)
            .attr('id', (d) => d.properties.name)
            .attr('id', (d) => d.location)
            .attr('stroke', 'black')
            .attr('fill', 'lightgray'),
        (update) =>
          update.call((update) =>update),
        (exit) => exit.remove()
      );
     
  
    // const selected_date = new Date('2021-09-04');
    function filter_date(list) {
      return list.date.getDate() == selected_date.getDate()&& 
        list.date.getMonth() == selected_date.getMonth()&& 
        list.date.getFullYear() == selected_date.getFullYear();
    }
    const date_data = data.filter(filter_date);  
    
    let my_state = "California"
    function get_state_centroid(centroids) {
      return centroids.name == my_state;
    }

    let marks = date_data.map((d) => {
      my_state = d.location;
      const center = state_centroids.filter(get_state_centroid)[0];
      if(center)
        return { 
          location : d.location,
          lat : center.lat,
          lon : center.lon,
          full : d.people_fully_vaccinated_per_hundred,
          part : d.people_vaccinated_per_hundred,
          doses : d.share_doses_used
        }
    });
    
    marks = marks.filter(function( element ) {
     return element !== undefined;
    });

    const highest_vacc = max(marks, function (d) {
        return d.full;
    });
    
    // ARC STUFF
    let ring_width = 7;
    let ring_radius = 12;
    function generateArc(d, base_radius, value) {
    	let inner = base_radius;
      let outer = base_radius + ring_width;
      let angle = (value(d) / 100) * 2*Math.PI;
      let arcGen = arc()
        .innerRadius(inner)
        .outerRadius(outer)
        .startAngle(0)
        .endAngle(angle);
      return arcGen(d);
    }
    // END ARC STUFF
  
    const circleRadius = d3
      .scaleSqrt()
      .domain([0, highest_vacc])
      .range([0, 25]); // 0 to maximum radius in pixels
    
   	function radius (d) { 
       return ring_radius;
    }	

    var simulation = forceSimulation(marks)
      .force("x", forceX(function(d) {
        return projection([+d.lon,+d.lat])[0];
      }))
      .force("y", forceY(function(d) {
        return projection([+d.lon,+d.lat])[1];
      }))
      .force("collide", forceCollide(d => radius(d) + ring_width*2 + 1))
      .stop();
    for (var i = 0; i < 120; ++i) simulation.tick();
        
    const circles  = selection
      .selectAll('.circles')
      .data(marks)
    	.join(
        (enter) =>
          enter
            .append("circle")
        		.attr('class', 'circles')
  		      .attr('cx', (d) => d.x)
	    	    .attr('cy', (d) => d.y)
       		  .attr('id', (d) => d.location)
        		.attr('fill', '#e0dcdc')
        		.attr('stroke', 'black')
        		.attr('stroke-width', 2)
        		.attr('opacity', 1)
        		.attr('r', d => radius(d) + ring_width*2),
        (update) =>
          update.call((update) => update),
        (exit) => exit.remove()
      );
    
    const vacc_value = (d) => d.full;
    const vacc_rings = selection
      .selectAll('.vacc-rings')
      .data(marks)
    	.join(
        (enter) =>
          enter
            .append("path")
        		.attr('class', '.vacc-rings')
        		.attr("d", d => {return generateArc(d, ring_radius, vacc_value)})
        		.attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
       		  .attr('id', (d) => d.location)
        		.attr('fill', 'blue'),
        (update) =>
          update.call((update) => update),
        (exit) => exit.remove()
      );
    
    const dose_value = (d) => d.doses * 100;
    const dose_rings = selection
      .selectAll('.dose-rings')
      .data(marks)
    	.join(
        (enter) =>
          enter
            .append("path")
        		.attr('class', '.dose-rings')
        		.attr("d", d => {return generateArc(d, ring_width + ring_radius, dose_value)})
        		.attr("transform", d => {
              return "translate(" + [d.x, d.y] + ")";
            })
       		  .attr('id', (d) => d.location)
        		.attr('fill', 'green'),
        (update) =>
          update.call((update) => update),
        (exit) => exit.remove()
      );
    
      const vacc_text = selection
        .selectAll('.vacc-text')
        .data(marks)
        .join(
          (enter) =>
            enter
              .append("text")
              .attr('class', '.vacc-text')
              .attr('x', (d) => d.x - 10)
              .attr('y', (d) => d.y + 5)
              .text((d) => "" + parseInt(d.full)),
          (update) => update,
          (exit) => exit.remove()
        );

  };
  
  my.data = function (_) {
    return arguments.length ? ((data = _), my) : data;
  };
  
  my.map_data = function (_) {
    return arguments.length ? ((map_data = _), my) : map_data;
  };
  
  my.state_centroids = function (_) {
    return arguments.length ? ((state_centroids = _), my) : state_centroids;
  };
  
  my.selected_date = function (_) {
    return arguments.length ? ((selected_date = _), my) : selected_date;
  };
  
  return my;
};
