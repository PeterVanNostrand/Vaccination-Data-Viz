const {
    csv,
    select,
    scaleLinear,
    extent,
    axisLeft,
    axisBottom,
    scaleLog,
    scaleTime
  } = d3;

// ##### DATA SOURCE AND MANIPULATION #####
// data source url
const csvUrl = [
  'https://gist.githubusercontent.com/',
  'PeterVanNostrand/', // User
  'd449b0a3e5914278dfa79ba60e48df5d/', // Id of the Gist
  'raw/', // commit
	'vaccine_data.csv', // File name
].join('');

// parsing the dataset
const parseRow = (d) => {
  d.date = new Date(d.date);
  d.total_vaccinations = +d.total_vaccinations;
  d.total_distributed = +d.total_distributed;
  d.people_vaccinated = +d.people_vaccinated;
  d.people_fully_vaccinated_per_hundred = +d.people_fully_vaccinated_per_hundred;
  d.total_vaccinations_per_hundred = +d.total_vaccinations_per_hundred;
  d.people_fully_vaccinated = +d.people_fully_vaccinated;
  d.people_vaccinated_per_hundred = +d.people_vaccinated_per_hundred;
  d.distributed_per_hundred = +d.distributed_per_hundred;
  d.daily_vaccinations_raw = +d.daily_vaccinations_raw;
  d.daily_vaccinations = +d.daily_vaccinations;
  d.daily_vaccinations_per_million = +d.daily_vaccinations_per_million;
  d.share_doses_used = +d.share_doses_used;
  return d;
};

// function to select only the data for a specific state
let selected_state = "New York State"
function filter_state(list) {
  return list.location == selected_state
}

// values to visualize
const xValue = (d) => d.date;
const yValue = (d) => d.daily_vaccinations;

// Select the SVG element
const svg = select('svg');
const width = +svg.attr('width');
const height = +svg.attr('height');
const g = svg.append('g');

// Draw a rectangle for testing
// const rect = g.append('rect')
// 	.attr('width', 100)
// 	.attr('height',100)
// 	.attr('x', 0)
// 	.attr('y', 0);

// Margin for axis label spacing
const margin = {
  top: 20,
  right: 20,
  bottom: 40,
  left: 100,
};
const bar_width = 3;
const bar_opacity = 1.0;
const bar_color = "#5DABF4";

const main = async () => {
  // load and filter the data
  const data_raw = await csv(csvUrl, parseRow);
  const data = data_raw.filter(filter_state);
  console.log(data);

  // Create a time scale for the x-axis
  const mindate = new Date("2021-04-01")
  const maxdate = new Date("2021-09-04")
  const x = scaleTime()
    .domain([mindate, maxdate])
    .range([margin.left, width - margin.right]);

  // Create a linear scale for the y-axis
  const y = scaleLinear()
    .domain(extent(data, yValue))
    .range([height - margin.bottom, margin.top]);

  // create a set of marks to visualize
  const marks = data.map((d) => ({
    x: x(xValue(d)),
    y: y(yValue(d)),
  }));

  // Draw the marks usind d3
  g.selectAll('rect').data(marks)
    .join('rect')
  	.attr('width', bar_width)
  	.attr('height', (d) => d.y)
  	.attr('opacity', bar_opacity)
  	.attr('fill', bar_color)
    .attr('x', (d) => {
    	return d.x + bar_width/2
  	})
  	.attr('y', (d) => {
      // place the bottom of each bar at the x-axis
  		return height - margin.bottom - d.y;
  	});

  // Create axes
  svg
    .append('g')
    .attr('transform', `translate(${margin.left},0)`)
    .call(axisLeft(y));
  svg
    .append('g')
    .attr('transform', `translate(0,${height - margin.bottom})`)
    .call(axisBottom(x));
  };

main();










